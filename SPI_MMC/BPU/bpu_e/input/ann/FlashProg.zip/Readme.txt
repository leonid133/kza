		--------------------------------------------------------
                 Cygnal Integrated Products version 1.003 Readme File
                                        2001
                --------------------------------------------------------



This document provides information that supplements the Cygnal Memory Programmer FlashProg.exe.

The accompanying files CygUtil.dll and CygUtil.lib must be placed in one the following directories:

	1. The directory containing the EXE client file.
	2. The process�s current directory.
	3. The Windows system directory. ex. C:\Windows\System, 		C:\Windows\System32, C:\WINNT\System32, C:\WINNT\System
	4. The Windows directory. ex. C:\Windows
	5. The directories listed in the Path environment variable.

Further Documentation is provided in Application Note 17


