-------------------------------------------------------------------------------
 Readme.txt
-------------------------------------------------------------------------------

Copyright 2007 Silicon Laboratories, Inc.
http://www.silabs.com

Program Description:
-------------------

The USB MSD RD includes all the �F340 firmware necessary to handle the following:
* USB enumeration and standard requests
* MSD class requests
* SCSI command set
* Media access - SD, MMC and CompactFlash card formats
* FAT16 file system support

Also included is an example application that can perform the following tasks:
* Present an interactive command shell via the UART
* Measure temperature using the on-chip temperature sensor and ADC
* Monitor the state of the two push-button switches on the target board
* Log the temperature and button state information to log files in the memory card


How To Test:
-----------

Refer to the "USB Mass Storage Device Reference Design Kit User's Guide" for 
step-by-step demonstration instructions. This is avilable here:
http://www.silabs.com/products/microcontroller/designs.asp

For more information on the firmware components and the file system API, 
please see the application note "AN282-USB Mass Storage Device Reference Design 
Programmer's Guide", which is available here:
http://www.silabs.com/products/microcontroller/applications.asp


Target and Tool Chain Information:
---------------------------------

FID:            34X000071
Target:         C8051F34x
Tool chain:     Keil C51 v8.0 (A51, C51, BL51)
                Silicon Laboratories IDE version 2.71
Project Name:   F34x_MSD


Command Line Options:
--------------------

Assembler : XR GEN DB EP NOMOD51
Compiler  : PW(80) SB LC OT(9,Size) CD DB OE DF(__F340_VER__) Large
Linker    : RS(256) PL(68) PW(78) IX


File List:
---------

c8051F320.h
F34x_MSD.wsp
F34x_MSD_CF_Basic_Functions.c
F34x_MSD_CF_Basic_Functions.h
F34x_MSD_Cmd.c
F34x_MSD_Cmd.h
F34x_MSD_Definitions.h
F34x_MSD_Dir_Commands.c
F34x_MSD_Dir_Commands.h
F34x_MSD_File_System.c
F34x_MSD_File_System.h
F34x_MSD_Format_Disk.c
F34x_MSD_Format_Disk.h
F34x_MSD_Get_Char.c
F34x_MSD_Get_Char.h
F34x_MSD_Log.c
F34x_MSD_Log.h
F34x_MSD_MMC.c
F34x_MSD_MMC.h
F34x_MSD_MMC_Command.asm
F34x_MSD_MSD.c
F34x_MSD_MSD.h
F34x_MSD_Physical_Settings.h
F34x_MSD_Put_Char.c
F34x_MSD_Put_Char.h
F34x_MSD_Scsi.c
F34x_MSD_Scsi.h
F34x_MSD_Sect_Serv.c
F34x_MSD_Sect_Serv.h
F34x_MSD_Temp_Sensor.c
F34x_MSD_Temp_Sensor.h
F34x_MSD_UART.c
F34x_MSD_UART.h
F34x_MSD_USB_Descriptor.c
F34x_MSD_USB_Descriptor.h
F34x_MSD_USB_ISR.c
F34x_MSD_USB_Main.c
F34x_MSD_USB_Main.h
F34x_MSD_USB_Procedure.asm
F34x_MSD_USB_Register.h
F34x_MSD_USB_Std_Req.c
F34x_MSD_Util.c
F34x_MSD_Util.h
F34x_MSD_VBUS_Functions.c
F34x_MSD_VBUS_Functions.h
Readme.txt [this file]


Release Information:
-------------------

Release 1.2
  -All changes by BD and PD
  -26 SEP 2007
  -Added Modified Startup.A51 to project
  -In F34x_MSD_File_System.c:
    -Modified code in fwrite() and fat_chain() to fix cluster-spanning bug.
    -Modified code in file_name_match() to fix bug with multiple files that
       were recorded with the same name.
  -In F34x_MSD_Log.c:
    -Changed Log_Step() routine to perform only one fwrite() and decrease
       amount of time spent logging the button data by 67%.
  -In F34x_MSD_MMC.c:
    -Removed debugging printf()s.

Release 1.1
  -All changes by PKC
  -09 JUN 2006
  -Replaced SFR definitions file "c8051f320.h" with "c8051f340.h"
  -Removed individual SFR definitions and included c8051f340.inc in asm files
  -Corrected "SPIDAT" to "SPI0DAT" in F34x_MSD_MMC.c

Release 1.0
  -Initial Release

-------------------------------------------------------------------------------
 End Of File
-------------------------------------------------------------------------------
