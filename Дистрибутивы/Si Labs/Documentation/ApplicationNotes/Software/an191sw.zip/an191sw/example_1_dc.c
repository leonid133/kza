//-----------------------------------------------------------------------------
// Example 1
// DC Motor Control
//-----------------------------------------------------------------------------
// Copyright 2004 Silicon Laboratories Inc.
//
// AUTH: KAB
// DATE: 12MAR04
//
// This program provides simple DC motor control using the PCA 8-bit PWM Mode.
// The ADC is used to read the potentiometer voltage on P0.6. The ADC uses
// polled mode and 64 sample averaging. The 8-bit PWM is configured to operate
// at 24 kHz. The PWM high-time varies from a minimum of 160 ns to a maximum of
// 100%.
//
// Target: C8051F30x
//
// Tool chain: KEIL Eval 'c'
//
//-----------------------------------------------------------------------------
// Includes
//-----------------------------------------------------------------------------

#include <c8051f300.h>                 // SFR declarations

//-----------------------------------------------------------------------------
// Function PROTOTYPES
//-----------------------------------------------------------------------------
void SYSCLK_Init (void);               // Initialize SYSCLK
void PORT_Init (void);                 // Initialize XBR and Port Pins
void PCA0_Init (void);                 // Initialize PCA0
void ADC0_Init (void);                 // Initialize ADC
unsigned char readVin(void);           // read ADC using polling
unsigned char avgVin(void);            // returns avg ADC reading


//-----------------------------------------------------------------------------
// MAIN Routine
//-----------------------------------------------------------------------------
void main (void)
{
   PCA0MD &= ~0x40;                    // Disable Watchdog Timer

   SYSCLK_Init ();                     // Initialize system clock
   PORT_Init ();                       // Initialize crossbar and GPIO
   ADC0_Init();                        // Initialize ADC for polled mode
   PCA0_Init ();                       // PCA0 for 8-bit PWM

   EA = 1;                             // enable global interrupts

   while (1)
   {
      PCA0CPH0 = avgVin();             // get avg reading and output to PWM
   }
}

//-----------------------------------------------------------------------------
// SYSCLK_Init
//-----------------------------------------------------------------------------
//
// This routine initializes the system clock to use the internal 24.5MHz
// oscillator as its clock source.  Also enables missing clock detector reset
// and the VDD Monitor.
//
void SYSCLK_Init (void)
{
   OSCICN = 0x07;                      // configure internal oscillator for
   RSTSRC = 0x06;                      // enable missing clock detector
                                       // and VDD Monitor.
}

//-----------------------------------------------------------------------------
// PORT_Init
//-----------------------------------------------------------------------------
//
// Configure the Crossbar and GPIO ports.
// P0.0 - /PWM - active low PWM signal
// P0.1 -
// P0.2 -
// P0.3 -
// P0.4 -
// P0.5 -
// P0.6 - Analog Input
// P0.7 - C2D
//
void PORT_Init (void)
{
   XBR0     =  0x00;                    // don't skip any pins
   XBR1     =  0x40;                    // Enable CEX0 on P0.0
   P0MDOUT  =  0x01;                    // Enable P0.0 as a push-pull output
   P0MDIN   = ~0x40;                    // Configure P0.6 for analog input
   XBR2    |=  0x40;                    // Enable crossbar

}


//-----------------------------------------------------------------------------
// PCA0_Init
//-----------------------------------------------------------------------------
//
//
void PCA0_Init (void)
{

   PCA0MD = 0x02;                      // PCA uses sysclk/4, no PCA interrupt

   PCA0CPM0 = 0x42;                    // Module 0, 8-bit PWM Mode

   PCA0L = 0x00;                       // reset the timer
   PCA0H = 0x00;
   PCA0CPL0 = 0x00;
   PCA0CPH0 = 0x00;                    // Initialize to minimum duty
   CR = 1;                             // Start PCA0 timer
}

//-----------------------------------------------------------------------------
// ADC0_Init
//-----------------------------------------------------------------------------

void ADC0_Init (void)
{
   ADC0CN = 0x40;                      // Low-power tracking mode;
                                       // ADC0 conversions are initiated
                                       // on writes to AD0BUSY;
   AMX0SL = 0xf6;                      // select P0.6, single-ended
   ADC0CF = 0x81 ;                     // AD0SC=4 gain =1
   REF0CN = 0x0a;                      // ADC uses Vdd for full scale
   EIE1 &= ~0x04;                      // disable ADC0 EOC interrupt
   AD0EN = 1;                          // enable ADC
}

unsigned char readVin(void)
{
   AD0INT = 0;                         // clear ADC0 end-of-conversion
   AD0BUSY = 1;                        // initiate conversion
   while (!AD0INT);                    // wait for conversion to complete
   return ADC0;
}

unsigned char avgVin(void)
{
   unsigned char i, result;
   unsigned int sum;

   sum = 0;
   for (i = 64; i != 0; i--)           // repeat 64 times
   {
      sum += readVin();                // read ADC and add to sum
   }
   result = (unsigned char)(sum>>6);   // divide by 64 and cast to uchar
   return result;                      // return average reading
}