//-----------------------------------------------------------------------------
// F326_AES_Typdef.h
//-----------------------------------------------------------------------------
// Copyright 2007 Silicon Laboratories, Inc.
// http://www.silabs.com
//
// Program Description:
//
//
// How To Test:    See Readme.txt
//
//          
// Target:         C8051F326
// Tool chain:     Keil C51 7.50 / Keil EVAL C51
//                 Silicon Laboratories IDE version 2.91
// Command Line:   See Readme.txt
// Project Name:   F326_AES
//
//
// Release 1.0
//    -Initial Revision (CG/GP)
//    -11 JUN 2007
//

#ifndef _F326_AES_TYPEDEF_H_
#define _F326_AES_TYPEDEF_H_

//-----------------------------------------------------------------------------
// Type definitions
//-----------------------------------------------------------------------------

typedef	unsigned char byte;            // Type used for byte storage

typedef union INT {
   unsigned int i;
   unsigned char b[2];
} INT;

typedef struct word
{
   byte b0;
   byte b1;
   byte b2;
   byte b3;
} word;

//-----------------------------------------------------------------------------
// Close File Definition
//-----------------------------------------------------------------------------

#endif 

//-----------------------------------------------------------------------------
// End Of File
//-----------------------------------------------------------------------------