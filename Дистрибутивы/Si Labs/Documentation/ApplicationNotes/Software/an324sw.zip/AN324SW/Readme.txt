-------------------------------------------------------------------------------
 Readme.txt
-------------------------------------------------------------------------------

Copyright 2007 Silicon Laboratories, Inc.
http://www.silabs.com

Program Description:
-------------------

This program is a sample implementation of the AES algorithm.


Customizible Options:
---------------------

CIPHER_KEY_LENGTH in F326_AES_Parameters.h

CIPHER_KEY in F326_AES_KeyExpander.h



How To Test:
-----------

1) Compile and download the code to a C8051F326/7 device using the 
Silicon Labs IDE

2) The proper execution of the encrypt and decrypt routines can be confirmed in 
the firmware by setting a breakpoint after the InvCipher() function, which is 
called in F326_AES_Main.c. Add the variables EncryptedData and PlaintextData 
to the IDE watch window and confirm that their values are equivalent to the 
values shown in Section 3.3 of application note AN324.



Target and Tool Chain Information:
---------------------------------

Target:         C8051F326/7
Tool chain:     Keil C51 7.50 / Keil EVAL C51
                Silicon Laboratories IDE version 2.91
Project Name:   F326_AES


Command Line Options:
--------------------

Assembler : Default
Compiler  : Default
Linker    : Default 


File List:
---------

F326_AES_Cipher.c
F326_AES_Cipher.h
F326_AES_InvCipher.c
F326_AES_InvCipher.h
F326_AES_KeyExpander.c
F326_AES_KeyExpander.h
F326_AES_Main.c
F326_AES_Parameters.h
F326_AES_Sbox.h
F326_AES_Typedef.c
Readme.txt (this file)

-------------------------------------------------------------------------------
 End Of File
-------------------------------------------------------------------------------