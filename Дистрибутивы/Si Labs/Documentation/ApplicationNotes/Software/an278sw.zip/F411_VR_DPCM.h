//-----------------------------------------------------------------------------
// F411_VR_DPCM.h
//-----------------------------------------------------------------------------
// Copyright 2006 Silicon Laboratories, Inc.
// http://www.silabs.com
//
// Program Description:
//
// This file contains the DPCM encoding and decoding function
// prototypes for any c files that need to use the DPCM functions.
//
// How To Use:    See Readme.txt
//
// FID:            41X000007
// Target:         C8051F411
// Tool chain:     Keil C51 7.50 / Keil EVAL C51
//                 Silicon Laboratories IDE version 2.6
// Project Name:   F411_VR
//
// Release 1.3
//    -All changes by TP
//    -02 Feb 2006
//    -project version updated, no changes to this file
//
// Release 1.2
//    -All changes by TP
//    -21 Nov 2005
//    -project version updated, no changes to this file.
//
// Release 1.1
//    -All changes by TP
//    -16 Aug 2004
//    -project version updated, no changes to this file
//
// Release 1.0
//    -Initial Revision (TP)
//    -15 AUG 2004
//

#ifndef DPCMFUNCS_H
#define DPCMFUNCS_H

//-----------------------------------------------------------------------------
// External Function PROTOTYPES
//-----------------------------------------------------------------------------
extern unsigned char DPCM_Encode (short sample_diff);
extern short DPCM_Decode (unsigned char dpcm_code);

#endif  // DPCMFUNCS_H

//-----------------------------------------------------------------------------
// End Of File
//-----------------------------------------------------------------------------