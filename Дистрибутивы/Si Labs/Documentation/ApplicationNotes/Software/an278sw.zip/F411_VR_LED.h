//-----------------------------------------------------------------------------
// F411_VR_LED.h
//-----------------------------------------------------------------------------
// Copyright 2006 Silicon Laboratories, Inc.
// http://www.silabs.com
//
// Program Description:
//
// This file contains the function prototypes for the functions that use the
// PCA in PWM mode to brighten, dim, and flutter the LEDs.
//
// How To Use:    See Readme.txt
//
// FID:            41X000009
// Target:         C8051F411
// Tool chain:     Keil C51 7.50 / Keil EVAL C51
//                 Silicon Laboratories IDE version 2.6
// Project Name:   F411_VR
//
// Release 1.3
//    -All changes by TP
//    -02 Feb 2006
//    -project version updated, no changes to this file
//
// Release 1.2
//    -All changes by TP
//    -21 Nov 2005
//    -project version updated, no changes to this file
//
// Release 1.1
//    -All changes by TP
//    -16 Aug 2004
//    -project version updated, no changes to this file
//
// Release 1.0
//    -Initial Revision (TP)
//    -15 AUG 2004
//

#ifndef DIMMERLEDFUNCS_H
#define DIMMERLEDFUNCS_H

//-----------------------------------------------------------------------------
// LED variables needed to update the PCA PWM duty cycle
//-----------------------------------------------------------------------------
extern unsigned int LED_PWM;
extern int LED_PWM_CHANGE;
extern unsigned char *LED_DCH;
extern unsigned char LED0_DC;
extern unsigned char LED1_DC;
extern unsigned char LED2_DC;
extern unsigned char ADJ;

//-----------------------------------------------------------------------------
// External Function PROTOTYPES
//-----------------------------------------------------------------------------
extern void Dim_LED (void);
extern void Brighten_LED (void);
extern void Flutter_LED (void);

#endif  // DIMMERLEDFUNCS_H

//-----------------------------------------------------------------------------
// End Of File
//-----------------------------------------------------------------------------