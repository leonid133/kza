//-----------------------------------------------------------------------------
// F411_VR_SSTFlash.h
//-----------------------------------------------------------------------------
// Copyright 2006 Silicon Laboratories, Inc.
// http://www.silabs.com
//
// Program Description:
//
// This file contains the external prototypes for c files that will use the
// interfacing functions to the SST Flash (F411_VR_SSTFlash.c functions).
//
// How To Use:    See Readme.txt
//
// FID:            41X000011
// Target:         C8051F411
// Tool chain:     Keil C51 7.50 / Keil EVAL C51
//                 Silicon Laboratories IDE version 2.6
// Project Name:   F411_VR
//
// Release 1.3
//    -All changes by TP
//    -02 Feb 2006
//    -added Read_MEM_Init (duplicate of Read_MEM) to avoid
//       the compiler warning (multiple calls to segment)
//
// Release 1.2
//    -All changes by TP
//    -21 Nov 2005
//    -project version updated, no changes to this file.
//
// Release 1.1
//    -All changes by TP
//    -16 Aug 2004
//    -project version updated, no changes to this file
//
// Release 1.0
//    -Initial Revision (TP)
//    -15 AUG 2004
//

#ifndef SSTFLASHFUNCS_H
#define SSTFLASHFUNCS_H

//-----------------------------------------------------------------------------
// External Function PROTOTYPES
//-----------------------------------------------------------------------------
extern void SSTFlash_Init (void);

extern void Write_MEM (unsigned long address, unsigned char data_byte);
extern unsigned char Read_MEM (unsigned long address);
extern void Erase_MEM (void);
extern char ReadID_MEM (void);
extern unsigned char Read_MEM_Init (unsigned long address);

#endif  // SSTFLASHFUNCS_H

//-----------------------------------------------------------------------------
// End Of File
//-----------------------------------------------------------------------------