-------------------------------------------------------------------------------
 Readme.txt
-------------------------------------------------------------------------------

Copyright 2005 Silicon Laboratories, Inc.
http://www.silabs.com

Program Description:
-------------------

This project is the Voice Recorder firmware for the AN278 Voice Recorder
Reference Design.  This project illustrates how to record, store, and playback
voice samples using a Silicon Labs C8051F411 microcontroller.


How To Use:
----------

1) Compile the project in the Silicon Labs IDE 
2) Download the code to the voice recorder reference design board (C8051F411)
	using the Silicon Labs IDE
3) Run and debug the project.


Acceptable Warnings on Build:
----------------------------

The warning that is acceptable on building this project are:

 *** WARNING L16: UNCALLED SEGMENT, IGNORED FOR OVERLAY PROCESS
    SEGMENT: ?PR?READID_MEM?SSTFLASH
    
This warning is given because the ReadID_MEM function is provided in SSTFlash.c 
for debugging (checking for proper communication between the SST Flash and the 
'F411), but isn't used by the Voice Recorder firmware.


Target and Tool Chain Information:
---------------------------------

FID:            41X000012
Target:         C8051F41x
Tool chain:     Keil C51 7.50 / Keil EVAL C51
                Silicon Laboratories IDE version 2.6
Project Name:   Voice_Recorder


Command Line Options:
--------------------

Assembler : Default
Compiler  : Default
Linker    : Default


File List:
---------

F411_VR.wsp (Silicon Labs IDE Project workspace file)
F411_VR.c (main project source file)
F411_VR_LED.c and F411_VR_LED.h (functions that use the PCA to dim and brighten 
		the LEDs)
F411_VR_DPCM.c and F411_VR_DPCM.h (functions for DPCM compression)
F411_VR_SSTFlash.c and F411_VR_SSTFlash.h (functions to read, write, and erase the external
		SSF serial Flash on the Voice Recorder Reference Design)
F411_VR_STARTUP.A51 (startup file that includes the disabling of the Watchdog timer)
c8051F410.h (header file with SFR definitions for the 'F4xx family)
Readme.txt (this document)


Release Information:
-------------------

Release 1.3
  -Modified voice_recorder.c, SSTFlash.h, SSTFlash.c

Release 1.2
  -Modified voice_recorder.c, dpcm.c

Release 1.1
  -Modified SSTFlash.c

Release 1.0
  -Initial Release

-------------------------------------------------------------------------------
 End Of File
-------------------------------------------------------------------------------