//-----------------------------------------------------------------------------
// SPI_defs.h
//-----------------------------------------------------------------------------
// Copyright 2001 Cygnal Integrated Products, Inc.
//
// AUTH: BD
// DATE: 7 DEC 01
//
// This file defines the pins used for the SPI device.
// The SPI device is mapped to pins P0.0 - P0.3, but can be modified to map to 
// any of the available GPIO pins on the device.
//


#ifndef SPI_DEFS

#define  SPI_DEFS

sbit MOSI = P0^0;                      // Master Out / Slave In (output)
sbit MISO = P0^1;                      // Master In / Slave Out (input)
sbit SCK = P0^2;                       // Serial Clock (output)
sbit NSS = P0^3;                       // Slave Select (output to chip select)

#endif