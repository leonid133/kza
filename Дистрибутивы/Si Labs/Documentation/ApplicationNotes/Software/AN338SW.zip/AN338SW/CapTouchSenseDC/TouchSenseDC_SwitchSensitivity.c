//-----------------------------------------------------------------------------
// TouchSenseDC_SwitchSensitivity.c
//-----------------------------------------------------------------------------
// Copyright 2008 Silicon Laboratories, Inc.
// http://www.silabs.com
//
// Program Description:
//
// This program lights up the four LEDs for the four touch-sensitive switches
// when they are pressed.  After the calibration routine is performed, the four
// four switches are set to different sensitivities.
//
// Switch A (Blue)   - Least Sensitivity
// Switch B (Green)  - Slightly Sensitive
// Switch C (Red)    - More Sensitive
// Switch D (Yellow) - Most Sensitive
//
// A relaxation oscillator is implemented using an on-chip analog comparator
// with dedicated TouchSense inputs. The high-to-low transitions of the
// relaxation oscillator are counted by Timer2. The relaxation oscillator
// frequency depends on the capacitance of the touch sense trace capacitor.
// Timer2 is operated in capture mode to determine the oscillation period.
//
// How To Test:
//
// Setup:
// 1) Download code to the ToolStick TouchSense Daughter Card
//
// One Time Calibration (stored in non-volatile flash):
// 2) If the code is downloaded for the first time, the Blue LED will turn on
//    indicating the board needs to be calibrated.  If the Blue LED is not on, 
//    press the mechanical switch to start calibration.
// 3) Put your finger on touch sensitive switch A and press and release
//    the mechanical switch.
// 4) Repeat Step 2 for the remaining three switches.  The LED will turn on
//    to indicate which switch to put your finger on.
//
// Usage:
// Touch any of the four touch sensitive switches. The corresponding LED
// should light up in response.  The less sensitive switches will require
// a firmer touch to turn on the LED, and the more sensitive switches
// will require only a light touch.
//
// Target:         ToolStick TouchSense DC
// Tool chain:     Generic
// Command Line:   None
//
// Release 1.0
//    -Initial Revision (GP)
//    -18 FEB 2008
//

//-----------------------------------------------------------------------------
// Includes
//-----------------------------------------------------------------------------

#include <compiler_defs.h>
#include <C8051F930_defs.h>            // SFR declarations

//-----------------------------------------------------------------------------
// Pin Declarations
//-----------------------------------------------------------------------------

SBIT (BLUE_LED,     SFR_P1, 0);        // '0' means ON, '1' means OFF
SBIT (GREEN_LED,    SFR_P1, 1);        // '0' means ON, '1' means OFF
SBIT (RED_LED,      SFR_P1, 5);        // '0' means ON, '1' means OFF
SBIT (YELLOW_LED,   SFR_P1, 6);        // '0' means ON, '1' means OFF
SBIT (SW2,          SFR_P0, 2);        // SW2 == 0 means switch pressed

//-----------------------------------------------------------------------------
// Global CONSTANTS
//-----------------------------------------------------------------------------

#define SYSCLK       24500000          // SYSCLK frequency in Hz

#define LED_ON              0          // Macros to turn LED on and off
#define LED_OFF             1

#define SCRATCHPAD          1          // Passed to the Flash access routines
                                       // to indicate that the calibration
                                       // constants are located in scratchpad

#define CAL_ADDRESS    0x0000          // Starting address in scratchpad to
                                       // store eight bytes of calibration data

#define NUM_SWITCHES        4          // Number of touch-sensitive switches

#define BLUE                0          // Indices for various arrays
#define GREEN               1
#define RED                 2
#define YELLOW              3

//-----------------------------------------------------------------------------
// Global Variables
//-----------------------------------------------------------------------------

// Timer2 count of relaxation oscillator transitions
UU16 Switch_Timer_Count;

// Touch Switch Status: 0 means finger sensed; 1 means finger not sensed.
U8 Switch_Status[NUM_SWITCHES];       // index 0 = Blue Status
                                      // index 1 = Green Status
                                      // index 2 = Red Status
                                      // index 3 = Yellow Status

// Mux settings for CPT0MX using same order of switches as above
U8 Switch_Mux[NUM_SWITCHES] = {0xC0, 0x0C, 0xC5, 0x1C};

//-----------------------------------------------------------------------------
// Function PROTOTYPES
//-----------------------------------------------------------------------------

void SYSCLK_Init (void);
void PORT_Init (void);
void TouchSense_Init (void);

void Wait_MS(unsigned int ms);
void TouchSense_Update(void);
void Calibrate (void);
U16 Get_Calibration(U16 address);

// FLASH read/write/erase routines
void FLASH_ByteWrite (U16 addr, U8 byte, U8 SFLE);
U8   FLASH_ByteRead  (U16 addr, U8 SFLE);
void FLASH_PageErase (U16 addr, U8 SFLE);

//-----------------------------------------------------------------------------
// MAIN Routine
//-----------------------------------------------------------------------------

void main (void)
{
   PCA0MD &= ~0x40;                    // Disable the watchdog timer

   DC0CN = 0x06;                       // Set Supply Voltage to 3.0 Volts

   PORT_Init();                        // Initialize Port I/O
   SYSCLK_Init ();                     // Initialize Oscillator

   TouchSense_Init();                  // Initialize Comparator0 and
                                       // Timer2 for use with TouchSense

   if (Get_Calibration(0) == 0xFFFF)
   {
      Calibrate ();
   }

   while(1)
   {
      TouchSense_Update();             // Update switch variables

      BLUE_LED   = Switch_Status[BLUE];     // Set LED states
      GREEN_LED  = Switch_Status[GREEN];
      RED_LED    = Switch_Status[RED];
      YELLOW_LED = Switch_Status[YELLOW];

      Wait_MS(25);                     // Polling Interval

      if(!SW2)                         // If the P0.2 Switch is Pressed
      {
         while (!SW2);                 // Wait for switch to release
         Calibrate();                  // Force calibration of switches
      }
   }
}

//-----------------------------------------------------------------------------
// Support Subroutines
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// TouchSense_Update
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Measure the relaxation oscillator count for the four switches
// If any of them are below the calibration threshold, the switch is pressed
//
//-----------------------------------------------------------------------------
void TouchSense_Update (void)
{
   U8   i;
   UU16 timer_count_A, timer_count_B;

   for (i = 0; i < NUM_SWITCHES; i++)
   {
      // Set the comparator mux for the current switch
      CPT0MX = Switch_Mux[i];

      // Prepare Timer2 for the first TouchSense reading
      TF2H = 0;                           // Clear overflow flag
      while (!TF2H);                      // Wait for edge
      timer_count_A.U16 = TMR2RL;         // Record value

      // Prepare Timer2 for the second TouchSense reading
      TF2H = 0;                           // Clear overflow flag
      while(!TF2H);                       // Wait for edge
      timer_count_B.U16 = TMR2RL;         // Record value

      // Calculate the oscillation period
      Switch_Timer_Count.U16 = timer_count_B.U16 - timer_count_A.U16;

      // Update the status variable for the current switch
      if ( Switch_Timer_Count.U16 > Get_Calibration(i*2) )
      {
         Switch_Status[i] = 0;         // Switch On

      } else
      {
         Switch_Status[i] = 1;         // Switch Off
      }
   }
}

//-----------------------------------------------------------------------------
// Wait_MS
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters:
//   1) unsigned int ms - number of milliseconds of delay
//                        range is full range of integer: 0 to 65335
//
// This routine inserts a delay of <ms> milliseconds.
//-----------------------------------------------------------------------------
void Wait_MS(unsigned int ms)
{
   U8 i;

   TR0 = 0;                            // Stop Timer0

   TMOD &= ~0x0F;                      // Timer0 in 8-bit mode
   TMOD |= 0x02;

   CKCON &= ~0x03;                     // Timer0 uses a 1:48 prescaler
   CKCON |= 0x02;

   TH0 = -SYSCLK/48/10000;             // Set Timer0 Reload Value to
                                       // overflow at a rate of 10kHz

   TL0 = TH0;                          // Init Timer0 low byte to the
                                       // reload value

   TF0 = 0;                            // Clear Timer0 Interrupt Flag
   ET0 = 0;                            // Timer0 interrupt disabled
   TR0 = 1;                            // Timer0 on

   while(ms--)                         // For each ms, wait for Timer
   {                                   // to overflow 10 times
      for(i = 0; i < 10; i++)
      {
         TF0 = 0;
         while(!TF0);
      }
   }

   TF0 = 0;                            // Clear the Timer interrupt flag
}


//-----------------------------------------------------------------------------
// Calibrate
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// This routine will store the touch value in non-volatile Flash memory as
// the calibration threshold for the switch SW21.
//
// 1. Place a finger on the touch switch SW21, and hold it there.
// 2. Press switch SW2 (P0.7) for >1 sec and release using another finger.
// 3. Remove finger from SW21.
//-----------------------------------------------------------------------------
void Calibrate (void)
{
   U8  EA_Save, i;

   U16 SW_Open_Count[NUM_SWITCHES];
   U16 SW_Closed_Count[NUM_SWITCHES];
   UU16 SW_Calibration[NUM_SWITCHES];
   UU16 timer_count_A, timer_count_B;

   // Turn off all the LEDs
   BLUE_LED   = LED_OFF;
   GREEN_LED  = LED_OFF;
   RED_LED    = LED_OFF;
   YELLOW_LED = LED_OFF;

   // Count the number of oscillator cycles with all switches not pressed
   for (i = 0; i < NUM_SWITCHES; i++)
   {
      // Set the comparator mux for the current switch
      CPT0MX = Switch_Mux[i];

      Wait_MS (1);

      // Prepare Timer2 for the first TouchSense reading
      TF2H = 0;                           // Clear overflow flag
      while (!TF2H);                      // Wait for overflow
      timer_count_A.U16 = TMR2RL;         // Record value

      // Prepare Timer2 for the second TouchSense reading
      TF2H = 0;                           // Clear overflow flag
      while (!TF2H);                      // Wait for overflow
      timer_count_B.U16 = TMR2RL;         // Record value

      // Calculate the oscillation period
      SW_Open_Count[i] = timer_count_B.U16 - timer_count_A.U16;
   }

   for (i = 0; i < NUM_SWITCHES; i++)
   {
      // Set the comparator mux for the current switch
      CPT0MX = Switch_Mux[i];

      Wait_MS (1);

      // Turn on the LED for the switch that is currently being calibrated
      if (i == 0) { BLUE_LED   = LED_ON; }
      if (i == 1) { GREEN_LED  = LED_ON; BLUE_LED  = LED_OFF; }
      if (i == 2) { RED_LED    = LED_ON; GREEN_LED = LED_OFF; }
      if (i == 3) { YELLOW_LED = LED_ON; RED_LED   = LED_OFF; }

      // Wait for the mechanical switch
      while (SW2);                        // Wait till switch is pressed
      while (!SW2);                       // Wait till switch released

      // Prepare Timer2 for the first TouchSense reading
      TF2H = 0;                           // Clear overflow flag
      while (!TF2H);                      // Wait for overflow
      timer_count_A.U16 = TMR2RL;         // Record value

      // Prepare Timer2 for the second TouchSense reading
      TF2H = 0;                           // Clear overflow flag
      while (!TF2H);                      // Wait for overflow
      timer_count_B.U16 = TMR2RL;         // Record value

      // Calculate the oscillation period
      SW_Closed_Count[i] = timer_count_B.U16 - timer_count_A.U16;
   }

   YELLOW_LED = LED_OFF;

   // Calculate the threshold value for each switch; Each switch is calibrated
   // with a different sensitivity.  This could easily be rolled into a loop,
   // but it is explicitly written to show how the calibration is different.

   // Least Sensitive
   SW_Calibration[BLUE].U16   = SW_Open_Count[BLUE] +
                                ((SW_Closed_Count[BLUE] - SW_Open_Count[BLUE]) * 9 / 10);

   // Slightly Sensitive
   SW_Calibration[GREEN].U16  = SW_Open_Count[GREEN] +
                                ((SW_Closed_Count[GREEN] - SW_Open_Count[GREEN]) * 3 / 5);

   // More Sensitive
   SW_Calibration[RED].U16    = SW_Open_Count[RED] +
                                ((SW_Closed_Count[RED] - SW_Open_Count[RED]) * 2 / 5);

   // Most Sensitive
   SW_Calibration[YELLOW].U16 = SW_Open_Count[YELLOW] +
                                ((SW_Closed_Count[YELLOW] - SW_Open_Count[YELLOW]) * 1 / 10);


   EA_Save = IE;                       // Preserve EA
   EA = 0;                             // Disable interrupts

   // Erase the scratchpad
   FLASH_PageErase (0x0000, SCRATCHPAD);

   // Write the calibration values to the Scratchpad area of Flash
   for (i = 0; i < NUM_SWITCHES; i++)
   {
      FLASH_ByteWrite ((U16)(CAL_ADDRESS+2*i+MSB), SW_Calibration[i].U8[MSB], SCRATCHPAD);
      FLASH_ByteWrite ((U16)(CAL_ADDRESS+2*i+LSB), SW_Calibration[i].U8[LSB], SCRATCHPAD);
   }

   if ((EA_Save & 0x80) != 0)          // Restore EA
   {
      EA = 1;
   }

   // Blink the LEDs to indicate calibration is complete
   Wait_MS(250);
   BLUE_LED   = LED_ON;
   GREEN_LED  = LED_ON;
   RED_LED    = LED_ON;
   YELLOW_LED = LED_ON;
   Wait_MS(250);
   BLUE_LED   = LED_OFF;
   GREEN_LED  = LED_OFF;
   RED_LED    = LED_OFF;
   YELLOW_LED = LED_OFF;
   Wait_MS(250);
   BLUE_LED   = LED_ON;
   GREEN_LED  = LED_ON;
   RED_LED    = LED_ON;
   YELLOW_LED = LED_ON;
   Wait_MS(250);
   BLUE_LED   = LED_OFF;
   GREEN_LED  = LED_OFF;
   RED_LED    = LED_OFF;
   YELLOW_LED = LED_OFF;
   Wait_MS(250);
   BLUE_LED   = LED_ON;
   GREEN_LED  = LED_ON;
   RED_LED    = LED_ON;
   YELLOW_LED = LED_ON;
   Wait_MS(1000);
}

//-----------------------------------------------------------------------------
// Get_Calibration
//-----------------------------------------------------------------------------
//
// Return Value :
//   1) unsigned int   -  calibration value
//                        range is full range of integer: 0 to 65335
// Parameters: None
//
// This routine reads the calibration value from Flash
//-----------------------------------------------------------------------------
U16 Get_Calibration(U16 address)
{
   UU16 cal_value;

   cal_value.U8[MSB] = FLASH_ByteRead ((U16)(address+MSB),  SCRATCHPAD);
   cal_value.U8[LSB] = FLASH_ByteRead ((U16)(address+LSB),  SCRATCHPAD);

   return cal_value.U16;
}

//-----------------------------------------------------------------------------
// Flash Subroutines
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// FLASH_ByteWrite
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   :
//   1) FLADDR addr - address of the byte to write to
//                    valid range is from 0x0000 to 0xFBFF for 64K devices
//                    valid range is from 0x0000 to 0x7FFF for 32K devices
//   2) char byte - byte to write to Flash.
//
// This routine writes <byte> to the linear FLASH address <addr>.
//-----------------------------------------------------------------------------
void FLASH_ByteWrite (U16 addr, U8 byte, U8 SFLE)
{
   U8 EA_Save = IE;                    // Preserve EA
   SEGMENT_VARIABLE_SEGMENT_POINTER (pwrite, U8, xdata, data);

   EA = 0;                             // Disable interrupts

   VDM0CN = 0x80;                      // Enable VDD monitor


   RSTSRC = 0x06;                      // Enable VDD monitor as a reset source
                                       // Leave missing clock detector enabled

   pwrite = (char xdata *) addr;

   FLKEY  = 0xA5;                      // Key Sequence 1
   FLKEY  = 0xF1;                      // Key Sequence 2
   PSCTL |= 0x01;                      // PSWE = 1

   if(SFLE)
   {
      PSCTL |= 0x04;                   // Access Scratchpad
   }

   VDM0CN = 0x80;                      // Enable VDD monitor


   RSTSRC = 0x02;                      // Enable VDD monitor as a reset source

   *pwrite = byte;                     // Write the byte

   PSCTL &= ~0x05;                     // SFLE = 0; PSWE = 0

   if ((EA_Save & 0x80) != 0)          // Restore EA
   {
      EA = 1;
   }
}

//-----------------------------------------------------------------------------
// FLASH_ByteRead
//-----------------------------------------------------------------------------
//
// Return Value :
//      unsigned char - byte read from Flash
// Parameters   :
//   1) FLADDR addr - address of the byte to read to
//                    valid range is from 0x0000 to 0xFBFF for 64K devices
//                    valid range is from 0x0000 to 0x7FFF for 32K devices
//
// This routine reads a <byte> from the linear FLASH address <addr>.
//-----------------------------------------------------------------------------
U8 FLASH_ByteRead (U16 addr, U8 SFLE)
{
   U8 EA_Save = IE;                    // Preserve EA

   SEGMENT_VARIABLE_SEGMENT_POINTER (pread, U8, code, data);
   //char code * data pread;             // FLASH read pointer

   unsigned char byte;

   EA = 0;                             // Disable interrupts

   pread = (char code *) addr;

   if(SFLE)
   {
      PSCTL |= 0x04;                   // Access Scratchpad
   }

   byte = *pread;                      // Read the byte

   PSCTL &= ~0x04;                     // SFLE = 0

   if ((EA_Save & 0x80) != 0)          // Restore EA
   {
      EA = 1;
   }

   return byte;
}

//-----------------------------------------------------------------------------
// FLASH_PageErase
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   :
//   1) FLADDR addr - address of any byte in the page to erase
//                    valid range is from 0x0000 to 0xFBFF for 64K devices
//                    valid range is from 0x0000 to 0x7FFF for 32K devices
//
// This routine erases the FLASH page containing the linear FLASH address
// <addr>.  Note that the page of Flash containing the Lock Byte cannot be
// erased if the Lock Byte is set.
//
//-----------------------------------------------------------------------------
void FLASH_PageErase (U16 addr, U8 SFLE)
{
   U8 EA_Save = IE;                    // Preserve EA

   SEGMENT_VARIABLE_SEGMENT_POINTER (pwrite, U8, xdata, data);
   //unsigned char xdata * data pwrite;// FLASH write pointer

   EA = 0;                             // Disable interrupts

   VDM0CN = 0x80;                      // Enable VDD monitor

   RSTSRC = 0x06;                      // Enable VDD monitor as a reset source
                                       // Leave missing clock detector enabled

   pwrite = (char xdata *) addr;

   FLKEY  = 0xA5;                      // Key Sequence 1
   FLKEY  = 0xF1;                      // Key Sequence 2
   PSCTL |= 0x03;                      // PSWE = 1; PSEE = 1

   if(SFLE)
   {
      PSCTL |= 0x04;                   // Access Scratchpad
   }

   VDM0CN = 0x80;                      // Enable VDD monitor

   RSTSRC = 0x02;                      // Enable VDD monitor as a reset source
   *pwrite = 0;                        // Initiate page erase

   PSCTL &= ~0x07;                     // SFLE = 0; PSWE = 0; PSEE = 0

   if ((EA_Save & 0x80) != 0)          // Restore EA
   {
      EA = 1;
   }
}



//-----------------------------------------------------------------------------
// Initialization Subroutines
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// TouchSense_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Configure Comparator 0 and Timer 2 for use with Touchsense.
//-----------------------------------------------------------------------------
void TouchSense_Init (void)
{
   // Initialize Comparator0
   CPT0CN = 0x8F;                      // Enable Comparator0; clear flags
                                       // select maximum hysterisis
   CPT0MD = 0x0F;                      // Comparator interrupts disabled,
                                       // lowest power mode

   CPT0MX = Switch_Mux[BLUE];          // Set mux initially to Blue switch

   // Initialize Timer2
   CKCON |= 0x10;                      // Timer2 counts system clocks
   TMR2CN = 0x16;                      // Capture mode enabled, capture
                                       // trigger is Comparator0.
                                       // Start timer (TR2 = 1).

   // Set all four switches to not pressed
   Switch_Status[BLUE]   = 1;
   Switch_Status[GREEN]  = 1;
   Switch_Status[RED]    = 1;
   Switch_Status[YELLOW] = 1;
}

//-----------------------------------------------------------------------------
// PORT_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Configure the Crossbar and GPIO ports.
//
// P0.0   analog    open-drain    Touch Sense Switch
// P0.1   analog    open-drain    Touch Sense Switch
// P0.2   digital   open-drain    Switch P0.2
// P0.3   analog    open-drain    Touch Sense Switch
//
// P1.0   digital   open-drain    Blue LED
// P1.1   digital   open-drain    Green LED
// P1.2   analog    open-drain    Touch Sense Switch
// P1.5   digital   open-drain    Red LED
// P1.6   digital   open-drain    Yellow LED
//
//-----------------------------------------------------------------------------
void PORT_Init (void)
{
   // Configure TouchSense switches
   P0MDIN &= ~0x0B;                    // P0.0, P0.1, P0.3 is analog
   P0MDOUT &= ~0x0B;                   // P0.0, P0.1, P0.3 is open-drain
   P0      |=  0x0B;                   // P0.0, P0.1, P0.3 latch -> '1'

   P1MDIN &= ~0x04;                    // P1.2 is analog
   P1MDOUT &= ~0x04;                   // P1.2 is open-drain
   P1      |=  0x04;                   // P1.2 latch -> '1'

   // Configure Hardware Switch
   P0MDIN |= 0x04;                     // P0.2 is digital
   P0MDOUT &= ~0x04;                   // P0.2 is open-drain
   P0     |= 0x04;                     // Set P0.2 latch -> '1'

   // Configure LEDs
   P1MDIN  |= 0x63;                    // 1.0, 1.1, P1.5, P1.6 are digital
   P1MDOUT |= 0x63;                    // 1.0, 1.1, P1.5, P1.6 are push-pull

   // Configure Crossbar
   XBR2    = 0x40;                     // Enable crossbar and weak pull-ups
}


//-----------------------------------------------------------------------------
// SYSCLK_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// This routine initializes the system clock to use the internal precision
// oscillator at its maximum frequency and enables the missing clock
// detector.
//
//-----------------------------------------------------------------------------

void SYSCLK_Init (void)
{
   OSCICN |= 0x80;                     // Enable the precision internal osc.

   RSTSRC = 0x06;                      // Enable missing clock detector and
                                       // leave VDD Monitor enabled.

   CLKSEL = 0x00;                      // Select precision internal osc.
                                       // divided by 1 as the system clock
}

//-----------------------------------------------------------------------------
// End Of File
//-----------------------------------------------------------------------------