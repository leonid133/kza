//-----------------------------------------------------------------------------
// F300_TCRTC_Clock.h
//-----------------------------------------------------------------------------
// Copyright 2006 Silicon Laboratories, Inc.
// http://www.silabs.com
//
// Program Description:
//
// See Readme.txt
//
// How To Test:    See Readme.txt
//
//
// FID:            30X000012
// Target:         C8051F300
// Tool chain:     Keil
//                 Silicon Laboratories IDE version 2.71
// Command Line:   See Readme.txt
// Project Name:   F300_TempCompRTC_RD
//
// Release 1.0
//    -Initial Revision (SYRO)
//    -12 MAY 2006
//

#ifndef  __tcrtc_clock_h__
#define  __tcrtc_clock_h__

//-----------------------------------------------------------------------------
// Global CONSTANTS
//-----------------------------------------------------------------------------
#define Set12_24 	0x40
#define AM_PM 		0x20

//-----------------------------------------------------------------------------
// Global VARIABLES
//-----------------------------------------------------------------------------
extern unsigned long idata accumulative;

//-----------------------------------------------------------------------------
// Function PROTOTYPES
//-----------------------------------------------------------------------------
void IncRTC(void);                          // Increments RTC registers

//-----------------------------------------------------------------------------
// Extern Function PROTOTYPES
//-----------------------------------------------------------------------------
extern void calc_ppm(void);
extern void compensate_RTC(void);
extern unsigned char Bin2BCD (unsigned char a);
extern void BCD_Time(void);

#endif


//-----------------------------------------------------------------------------
// end of tcrtc_clock.h
//-----------------------------------------------------------------------------