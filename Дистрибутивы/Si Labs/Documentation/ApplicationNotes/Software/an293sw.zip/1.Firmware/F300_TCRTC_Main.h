//-----------------------------------------------------------------------------
// F300_TCRTC_Main.h
//-----------------------------------------------------------------------------
// Copyright 2006 Silicon Laboratories, Inc.
// http://www.silabs.com
//
// Program Description:
//
// See Readme.txt
//
// How To Test:    See Readme.txt
//
//
// FID:            30X000008
// Target:         C8051F300
// Tool chain:     Keil
//                 Silicon Laboratories IDE version 2.71
// Command Line:   See Readme.txt
// Project Name:   F300_TempCompRTC_RD
//
// Release 1.0
//    -Initial Revision (SYRO)
//    -12 MAY 2006
//

#ifndef  __tcrtc_main_h__
#define  __tcrtc_main_h__

                                            
#define SYSCLK       24500000               // SYSCLK frequency in Hz
#define XTALCLK		 32768			        // External osc. frequency in Hz
#define BAUDRATE     9600                   // Baud rate of UART in bps
#define NVRAM_ADDR	 0x1A00			        // FLASH memory address where the 
                                            // RTC NVRAM is stored; should be 
									        // the begining of a FLASH page

// pointer to FLASH memory for NVRAM data; allocates an entire FLASH page to be
// sure that an erase doesn't change code space
unsigned char code FLASH_NVRAM[512] _at_ NVRAM_ADDR;

unsigned char idata RTC_REG[8];			    // the emulated RTC registers
unsigned char idata RTC_NVRAM[56];		    // the emulated RTC NVRAM
unsigned char idata WORD_ADDR;			    // the emulated RTC register pointer

bit flash_write;                            // flag for saving NVRAM buffer in
                                            // FLASH memory 
bit reg_write;                              // flag set when RTC registers have
                                            // been written
#ifdef _UART_

unsigned char code day_names[7][10] = {
    "Sunday", "Monday", "Tuesday", "Wednesday", 
    "Thursday", "Friday", "Saturday" };

unsigned char uart_cnt;                     // counts the characters received
                                            // on UART
unsigned char uart_len;                     // number of bytes of data to be
                                            // received or transmitted
unsigned char uart_sent;                    // number of bytes of data sent
bit uart_read, uart_write;                  // flags indicating the type of
                                            // operation (read or write)
bit uart_display;                           // flag set when sending data on
                                            // UART every second
extern int idata temperature;               // the temperature

#else

bit smb_cnt;					            // flag indicating which is the 
                                            // first data byte received on SMBus
#endif

extern unsigned int code TEMP_OFFSET;       // temperature sensor offset value
extern bit min_changed;                     // flag set when minutes change
extern bit day_changed;                     // flag set when days change

//-----------------------------------------------------------------------------
// Function PROTOTYPES
//-----------------------------------------------------------------------------
void PORT_Init(void);                       // Configure the Crossbar and GPIO 
                                            // ports
void OSC_Config (void);                     // Oscillator Configuration
void Timer0_Init(void);                 
void Timer1_Init(void);                     // Timer1_Init
void Timer2_Init(void);                     // Timer2_Init
void ADC0_Init (void);                      // AD converter configuration
void RTC_Init(void);                        // Initializes RTC registers and 
                                            // NVRAM buffer

void Interrupt_Init(void);                  // Initializes interrupts

void T0_WaitMS (unsigned ms);               // Delay for a specified number of ms

#ifdef _UART_

void UART_Init(void);                       // Configure UART0

unsigned char UART_send(void);              // Returns the data byte to be
                                            // transmitted on UART

void UART_rec(unsigned char c);             // Updates the RTC reg. and NVRAM 
                                            // with data received from UART
void UART_Print(void);

#else

void SMBus_Init(void);                      // SMBUS interface configuration

#endif


//-----------------------------------------------------------------------------
// Extern Function PROTOTYPES
//-----------------------------------------------------------------------------
extern void calibrate (void);
extern void calc_ppm (void);

#endif


//-----------------------------------------------------------------------------
// end of tcrtc_main.h
//-----------------------------------------------------------------------------