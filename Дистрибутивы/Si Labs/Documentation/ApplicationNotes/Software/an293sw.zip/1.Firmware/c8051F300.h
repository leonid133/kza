//-----------------------------------------------------------------------------
// C8051F300.h
//-----------------------------------------------------------------------------
// Copyright 2005 Silicon Laboratories, Inc.
// http://www.silabs.com
//
// Program Description:
//
// Register/bit definitions for the C8051F30x product family.
//
//
// FID:            30X000002
// Target:         C8051F300, 'F301, F302, 'F303, 'F304, 'F305
// Tool chain:     Keil
// Command Line:   None
//
// Release 1.2
//    -All changes by GP
//    -13 DEC 2005
//    -Converted file to new coding guidelines
//    -Added #defines for interrupt priorities
//    -Added #ifndef/#define to allow multiple includes of file
//
// Release 1.11
//    -11 JUL 02
//    -Latest release before new firmware coding standard
//

//-----------------------------------------------------------------------------
// Header File Preprocessor Directive
//-----------------------------------------------------------------------------

#ifndef C8051F300_H
#define C8051F300_H

//-----------------------------------------------------------------------------
// Byte Registers
//-----------------------------------------------------------------------------

sfr P0       = 0x80;                   // Port 0
sfr SP       = 0x81;                   // Stack pointer
sfr DPL      = 0x82;                   // Data pointer - low byte
sfr DPH      = 0x83;                   // Data pointer - high byte
sfr PCON     = 0x87;                   // Power control
sfr TCON     = 0x88;                   // Timer control
sfr TMOD     = 0x89;                   // Timer mode
sfr TL0      = 0x8A;                   // Timer 0 - low byte
sfr TL1      = 0x8B;                   // Timer 1 - low byte
sfr TH0      = 0x8C;                   // Timer 0 - high byte
sfr TH1      = 0x8D;                   // Timer 1 - high byte
sfr CKCON    = 0x8E;                   // Clock control
sfr PSCTL    = 0x8F;                   // Program store R/W control
sfr SCON0    = 0x98;                   // Serial port 0 control
sfr SBUF0    = 0x99;                   // Serial port 0 buffer
sfr CPT0MD   = 0x9D;                   // Comparator0 mode
sfr CPT0MX   = 0x9F;                   // Comparator0 mux
sfr P0MDOUT  = 0xA4;                   // Port 0 output mode
sfr IE       = 0xA8;                   // Interrupt enable
sfr OSCXCN   = 0xB1;                   // External oscillator control
sfr OSCICN   = 0xB2;                   // Internal oscillator control
sfr OSCICL   = 0xB3;                   // Internal oscillator calibration
sfr FLKEY    = 0xB7;                   // Flash lock & key
sfr FLSCL    = 0xB6;                   // Flash scale
sfr IP       = 0xB8;                   // Interrupt priority
sfr AMX0SL   = 0xBB;                   // ADC0 mux channel selection
sfr ADC0CF   = 0xBC;                   // ADC0 configuration
sfr ADC0     = 0xBE;                   // ADC0 data
sfr SMB0CN   = 0xC0;                   // SMBus0 control
sfr SMB0CF   = 0xC1;                   // SMBus0 configuration
sfr SMB0DAT  = 0xC2;                   // SMBus0 data
sfr ADC0GT   = 0xC4;                   // ADC0 greater-than
sfr ADC0LT   = 0xC6;                   // ADC0 less-than
sfr TMR2CN   = 0xC8;                   // Timer2 control
sfr TMR2RLL  = 0xCA;                   // Timer2 reload low
sfr TMR2RLH  = 0xCB;                   // Timer2 reload high
sfr TMR2L    = 0xCC;                   // Timer2 low byte
sfr TMR2H    = 0xCD;                   // Timer2 high byte
sfr PSW      = 0xD0;                   // Program status word
sfr REF0CN   = 0xD1;                   // Voltage reference 0 control
sfr PCA0CN   = 0xD8;                   // PCA0 control
sfr PCA0MD   = 0xD9;                   // PCA0 mode
sfr PCA0CPM0 = 0xDA;                   // PCA0 module 0 mode
sfr PCA0CPM1 = 0xDB;                   // PCA0 module 1 mode
sfr PCA0CPM2 = 0xDC;                   // PCA0 module 2 mode
sfr ACC      = 0xE0;                   // Accumulator
sfr XBR0     = 0xE1;                   // Crossbar configuration register 0
sfr XBR1     = 0xE2;                   // Crossbar configuration register 1
sfr XBR2     = 0xE3;                   // Crossbar configuration register 2
sfr IT01CF   = 0xE4;                   // INT0/INT1 configuration
sfr EIE1     = 0xE6;                   // Extended interrupt enable 1
sfr ADC0CN   = 0xE8;                   // ADC0 control
sfr PCA0CPL1 = 0xE9;                   // Capture/compare module1 - Low byte
sfr PCA0CPH1 = 0xEA;                   // Capture/compare module1 - High byte
sfr PCA0CPL2 = 0xEB;                   // Capture/compare module2 - Low byte
sfr PCA0CPH2 = 0xEC;                   // Capture/compare module2 - High byte
sfr RSTSRC   = 0xEF;                   // Reset source
sfr B        = 0xF0;                   // B register
sfr P0MDIN   = 0xF1;                   // Port 0 input mode register
sfr EIP1     = 0xF6;                   // Extended interrupt priority 1
sfr CPT0CN   = 0xF8;                   // Comparator 0 control
sfr PCA0L    = 0xF9;                   // PCA0 counter register low byte
sfr PCA0H    = 0xFA;                   // PCA0 counter register high byte
sfr PCA0CPL0 = 0xFB;                   // Capture/compare module0 - Low byte
sfr PCA0CPH0 = 0xFC;                   // Capture/compare module0 - High byte

//-----------------------------------------------------------------------------
// Bit Definitions
//-----------------------------------------------------------------------------

//  TCON  0x88
sbit TF1     = TCON ^ 7;               // Timer 1 overflow flag
sbit TR1     = TCON ^ 6;               // Timer 1 on/off control
sbit TF0     = TCON ^ 5;               // Timer 0 overflow flag
sbit TR0     = TCON ^ 4;               // Timer 0 on/off control
sbit IE1     = TCON ^ 3;               // Ext interrupt 1 edge flag
sbit IT1     = TCON ^ 2;               // Ext interrupt 1 type
sbit IE0     = TCON ^ 1;               // Ext interrupt 0 edge flag
sbit IT0     = TCON ^ 0;               // Ext interrupt 0 type

//  SCON0  0x98
sbit S0MODE  = SCON0 ^ 7;              // Serial mode control bit 0
                                       // Bit 6 not used
sbit MCE0    = SCON0 ^ 5;              // Multiprocessor communication enable
sbit REN0    = SCON0 ^ 4;              // Receive enable
sbit TB80    = SCON0 ^ 3;              // Transmit bit 8
sbit RB80    = SCON0 ^ 2;              // Receive bit 8
sbit TI0     = SCON0 ^ 1;              // Transmit interrupt flag
sbit RI0     = SCON0 ^ 0;              // Receive interrupt flag

//  IE  0xA8
sbit EA      = IE ^ 7;                 // Global interrupt enable
                                       // Bit 6 not used
sbit ET2     = IE ^ 5;                 // Timer2 interrupt enable
sbit ES0     = IE ^ 4;                 // UART0 interrupt enable
sbit ET1     = IE ^ 3;                 // Timer 1 interrupt enable
sbit EX1     = IE ^ 2;                 // External interrupt 1 enable
sbit ET0     = IE ^ 1;                 // Timer 0 interrupt enable
sbit EX0     = IE ^ 0;                 // External interrupt 0 enable

//  IP  0xB8
                                       // Bit 7 not used
                                       // Bit 6 not used
sbit PT2     = IP ^ 5;                 // Timer2 priority
sbit PS0     = IP ^ 4;                 // UART0 priority
sbit PT1     = IP ^ 3;                 // Timer 1 priority
sbit PX1     = IP ^ 2;                 // External interrupt 1 priority
sbit PT0     = IP ^ 1;                 // Timer 0 priority
sbit PX0     = IP ^ 0;                 // External interrupt 0 priority

// SMB0CN 0xC0
sbit MASTER  = SMB0CN ^ 7;             // Master/slave indicator
sbit TXMODE  = SMB0CN ^ 6;             // Transmit mode indicator
sbit STA     = SMB0CN ^ 5;             // Start flag
sbit STO     = SMB0CN ^ 4;             // Stop flag
sbit ACKRQ   = SMB0CN ^ 3;             // Acknowledge request
sbit ARBLOST = SMB0CN ^ 2;             // Arbitration lost indicator
sbit ACK     = SMB0CN ^ 1;             // Acknowledge flag
sbit SI      = SMB0CN ^ 0;             // SMBus0 interrupt flag

//  TMR2CN 0xC8
sbit TF2H    = TMR2CN ^ 7;             // Timer2 high byte overflow flag
sbit TF2L    = TMR2CN ^ 6;             // Timer2 low byte overflow flag
sbit TF2LEN  = TMR2CN ^ 5;             // Timer2 low byte interrupt enable
                                       // Bit 4 not used
sbit T2SPLIT = TMR2CN ^ 3;             // Timer2 split mode enable
sbit TR2     = TMR2CN ^ 2;             // Timer2 on/off control
                                       // Bit 1 not used
sbit T2XCLK  = TMR2CN ^ 0;             // Timer2 external clock select

//  PSW 0xD0
sbit CY      = PSW ^ 7;                // Carry flag
sbit AC      = PSW ^ 6;                // Auxiliary carry flag
sbit F0      = PSW ^ 5;                // User flag 0
sbit RS1     = PSW ^ 4;                // Register bank select 1
sbit RS0     = PSW ^ 3;                // Register bank select 0
sbit OV      = PSW ^ 2;                // Overflow flag
sbit F1      = PSW ^ 1;                // User flag 1
sbit P       = PSW ^ 0;                // Accumulator parity flag

// PCA0CN 0xD8H
sbit CF      = PCA0CN ^ 7;             // PCA0 counter overflow flag
sbit CR      = PCA0CN ^ 6;             // PCA0 counter run control
                                       // Bit 5 not used
                                       // Bit 4 not used
                                       // Bit 3 not used
sbit CCF2    = PCA0CN ^ 2;             // PCA0 module 2 capture/compare flag
sbit CCF1    = PCA0CN ^ 1;             // PCA0 module 1 capture/compare flag
sbit CCF0    = PCA0CN ^ 0;             // PCA0 module 0 capture/compare flag

// ADC0CN 0xE8H
sbit AD0EN   = ADC0CN ^ 7;             // ADC0 enable
sbit AD0TM   = ADC0CN ^ 6;             // ADC0 track mode
sbit AD0INT  = ADC0CN ^ 5;             // ADC0 Conversion Complete flag
sbit AD0BUSY = ADC0CN ^ 4;             // ADC0 busy flag
sbit AD0WINT = ADC0CN ^ 3;             // ADC0 window compare interrupt flag
sbit AD0CM2  = ADC0CN ^ 2;             // ADC0 conversion mode select 2
sbit AD0CM1  = ADC0CN ^ 1;             // ADC0 conversion mode select 1
sbit AD0CM0  = ADC0CN ^ 0;             // ADC0 conversion mode select 0

// CPT0CN 0xF8H
sbit CP0EN   = CPT0CN ^ 7;             // Comparator0 enable
sbit CP0OUT  = CPT0CN ^ 6;             // Comparator0 output state
sbit CP0RIF  = CPT0CN ^ 5;             // Comparator0 rising-edge flag
sbit CP0FIF  = CPT0CN ^ 4;             // Comparator0 falling-edge flag
sbit CP0HYP1 = CPT0CN ^ 3;             // Comparator0 positive hysteresis 1
sbit CP0HYP0 = CPT0CN ^ 2;             // Comparator0 positive hysteresis 0
sbit CP0HYN1 = CPT0CN ^ 1;             // Comparator0 negative hysteresis 1
sbit CP0HYN0 = CPT0CN ^ 0;             // Comparator0 negative hysteresis 0

//-----------------------------------------------------------------------------
// Interrupt Priorities
//-----------------------------------------------------------------------------

#define INTERRUPT_INT0             0   // External Interrupt 0
#define INTERRUPT_TIMER0           1   // Timer0 Overflow
#define INTERRUPT_INT1             2   // External Interrupt 1
#define INTERRUPT_TIMER1           3   // Timer1 Overflow
#define INTERRUPT_UART0            4   // Serial Port 0
#define INTERRUPT_TIMER2           5   // Timer2 Overflow
#define INTERRUPT_SMBUS0           6   // SMBus0 Interface
#define INTERRUPT_ADC0_WINDOW      7   // ADC0 Window Comparison
#define INTERRUPT_ADC0_EOC         8   // ADC0 End Of Conversion
#define INTERRUPT_PCA0             9   // PCA0 Peripheral
#define INTERRUPT_COMPARATOR0      10  // Comparator0
#define INTERRUPT_COMPARATOR1      11  // Comparator1

//-----------------------------------------------------------------------------
// Header File Preprocessor Directive
//-----------------------------------------------------------------------------

#endif                                 // #define C8051F300_H

//-----------------------------------------------------------------------------
// End Of File
//-----------------------------------------------------------------------------