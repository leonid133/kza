//-----------------------------------------------------------------------------
// F300_TCRTC_Inteface.h
//-----------------------------------------------------------------------------
// Copyright 2006 Silicon Laboratories, Inc.
// http://www.silabs.com
//
// Program Description:
//
// See Readme.txt
//
// How To Test:    See Readme.txt
//
//
// FID:            30X000010
// Target:         C8051F300
// Tool chain:     Keil
//                 Silicon Laboratories IDE version 2.71
// Command Line:   See Readme.txt
// Project Name:   F300_TempCompRTC_RD
//
// Release 1.0
//    -Initial Revision (SYRO)
//    -12 MAY 2006
//


#ifndef  __tcrtc_interface_h__
#define  __tcrtc_interface_h__

#define _DEBUG_                             // in debug mode temperature and
                                            // accumulative are available
                                            // between addresses 0x40 and 0x45

//#define	_UART_                              // to use UART interface instead of
                                            // SMBus
                                            


//-----------------------------------------------------------------------------
// Global Constants
//-----------------------------------------------------------------------------
#ifndef _UART_

#define  SMB_FREQUENCY  10000               // Target SMBus frequency
#define  WRITE          0x00                // SMBus WRITE command
#define  READ           0x01                // SMBus READ command
#define  SLA_ADD        0xD0                // Device addresses (7 bits, lsb is a
                                            // don't care)
// Status vector - top 4 bits only
#define  SMB_SRADD      0x20                // (SR) slave address received
                                            // (also could be a lost arbitration)
#define  SMB_SRSTO      0x10                // (SR) STOP detected, or lost
                                            // arbitration
#define  SMB_SRDB       0x00                // (SR) data byte received, or lost
                                            // arbitration
#define  SMB_STDB       0x40                // (ST) data byte transmitted
#define  SMB_STSTO      0x50                // (ST) STOP detected

#endif


//-----------------------------------------------------------------------------
// RTC Registers
//-----------------------------------------------------------------------------
#define RTC_SEC         RTC_REG[0]          // RTC second
#define RTC_MIN         RTC_REG[1]          // RTC minute
#define RTC_HOUR        RTC_REG[2]          // RTC hour
#define RTC_DAY         RTC_REG[3]          // RTC day of week
#define RTC_DATE        RTC_REG[4]          // RTC day of month
#define RTC_MONTH       RTC_REG[5]          // RTC month
#define RTC_YEAR        RTC_REG[6]          // RTC year


//-----------------------------------------------------------------------------
// Extern Declarations
//-----------------------------------------------------------------------------
extern unsigned char Seconds;               // current seconds
extern unsigned char Minutes;               // current minutes
extern unsigned char Hours;                 // current hours
extern unsigned char Date;                  // current day of week
extern unsigned char Month;                 // current month
extern unsigned char Year;                  // current year
extern unsigned char Day;                   // current day

extern int idata temperature;               // ambient temperature
extern unsigned long idata accumulative;    // ppm accumulative

extern unsigned long time_remainder;        // remainder after sec compensation
extern unsigned long ppm_remainder;

extern unsigned char code  FLASH_NVRAM[512];// allocates an entire FLASH page
                                            // to be sure that an erase doesn't
                                            // change code space

extern unsigned char idata RTC_REG[8];		// the emulated RTC registers
extern unsigned char idata RTC_NVRAM[56];	// the emulated RTC NVRAM
extern unsigned char idata WORD_ADDR;		// the emulated RTC register pointer

extern bit flash_write;
extern bit reg_write;

//-----------------------------------------------------------------------------
// Function PROTOTYPES
//-----------------------------------------------------------------------------
void FLASH_Write (char *dest, 
char *src, unsigned num);                   // write data to FLASH memory

void FLASH_Erase(char *dest);               // erase a 512 bytes FLASH page

unsigned char RTC_Read(void);               // Read a byte from RTC registers
                                            // or NVRAM
void RTC_Write(unsigned char value);        // Write a byte to RTC registers
                                            // or NVRAM

void NVRAM_Update(void);                    // Saves the contents of emulated
                                            // NVRAM to FLASH memory

void BCD_Time(void);                        // Binary to BCD conversion of time
                                            // and date 
void Bin_Time(void);                        // BCD to binary conversion of RTC 
                                            // registers
unsigned char BCD2Bin_Seconds(void);        // BCD to binary conversion of Sec.
unsigned char Bin2BCD_Seconds(void);        // Binary to BCD conversion of Sec.
unsigned char BCD2Bin_Hours(void);          // BCD to binary conversion of Hours
unsigned char Bin2BCD_Hours (void);         // Binary to BCD conversion of Hours
unsigned char BCD2Bin (unsigned char v);    // BCD to Binary conversion
unsigned char Bin2BCD (unsigned char a);    // Binary to BCD conversion


#ifdef _UART_

unsigned char char2num(unsigned char c);    // character to digit conversion
unsigned char num2char(unsigned char c);    // digit to character conversion

#endif


#endif


//-----------------------------------------------------------------------------
// end of tcrtc_interface.h
//-----------------------------------------------------------------------------