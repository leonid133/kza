//-----------------------------------------------------------------------------
// F300_TCRTC_Clock.c
//-----------------------------------------------------------------------------
// Copyright 2006 Silicon Laboratories, Inc.
// http://www.silabs.com
//
// Program Description:
//
// See Readme.txt
//
// How To Test:    See Readme.txt
//
//
// FID:            30X000013
// Target:         C8051F300
// Tool chain:     Keil
//                 Silicon Laboratories IDE version 2.71
// Command Line:   See Readme.txt
// Project Name:   F300_TempCompRTC_RD
//
// Release 1.0
//    -Initial Revision (SYRO)
//    -12 MAY 2006
//


#include "c8051f300.h"                      // SFR declarations
#include "F300_TCRTC_Clock.h"

//-----------------------------------------------------------------------------
// Global VARIABLES
//-----------------------------------------------------------------------------

unsigned char   Seconds;                    // binary RTC registers
unsigned char   Minutes;
unsigned char   Hours;
unsigned char   Date;
unsigned char   Month;
unsigned char   Year;
unsigned char   Day;

bit min_changed = 0;                        // minute changed flag
bit day_changed = 0;                        // day changed flag


//-----------------------------------------------------------------------------
// Global CONSTANTS
//-----------------------------------------------------------------------------
static const unsigned char months[] = {0,31,28,31,30,31,30,31,31,30,31,30,31};

//-----------------------------------------------------------------------------
//IncRTC
//-----------------------------------------------------------------------------
//
// Increments RTC registers and set flags when minutes and days change
//
void IncRTC(void)
{
    unsigned char lastDay,tmp,DayOff=0;
    extern long ppm;

    if(Seconds & 0x80)                      // halt clock if bit CH is set 
        return;                  

	if(Seconds >= 59)                       // one minute passed
    {
        min_changed=1;                      // set minute changed flag
        Seconds = 0;

		if(Minutes >= 59)                   // one hour passed
        {
			Minutes = 0;
			if( (Hours & Set12_24) == 0 )   // 24 hours format
            {
                if( (Hours & 0x1F) >= 23 )  // end of the day?
    			{
                    Hours = 0;                  
                    day_changed=1;          // set day changed flag
                    DayOff=1;               // end of the day
    		    }
            } 	
    		else                            // 12 hours format
            {
                if((Hours & 0x0F) >= 11 )   // 11 o'clock or more
                {
                    if((Hours & 0x0F) >= 12)// 12 o'clock
                    {
                        Hours &= 0x60;
                    }
                    else
                    {
                        tmp = Hours & 0x60; // save the control bits
                        if(tmp & AM_PM)     // if 11 PM
                        {
    					    tmp &= ~AM_PM;  // turn to AM                            
                            day_changed=1;  // set day changed flag
                            Hours=12;
    						DayOff=1;       // end of the day
    					}  
                        else 
    						tmp |= AM_PM;   // if 11 AM turn to PM

                        Hours |= tmp;       // restore the control bits
                    }
    		    }  
			}
		
			if(DayOff==1)                   // a day has passed
            {
				DayOff=0;

				if(Day == 7) 
                    Day=1;                  // day of the week checked
				else 
                    Day++;                  // increment day of the week

				lastDay = months[Month];

				// is February in a leap year?
				if( (Month == 2) && ( ( (Year & 0x03) == 0) &&
                  ( (Year % 100 != 0) || (Year%400 == 0) ) ) )
				    lastDay++;	            // add one more day

				if(Date >= lastDay)         // a month passed
				{
					
					Date = 1;
					if(Month >= 12)         // a year passed
					{
						Month = 1;
						Year++;
					}
					else
						Month++;
				}
				else
					Date++;
            }
			else
			    Hours++;			
        }
		else
			Minutes++;
	}
	else
		Seconds++;

}


//-----------------------------------------------------------------------------
// end of tcrtc_clock.c
//-----------------------------------------------------------------------------