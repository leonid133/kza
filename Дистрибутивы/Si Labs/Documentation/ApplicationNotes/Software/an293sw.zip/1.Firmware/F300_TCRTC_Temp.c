//-----------------------------------------------------------------------------
// F300_TCRTC_Temp.c
//-----------------------------------------------------------------------------
// Copyright 2006 Silicon Laboratories, Inc.
// http://www.silabs.com
//
// Program Description:
//
// See Readme.txt
//
// How To Test:    See Readme.txt
//
//
// FID:            30X000007
// Target:         C8051F300
// Tool chain:     Keil
//                 Silicon Laboratories IDE version 2.71
// Command Line:   See Readme.txt
// Project Name:   F300_TempCompRTC_RD
//
// Release 1.0
//    -Initial Revision (SYRO)
//    -12 MAY 2006
//
//-----------------------------------------------------------------------------
// INCLUDES
//-----------------------------------------------------------------------------

#include "c8051f300.h"                      // SFR declarations
#include "F300_TCRTC_Temp.h"


//-----------------------------------------------------------------------------
// Global VARIABLES
//-----------------------------------------------------------------------------

unsigned int code TEMP_OFFSET=0xFFFF;       // The temperat. sensor offset value
                                            // will be set on the first run.  It
                                            // must be initialized to 0xff's
unsigned long time_remainder = 0;           // remainder after compens. of sec.
unsigned long ppm_remainder = 0;
unsigned long idata accumulative = 0;       // real ppm acumulator

int idata temperature = 0;                  // current temperature


//-----------------------------------------------------------------------------
// calibrate
//-----------------------------------------------------------------------------
//
// Measure the temperature, calculate the 0 DEG C offset value and the
// temperature sensor gain
//
void calibrate (void)
{
   long temp_offset;                        // contains 0 DEG temperature
                                            // offset value
   unsigned scratch;                        // temporary variable that is as
                                            // large as TEMP_OFFSET

   wait_soak_time ();                       // let temperature of device
                                            // stabilize

   temp_offset = (long) measure ();         // here we assume that temp_offset
                                            // contains the ADC code equivalent
                                            // to AMB_TEMP degrees C

   // now calculate the 0 DEG C offset value using <temp_offset> and the
   // temp sensor gain (TEMP_SENSOR_GAIN).

   temp_offset = temp_offset - ((long) AMB_TEMP * TEMP_SENSOR_GAIN *
                 PGA_GAIN / VREF * 65536 / 1000);

   // write the offset to FLASH
   scratch = (unsigned) temp_offset;        // convert (long) to (unsigned)
   if (TEMP_OFFSET == 0xFFFF) 
   {
		FLASH_Write ((unsigned char *) &TEMP_OFFSET, (unsigned char *) &scratch,
					  sizeof(TEMP_OFFSET));
   } 
}


//-----------------------------------------------------------------------------
// wait_soak_time
//-----------------------------------------------------------------------------
//
// This routine waits for the number of seconds indicated in the constant
// <SOAK_TIME>.
//
void wait_soak_time (void)
{
   unsigned char i;

   for( i = SOAK_TIME; i != 0; i--) {
        T0_WaitMS (1000);                   // wait 1000ms
     
   }
}


//-----------------------------------------------------------------------------
// measure
//-----------------------------------------------------------------------------
//
// This routine averages 65536 ADC samples and returns a 16-bit unsigned
// result.
//
unsigned int measure (void)
{
   unsigned i;                              // sample counter
   unsigned long accumulator=0L;            // here's where we integrate the
                                            // ADC samples

   // read the ADC value and add to running total
   i = 0;
 
   AD0EN = 1;                               // enable ADC
   do {
      AD0INT = 0;                           // clear end-of-conversion indicator
      AD0BUSY = 1;                          // initiate conversion
      while(!AD0INT);                       // wait for conversion to complete
      accumulator += ADC0;                  // read adc value and accumulate
      i++;                                  // update counter
   } while (i != 0x0000);
   
   AD0EN = 0;                               // disable ADC

   // the accumulator now contains 16 added bits of which 8 are usable
   return (unsigned int) (accumulator >> 8);
}


//-----------------------------------------------------------------------------
// get_temp
//-----------------------------------------------------------------------------
//
// This routine returns the temperature in hundredths of a degree C.
//
int get_temp (void)
{
   unsigned int ADC_code;
   long result;

   ADC_code = measure();

   result = ADC_code - TEMP_OFFSET;

   result = result * (long) VREF / PGA_GAIN / 256 * 1000 / TEMP_SENSOR_GAIN *
            100 / 256;

   return (int) result;
}


//-----------------------------------------------------------------------------
// calc_ppm
//-----------------------------------------------------------------------------
//
// This routine calculates the deviation of frequency in PPM
//
void calc_ppm(void)
{
    unsigned long temp_diff;
    unsigned long ppm;

    temperature = get_temp ();              // measure temperature once per min.

	if(temperature < 2500)                  // negative temperature or positive
                                            // temperature below 25 degrees
        temp_diff = (unsigned long)(2500 - temperature);     
                                            
	else                                    // positive temp. above 25 degrees
        temp_diff = (unsigned long)(temperature - 2500);

    // calc ppm/min = square(T - 25 deg C) * 0.04 * 60 sec
    // deviation frequency calculation once per minute
    ppm = (temp_diff * temp_diff) / 25UL;

    // store ppm remainder by division with 25 to keep accuracy
    ppm_remainder += (temp_diff * temp_diff) % 25UL;

    accumulative += ppm;                    // store ppm in temporary
                                            // accumulator
}


//-----------------------------------------------------------------------------
// compensate_RTC
//-----------------------------------------------------------------------------
//
// Every 24 hours RTC is compensated with temeperature.This routine calculates
// the seconds needs for compensation.
//
void compensate_RTC(void)
{
    extern unsigned char Seconds;
    unsigned long tmp_acc;

    accumulative += ppm_remainder / 25UL;   // add to acc. ppm_remainder stored
                                            // all the day
    ppm_remainder = ppm_remainder % 25UL;   // keep again remainder


    tmp_acc = accumulative % 10000UL;
    accumulative = accumulative / 10000UL;  // adjust to real temperature
    accumulative = accumulative * 60UL;     // add minutes
    accumulative += time_remainder;

    Seconds += (unsigned char)(accumulative / 1000000UL);
                                            // get compensation seconds

    time_remainder=accumulative % 1000000UL;
    accumulative = tmp_acc;                 // put in accumulative the remaind.
}


//-----------------------------------------------------------------------------
// end of tcrtc_temp.c
//-----------------------------------------------------------------------------