//-----------------------------------------------------------------------------
// F300_TCRTC_Inteface.c
//-----------------------------------------------------------------------------
// Copyright 2006 Silicon Laboratories, Inc.
// http://www.silabs.com
//
// Program Description:
//
// See Readme.txt
//
// How To Test:    See Readme.txt
//
//
// FID:            30X000011
// Target:         C8051F300
// Tool chain:     Keil
//                 Silicon Laboratories IDE version 2.71
// Command Line:   See Readme.txt
// Project Name:   F300_TempCompRTC_RD
//
// Release 1.0
//    -Initial Revision (SYRO)
//    -12 MAY 2006
//

//-----------------------------------------------------------------------------
// INCLUDES
//-----------------------------------------------------------------------------

#include "c8051f300.h"
#include "F300_TCRTC_Interface.h"


//-----------------------------------------------------------------------------
// FLASH_Write
//-----------------------------------------------------------------------------
//
// write data to FLASH memory
//
void FLASH_Write (char *dest, char *src, unsigned num)
{
   unsigned char idata i;                   // loop counter
   char xdata *pwrite;                      // FLASH write pointer
   char the_data;                           // holds data to write to FLASH

   pwrite = (char *) dest;                  // set target address in FLASH
   for (i = 0; i < num; i++) {
      the_data = *src++;                    // read data byte
      FLKEY = 0xa5;                         // Key sequence #1
      FLKEY = 0xf1;                         // Key sequence #2
      PSCTL = 0x01;                         // PSWE = 1; MOVX writes target FLASH
      RSTSRC = 0x06;                        // force MCD and VDDmon enable
      *pwrite = the_data;                   // write the data
      PSCTL = 0x00;                         // PSWE = 0; MOVX writes target XRAM
      pwrite++;                             // advance write pointer
   }
}

//-----------------------------------------------------------------------------
// FLASH_Erase
//-----------------------------------------------------------------------------
//
// erase a 512 bytes FLASH page
//
void FLASH_Erase(char *dest)
{
   char xdata *pwrite;				        // FLASH write pointer

   pwrite = (char *) dest;

   PSCTL = 0x03;                            // MOVX writes erase FLASH page
   FLKEY = 0xA5;                            // FLASH lock and key sequence 1
   FLKEY = 0xF1;                            // FLASH lock and key sequence 2
   RSTSRC = 0x06;                           // Force MCD and VDDmon enable
   *pwrite = 0;                             // initiate page erase
   PSCTL = 0x00;                            // MOVX writes target XRAM
}



//-----------------------------------------------------------------------------
// RTC_Read
//-----------------------------------------------------------------------------
//
// Read a byte from RTC registers or NVRAM
//
unsigned char RTC_Read(void)
{
	unsigned char result;

	if(WORD_ADDR < 0x08)					// read from emulated RTC registers
	{
		result=RTC_REG[WORD_ADDR];
	}

#ifdef _DEBUG_                              // if in debug mode, temperature
	else                                    // and accumulative are available
	if(WORD_ADDR==0x40)                     // between 0x40 and 0x45 addresses
		result = (unsigned char)(temperature >> 8);
	else
	if(WORD_ADDR==0x41)
		result = (unsigned char)(temperature & 0xFF);
	else
	if(WORD_ADDR==0x42)
		result = (unsigned char)(accumulative >> 24);
	else
	if(WORD_ADDR==0x43)
		result = (unsigned char)(accumulative >> 16);
	else
	if(WORD_ADDR==0x44)
		result = (unsigned char)(accumulative >> 8);
	else
	if(WORD_ADDR==0x45)
		result = (unsigned char)(accumulative & 0xFF);
#endif

	else                                    // read from emulated RTC NVRAM
    if(WORD_ADDR < 0x40)
	{
		result=RTC_NVRAM[WORD_ADDR-0x08];
	}

	WORD_ADDR++;							// increment the RTC register pointer

#ifdef _DEBUG_
	if(WORD_ADDR>0x45)						// if it's out of range
		WORD_ADDR=0;
#else
	if(WORD_ADDR>0x3F)						// if it's out of range
		WORD_ADDR=0;
#endif

	return result;
}


//-----------------------------------------------------------------------------
// RTC_Write
//-----------------------------------------------------------------------------
//
// Write a byte to RTC registers or NVRAM
//
void RTC_Write(unsigned char value)
{
	if(WORD_ADDR < 0x08)					// write to emulated RTC registers
	{
		if(WORD_ADDR <3)					// if writing hour, min or sec
		{
			accumulative = 0;               // clear accumulative and remainders
			time_remainder = 0;
            ppm_remainder = 0;
		}
		RTC_REG[WORD_ADDR]=value;

        reg_write = 1;
	}
	else
    if(WORD_ADDR < 0x40)                    // write to emulated RTC NVRAM
	{
		RTC_NVRAM[WORD_ADDR-0x08]=value;
        flash_write = 1;                    // set FLASH writing flag
    }

	WORD_ADDR++;							// increment the RTC register pointer

	if(WORD_ADDR>0x3F)						// if it's out of range
		WORD_ADDR=0;

}


//-----------------------------------------------------------------------------
// NVRAM_Update
//-----------------------------------------------------------------------------
//
// Erases the entire page of FLASH memory where NVRAM resides
// Updates the NVRAM data
//
void NVRAM_Update(void)
{
	// erase an entire page of FLASH
	FLASH_Erase((unsigned char*) FLASH_NVRAM);

	// write the 56 bytes of emulated NVRAM to FLASH
	FLASH_Write( (unsigned char*) FLASH_NVRAM, (unsigned char*)RTC_NVRAM, 
                 56*sizeof(*FLASH_NVRAM) );
}


//-----------------------------------------------------------------------------
// BCD_Time
//-----------------------------------------------------------------------------
//
// Convert the binary time and date to BCD
// Update the contents of RTC register
//
void BCD_Time(void)
{
	RTC_SEC=Bin2BCD_Seconds();              // convert second to BCD
	RTC_MIN=Bin2BCD(Minutes);               // convert minute to BCD
	RTC_HOUR=Bin2BCD_Hours();               // convert hour to BCD
	RTC_DATE=Bin2BCD(Date);                 // convert date to BCD
	RTC_MONTH=Bin2BCD(Month);               // convert month to BCD
	RTC_YEAR=Bin2BCD(Year);                 // convert year to BCD
	RTC_DAY=Day;                            // day of week is the same in BCD
}


//-----------------------------------------------------------------------------
// Bin_Time
//-----------------------------------------------------------------------------
//
// Convert RTC registers from BCD to binary
// Update the binary time and date
//
void Bin_Time(void)
{
	Seconds=BCD2Bin_Seconds();              // convert second to binary
	Minutes=BCD2Bin(RTC_MIN);               // convert minute to binary
	Hours=BCD2Bin_Hours();                  // convert hour to binary
	Date=BCD2Bin(RTC_DATE);                 // convert date to binary
	Month=BCD2Bin(RTC_MONTH);               // convert month to binary
	Year=BCD2Bin(RTC_YEAR);                 // convert year to binary
	Day=RTC_DAY;                            // day of week is the same in binary
}


//-----------------------------------------------------------------------------
// BCD2Bin_Seconds
//-----------------------------------------------------------------------------
//
// Convert BCD values of seconds to hex values 
//
unsigned char BCD2Bin_Seconds(void)
{
	unsigned char temp,ret;

	temp = RTC_SEC & 0x80;                  // save the control bit 
	ret = BCD2Bin(RTC_SEC & 0x7F);          // convert seconds to binary
	ret |= temp;                            // restore the control bit 
	
	return ret;
}


//-----------------------------------------------------------------------------
//Bin2BCD_Seconds 
//-----------------------------------------------------------------------------
//
// Binary to BCD conversion of Seconds
//
unsigned char Bin2BCD_Seconds(void)
{
	unsigned char temp,ret;

	temp = Seconds & 0x80;                  // save the control bit  
	ret = Bin2BCD(Seconds & 0x7F);          // convert seconds to BCD 
	ret |= temp;                            // restore the control bit      
	
	return ret;
}


//-----------------------------------------------------------------------------
// BCD2Bin_Hours
//-----------------------------------------------------------------------------
//
// Convert BCD values of hours to hex values
//
unsigned char BCD2Bin_Hours(void)
{
	unsigned char temp,ret;

    if(RTC_HOUR & 0x40)                     // if 12 hour format 
	{
		temp=RTC_HOUR & 0x60;               // save the control bits
		ret=BCD2Bin(RTC_HOUR & 0x1F);       // convert BCD hour to binary
    	ret|=temp;                          // restore the control bits
	}
	else                                    // if 24 hour format 
	{
		ret=BCD2Bin(RTC_HOUR & 0x3F);       // convert BCD hour to binary 
	}

	return ret;
}


//-----------------------------------------------------------------------------
//Bin2BCD_Hours
//-----------------------------------------------------------------------------
//
// Binary to BCD conversion of hours
//
unsigned char Bin2BCD_Hours (void)
{
	unsigned char temp,ret;

	temp=Hours & 0x60;                      // save the control bits
	
	ret=Bin2BCD(Hours & 0x1F);              // convert binary hour to BCD
	ret|=temp;                              // restore the control bits 
	
	return ret;
}


//-----------------------------------------------------------------------------
// BCD2Bin
//-----------------------------------------------------------------------------
//
// BCD to Binary conversion
//
unsigned char BCD2Bin (unsigned char v)
{
	unsigned char ret = 0;
     
	while(v & 0xF0)
	{
		ret += 10;
		v   -= 0x10;
	}
	ret += v & 0x0F;
	return ret;
}


//-----------------------------------------------------------------------------
// Bin2BCD
//-----------------------------------------------------------------------------
//
// Binary to BCD conversion
//
unsigned char Bin2BCD (unsigned char a)
{
	unsigned char r=0;

	while(a >= 10)		                    //convert binary -> BCD
	{
		a -= 10;
		r += 0x10;
	}
	r += a;
	return r;
}



#ifdef _UART_								// using UART communication

//-----------------------------------------------------------------------------
// char2num
//-----------------------------------------------------------------------------
//
// Convert a character representing a hex digit
// to it's corresponding number
//
unsigned char char2num(unsigned char c)
{
	if( (c >= 'A') && (c <= 'F') )
		return(c - 'A' + 10);
	else
	if( (c >= 'a') && (c <= 'f') )
		return(c - 'a' + 10);
	else
	if( (c >= '0') && (c <= '9') )
		return(c - '0');
}


//-----------------------------------------------------------------------------
// num2char
//-----------------------------------------------------------------------------
//
// Convert a number to it's corresponding character 
// representing a hex digit
// 
unsigned char num2char(unsigned char c)
{
	if( c > 9)
		return(c + 'A' - 10);
	else
		return(c + '0');
}

#endif                                      // using UART communication


//-----------------------------------------------------------------------------
// end of tcrtc_interface.c
//-----------------------------------------------------------------------------