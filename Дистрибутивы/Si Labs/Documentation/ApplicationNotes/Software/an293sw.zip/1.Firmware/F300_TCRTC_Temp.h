//-----------------------------------------------------------------------------
// F300_TCRTC_Temp.h
//-----------------------------------------------------------------------------
// Copyright 2006 Silicon Laboratories, Inc.
// http://www.silabs.com
//
// Program Description:
//
// See Readme.txt
//
// How To Test:    See Readme.txt
//
//
// FID:            30X000006
// Target:         C8051F300
// Tool chain:     Keil
//                 Silicon Laboratories IDE version 2.71
// Command Line:   See Readme.txt
// Project Name:   F300_TempCompRTC_RD
//
// Release 1.0
//    -Initial Revision (SYRO)
//    -12 MAY 2006
//

#ifndef  __tcrtc_temp_h__
#define  __tcrtc_temp_h__


//-----------------------------------------------------------------------------
// Temperature Sensor Calibration PARAMETERS
//-----------------------------------------------------------------------------
#define AMB_TEMP           28               // Ambient Calibration Temperature
                                            // (degC)
#define TEMP_SENSOR_GAIN   3300             // Temp Sensor Gain in (uV / degC)
#define PGA_GAIN           2                // PGA gain setting
#define VREF               3300             // ADC Voltage Reference (mV)
#define SOAK_TIME          15               // Soak Time in Seconds
                                                

//-----------------------------------------------------------------------------
// Function PROTOTYPES
//-----------------------------------------------------------------------------
void calibrate (void);                      // Calibrates the temperature sensor
void wait_soak_time (void);                 // Delay for a specified number of 
                                            // seconds
unsigned int measure (void);                // returns the temperature in
                                            // hundredths of a degree C
int get_temp (void);
void calc_ppm (void);                       // Calculates the deviation of the
                                            // frequency in PPM
void compensate_RTC(void);                  // Calculates the RTC compensation
void adjust_acc (void);                     // Ajust the accumulative value


//-----------------------------------------------------------------------------
// Extern Function PROTOTYPES
//-----------------------------------------------------------------------------
extern void T0_WaitMS (unsigned ms);
extern void FLASH_Write (char *dest, char *src, unsigned num);

#endif


//-----------------------------------------------------------------------------
// end of tcrtc_temp.h
//-----------------------------------------------------------------------------