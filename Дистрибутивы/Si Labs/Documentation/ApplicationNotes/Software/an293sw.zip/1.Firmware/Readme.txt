-------------------------------------------------------------------------------
 Readme.txt
-------------------------------------------------------------------------------

Copyright 2006 Silicon Laboratories, Inc.
http://www.silabs.com

Program Description:
-------------------

This program implements a Real Time Clock on a C8051F300 device.
The ambient temperature is measured periodically using the on-chip 
temp sensor to calibrate the oscillator against drift caused by changes 
in temperature.

The device also outputs information over an SMBus or UART interface.  See the 
Command Line Options Section of this Readme for information on how choose
between SMBus or UART.


How To Test:
-----------

See the Temperature Compensated Real Time Clock Reference Design Kit User's 
Guide for usage instructions. This is available here:
http://www.silabs.com/products/microcontroller/designs.asp


Acceptable Warnings on Build:
----------------------------

The warnings that are acceptable on building this project are:
1) *** WARNING L15: MULTIPLE CALL TO SEGMENT
SEGMENT: ?PR?_FLASH_WRITE?F300_TCRTC_INTERFACE

This warning can be safely ignored because this function won't be 
called at the same time by two different parts of code.


Target and Tool Chain Information:
---------------------------------

FID:            30X000005
Target:         C8051F300
Tool chain:     Keil C51 v8.0 (A51, C51, BL51)
                Silicon Laboratories IDE version 2.71
Project Name:   F300_TempCompRTC_RD


Command Line Options:
--------------------

Assembler : Default
Compiler  : DB OE DEFINE(_UART_) 
            
            OR

            DB OE

Linker    : RS(256) PL(68) PW(78) CODE(0x0000-0x19FF,0x1C00-0x1DFE)

The program can be configured to use SMBus or UART to communicate the
temperature information.  If the symbol _UART_ is defined in the compiler
command line, the program will use the UART interface.  If nothing is defined,
the SMBus interface will be used.


File List:
---------

c8051F300.h
F300_TCRTC_Clock.c
F300_TCRTC_Clock.h
F300_TCRTC_Interface.c
F300_TCRTC_Interface.h
F300_TCRTC_Main.c
F300_TCRTC_Main.h
F300_TCRTC_Temp.c
F300_TCRTC_Temp.h
F300_TempCompRTC_RD.wsp
Readme.txt (this file)

Release Information:
-------------------

Release 1.0
  -Initial Release

-------------------------------------------------------------------------------
 End Of File
-------------------------------------------------------------------------------