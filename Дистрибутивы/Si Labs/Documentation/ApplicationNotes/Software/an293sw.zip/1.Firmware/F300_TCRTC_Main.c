//-----------------------------------------------------------------------------
// F300_TCRTC_Main.c
//-----------------------------------------------------------------------------
// Copyright 2006 Silicon Laboratories, Inc.
// http://www.silabs.com
//
// Program Description:
//
// See Readme.txt
//
// How To Test:    See Readme.txt
//
//
// FID:            30X000009
// Target:         C8051F300
// Tool chain:     Keil
//                 Silicon Laboratories IDE version 2.71
// Command Line:   See Readme.txt
// Project Name:   F300_TempCompRTC_RD
//
// Release 1.0
//    -Initial Revision (SYRO)
//    -12 MAY 2006
//
//
//-----------------------------------------------------------------------------
// INCLUDES
//-----------------------------------------------------------------------------

#include "c8051f300.h"

#include "F300_TCRTC_Interface.h"
#include "F300_TCRTC_Main.h"
#include "F300_TCRTC_Temp.h"
#include "F300_TCRTC_Clock.h"

#ifdef _UART_
#include <stdio.h>
#endif

//-----------------------------------------------------------------------------
// 16-bit SFR Definitions for 'F30x
//-----------------------------------------------------------------------------

sfr16 TMR2RL   = 0xca;                      // Timer2 reload value
sfr16 TMR2     = 0xcc;                      // Timer2 counter

sbit SQW = P0^7;                            // P0.7 outputs a 1/2 Hz square wave


void main(void)
{
    IE = 0;                                 // all interrupts disabled;
    EIE1 = 0;                               //
    EA=0;                                   //
    PCA0MD &= ~0x40;                        // WDTE = 0 (clear WD timer)

	PORT_Init();                            // Init Crossbar and GPIO
    OSC_Config();                           // Configure internal & external osc.
    ADC0_Init();                            // Configure ADC
                                            // NVRAM buffer
    if (TEMP_OFFSET == 0xFFFF)
        calibrate();                        // Calibrating the temperature sensor

    Timer2_Init();                          // Configure Timer2
    RTC_Init();                             // Initializes RTC registers and 

#ifdef _UART_
	UART_Init();                            // Configure UART
#else
	SMBus_Init();                           // Configure SMBUS
	Timer0_Init();                          // Configure Timer0
	Timer1_Init();                          // Configure Timer1
#endif

    temperature = get_temp();               // measure the temperature

    Interrupt_Init();                       // initialize interrupts

    TR2 = 1;                                // Start Timer2

#ifdef _UART_
    uart_display = 1;                       // Set periodic display flag
#endif

    while(1)
	{
        if(min_changed)                     // a minute has passed
        {
            calc_ppm();                     // compute frequency deviation
            min_changed=0;
            if(day_changed)                 // a day has passed
            {
                compensate_RTC();           // compensate RTC deviation
                day_changed=0;
            }
        }
        PCON |= 0x01;                       // switch to idle mode  
    }
}


//-----------------------------------------------------------------------------
// PORT_Init
//-----------------------------------------------------------------------------
// Configure the Crossbar and GPIO ports.
// P0.0 - SMBus - SDA
// P0.1 - SMBus - SCL
// P0.2 - XTAL1 - 32768 Hz
// P0.3 - XTAL2 - 32768 Hz
// P0.4 - UART TX (push-pull)
// P0.5 - UART RX
// P0.6 - SQW (push-pull)
// P0.7 - none
//
void PORT_Init (void)
{
   // Configure the XBRn Registers
   XBR0 = 0x4c;                             // Skip crystal pins and SQW in 
                                            // crossbar
#ifdef _UART_
   XBR1 = 0x03;                             // Enable UART0 pins
#else
   XBR1 = 0x04;                             // Enable SMBus pins
#endif

   XBR2 = 0x40;                             // Enable crossbar and weak pull-ups

   // Select Pin I/0
   P0MDIN = 0xF3;                           // Configure XTAL1 and XTAL2 as
                                            // analog inputs   

   P0MDOUT   = 0x90;
   //P0MDOUT = 0x50;                          // Enable TX0 and SQW as
                                            // push-pull outputs

   P0 = 0xFF;
}


//-----------------------------------------------------------------------------
// OSC_Config
//-----------------------------------------------------------------------------
//
// Oscillator Configuration
//
void OSC_Config (void)
{
   unsigned int i;

   OSCICN = 0x07;                           // configure internal oscillator for
   										    // its highest frequency
   for(i=0;i<255;i++);					    // give time to external osc. to 
                                            // stabilize
   while(!(OSCXCN | 0x80));				    // wait until it's ready

   OSCXCN = 0x61;						    // 32.768 kHz crystal osc.

   RSTSRC = 0x06;							// enable MCD and VDDmon 
}


//-----------------------------------------------------------------------------
// ADC0_Init
//-----------------------------------------------------------------------------
//
// AD converter configuration
//
void ADC0_Init(void)
{
   ADC0CN = 0x00;                           // ADC0 disabled; ADC0 conversions 
                                            // are initiated on a write to
                                            // AD0Busy
   AMX0SL = 0xf8;                           // select temp sensor as mux input
   ADC0CF = (SYSCLK/5000000) << 3;          // ADC conversion clock < 5.0MHz
   ADC0CF |= 0x02;                          // PGA gain = 2
   REF0CN = 0x0e;                           // enable temp sensor, VREF = VDD,
                                            // bias generator is on.
   EIE1 &= ~0x04;                           // disable ADC0 EOC interrupt

   AD0EN = 1;                               // enable ADC0
}



#ifndef _UART_								// using SMBus communication

//-----------------------------------------------------------------------------
// Timer0_Init()
//-----------------------------------------------------------------------------
//
// Timer0 configured to overflow in 32ms
// Used to measure the time since last SMBus or UART interrupt took place
//
void Timer0_Init(void)
{
	CKCON &= ~0x0B;                         // Timer0 clock source = SYSCLK/12

    TMOD &= ~0x0E;                          // Timer0 in 16 bit mode
	TMOD |= 0x01;

	TH0 = 0;
	TL0 = 0;
    TR0 = 0;                                // Timer0 stopped
}


//-----------------------------------------------------------------------------
// SMBUS interface configuration
//-----------------------------------------------------------------------------
//
// Use Timer1 for free timeout detect. Enable slave mode. Enable
// setup & hold time extensions. Disable SCL low timeout detect
//
void SMBus_Init (void)
{
    SMB0CF=0x95;                              // enable SMBus;
                                              // enable free timeout detect

    SMB0CF &= ~0x80;                          // Reset communication
    SMB0CF |= 0x80;

    smb_cnt = 0;
}


//-----------------------------------------------------------------------------
// Timer1_Init
//-----------------------------------------------------------------------------
//
// Timer1 configured as the SMBus clock source (for free timeout detection):
// - Timer1 in 8-bit auto-reload mode
// - SYSCLK / 12 as Timer1 clock source
// - Timer1 overflow rate => 3 * SMB_FREQUENCY
// - Free timeout period will be ~10 * Timer1 overflow rate
// - Timer1 enabled
//
void Timer1_Init (void)
{
    CKCON &= ~0x13;                         // Timer1 clock source = SYSCLK / 12

    TMOD &= ~0xD0;                          // Timer1 in 8-bit auto-reload mode
    TMOD |= 0x20;

    TH1 = -(SYSCLK/SMB_FREQUENCY/12/3);     // Timer1 config. to overflow at 1/3
                                            // the rate defined by SMB_FREQUENCY

    TL1 = -(SYSCLK/SMB_FREQUENCY/12/3);     // Timer1 preloaded to overflow at
                                            // the rate defined by SMB_FREQUENCY

    TR1 = 1;                                // Timer1 running
}


#endif                                      // using SMBus communication


//-----------------------------------------------------------------------------
// Timer2_Init
//-----------------------------------------------------------------------------
//
// Timer2 configured for generating the RTC time measurement interrupt
// - Timer2 in 16-bit auto-reload mode
// - XTAL/8 as Timer2 clock source
// - Timer2 reload registers loaded for a 1s overflow period
// - Timer2 pre-loaded to overflow after 1s
// - Timer2 enabled
//
void Timer2_Init (void)
{
   TMR2CN = 0x01;                           // Timer2 configured for 16-bit
                                            // auto-reload, low-byte interrupt
                                            // disabled
                                            // Uses external oscillator:XTALCLK/8

   TMR2 = -(XTALCLK/8);				        // Timer2 configured to overflow
   TMR2RL = -(XTALCLK/8);	                // after one second

   CKCON &= ~0x20;                          // Timer2 uses XTALCLK/8
}



#ifdef _UART_							    // using UART communication


//-----------------------------------------------------------------------------
// UART_Init
//-----------------------------------------------------------------------------
//
// Configure the UART0 using Timer1 for <BAUDRATE> and 8-N-1.
//
void UART_Init(void)
{
	SCON0 = 0x10;                           // SCON0: 8-bit variable bit rate
                                            //        level of STOP bit ignored
                                            //        RX enabled
                                            //        ninth bits are zeros
                                            //        clear RI0 and TI0 bits
    if (SYSCLK/BAUDRATE/2/256 < 1)
	{
		TH1 = -(SYSCLK/BAUDRATE/2);
    	CKCON |=  0x10;                     // T1M = 1; SCA1:0 = xx
	}
	else if (SYSCLK/BAUDRATE/2/256 < 4)
	{
		TH1 = -(SYSCLK/BAUDRATE/2/4);
	    CKCON &= ~0x13;                     // T1M = 0; SCA1:0 = 01
		CKCON |=  0x01;
	}
	else if (SYSCLK/BAUDRATE/2/256 < 12)
	{
		TH1 = -(SYSCLK/BAUDRATE/2/12);
		CKCON &= ~0x13;                     // T1M = 0; SCA1:0 = 00
	}
	else
	{
		TH1 = -(SYSCLK/BAUDRATE/2/48);
		CKCON &= ~0x13;                     // T1M = 0; SCA1:0 = 10
		CKCON |=  0x02;
	}

	TL1 = TH1;                              // init Timer1
	TMOD &= ~0xf0;                          // TMOD: timer 1 in 8-bit autoreload
	TMOD |=  0x20;
	TR1 = 1;                                // START Timer1
	RI0 = 0;                                // clear receiver interrupt
	TI0 = 0;                                // clear transmit interrupt

    uart_display=0;                         // clear display flag
}


#endif									    // using UART communication



#ifndef _UART_								// using SMBus communication

//-----------------------------------------------------------------------------
// SMBus Interrupt Service Routine (ISR)
//-----------------------------------------------------------------------------
//
// SMBus ISR state machine
// - Slave only implementation - no master states defined
// - All incoming data is written to RTC registers or NVRAM
// - All outgoing data is read from RTC registers or NVRAM
//
void SMBUS_ISR (void) interrupt 6
{
   bit RXTX;                                // Software flag for slave
                                            // receiver-to-transmitter transition 

   TR0 = 1;                                 // Start Timer0

   switch (SMB0CN & 0xF0)                   // Decode the SMBus status vector
   {
      // Slave Receiver: Start+Address received
      case  SMB_SRADD:
  	     smb_cnt=0;
         if((SMB0DAT&0xFE) == SLA_ADD)      // Decode address
         {                                  // If the received address matches,
            ET2=0;                          // disable Timer2 interrupt
            BCD_Time();                     // update the RTC registers

            STA = 0;                        // Clear STA bit
            ACK = 1;                        // ACK the received slave address
            if(SMB0DAT&0x01==READ)          // If the transfer is a master READ,
            {
               SMB0DAT = RTC_Read();		// Prepare outgoing byte
               if(!(SMB0DAT&0x80))          // If data byte MSB = '0',
               {
                  STO = 1;                  // Set STO to force outgoing 
                                            // MSB => '0'
                  RXTX = 1;                 // Set receiver-to-transmitter flag
               }
            }
         }
         else                               // If received slave address
         {                                  // does not match,
            ACK = 0;                        // NACK received address
         }
         break;

      // Slave Receiver: Data received
      case  SMB_SRDB:
		 if(smb_cnt==0)                     // if it's first data byte
         {
            smb_cnt=1;
     	    WORD_ADDR=SMB0DAT;              // RTC register address received
         }
		 else
		 if(smb_cnt==1)                     // not first data byte
		 	RTC_Write(SMB0DAT);				// Store incoming data

         ACK = 1;                           // ACK received data

         break;

      // Slave Receiver: Stop received
      case  SMB_SRSTO:
         STO = 0;                           // STO must be cleared by software
         smb_cnt = 0;
         break;

      // Slave Transmitter: Data byte transmitted
      case  SMB_STDB:
      	 if(ACK)
      	 	SMB0DAT = RTC_Read();		    // Send next data byte
   	 	 ACK = 0;
         smb_cnt=0;
         break;

      // Slave Transmitter: Arbitration lost, Stop detected
      case  SMB_STSTO:
         STO = 0;
         smb_cnt=0;
         break;                             // No action required

      // Default: all other cases undefined
      default:
         SMB0CF &= ~0x80;                   // Reset communication
         SMB0CF |= 0x80;
         smb_cnt=0;
         ET2=1;                             // enable Timer2 interrupt
         break;
    }


    if( !(SMB0CF & 0x20) )                  // if not in the middle of
    {                                       // a transfer on SMBus
        ET2=1;                              // enable Timer2 interrupt
        smb_cnt=0;
        if(reg_write)
        {
    		Bin_Time();						// convert BCD registers to binary
            reg_write = 0;                  // clear RTC registers writing flag
        }
        if(flash_write)                     // if data was written in
        {                                   // NVRAM area
            NVRAM_Update();                 // update FLASH memory
            flash_write = 0;                // clear FLASH writing flag
        }
    }

    SI=0;                                   // Clear SMBus interrupt flag
    TR0=0;                                  // Stop Timer0
    TH0=0;                                  // Reset Timer0 counter
    TL0=0;

    if (RXTX)                               // If RXTX flag is set, the last
    {                                       // state was a receiver-to-transmitter
                                            // transition;
       while(!TXMODE);                      // Wait for slave to enter transmit mode,
       STO = 0;                             // Clear the STO bit and the RXTX flag
       RXTX = 0;
    }
}


//-----------------------------------------------------------------------------
// Timer0 Interrupt Service Routine (ISR)
//-----------------------------------------------------------------------------
//
// A Timer0 interrupt indicates an SMBus SCL low timeout.
// The SMBus is disabled and re-enabled here
//
void Timer0_ISR (void) interrupt 1
{
    TR0 = 0;                                // Stop Timer0
    SMB0CF &= ~0x80;                        // Reset SMBus communication
    SMB0CF |= 0x80;
    smb_cnt=0;                              // Reset first data byte flag
}

#endif                                      // using SMBus communication


//-----------------------------------------------------------------------------
// Timer2 Interrupt Service Routine (ISR)
//-----------------------------------------------------------------------------
//
// Timer2 is driven by external oscillator and overflows every second
// The ISR calls IncRTC function to update the clock registers
//
void Timer2_ISR (void) interrupt 5
{
    TF2H = 0;                               // Clear Timer2 interrupt flag
    SQW = ~SQW;                             // Toggle P0^6 output
	IncRTC();								// Increment RTC registers;

#ifdef _UART_
    if(uart_display)                        // Auto-display mode
        UART_Print();                       // Send on UART time, date, and 
                                            // temperature
#endif

}


#ifdef _UART_                               // using UART communication


//-----------------------------------------------------------------------------
// UART Interrupt Service Routine (ISR)
//-----------------------------------------------------------------------------
//
// Used to implement the RTC UART communication protocol:
// "r xx yy" - read yy bytes from address xx 
// "w xx yy data" - write yy data bytes starting with address xx 
//
// The 's' key toggles auto-display mode, in which time, date and temperature
// are sent to UART every second, and can be displayed on hyperterminal
//
void UART_ISR (void) interrupt 4
{
//Received data interrupt.
	if (RI0 != 0)
	{
		RI0 = 0;							// clear the interrupt flag

		if(SBUF0=='s')                      // recived 's' character
            uart_display = ~uart_display;   // toggle display flag
        else
        if(SBUF0=='r')                      // received 'r' character
		{
			uart_read=1;                    // set read flag
			uart_write=0;                   // clear write flag
			uart_cnt=0;                     // clear UART counter
		}
		else
		if(SBUF0=='w')                      // received 'w' character
		{
			uart_write=1;                   // set write flag
			uart_read=0;                    // clear read flag
			uart_cnt=0;                     // clear UART counter
		}
		else
		if(uart_read || uart_write)
		{
            BCD_Time();                     // update the RTC registers
			if(SBUF0 != ' ')                // skip blanks
			{
				uart_cnt++;                 // increment UART counter
				switch(uart_cnt)
				{                                                                                 
					case 1:                 // first digit of RTC register addr.
						WORD_ADDR=10*(SBUF0-'0');
						break;
					case 2:                 // second digit of RTC register addr.
						WORD_ADDR+=(SBUF0-'0');
						break;
					case 3:                 // first digit of data length
						uart_len=10*(SBUF0-'0');
						break;
					case 4:                 // second digit of data length
						uart_len+=(SBUF0-'0');
						
                        if(uart_len > 64)   // invalid data length
                            uart_len = 64;

                        if(uart_read)       // if it's a read operation
						{
                            SBUF0=' ';      // send a blank and generate 
                                            // a transmission interrupt      
							uart_read=0;    // clear read flag
							uart_cnt=0;     // clear UART counter
						}
						break;
					default:
						if(uart_write)      // if it's a write operation

                            if(uart_len!=0) // there still is data to 
                                            // be received
                                UART_rec(SBUF0); 
						break;
				}
			}
		}
	}

//Transmitted data interrupt.
	if ( TI0 != 0 )
	{
        TI0 = 0;                            // clear the interrupt flag

        if(uart_len!=0 && (!uart_display))  // there still is data
            SBUF0 = UART_send();            // to be transmitted               
    }	
}


//-----------------------------------------------------------------------------
// UART_send
//-----------------------------------------------------------------------------
//
// Returns the data byte to be transmitted on UART
//
unsigned char UART_send(void)
{
	unsigned char result;                   // the data byte to be returned
    unsigned char uart_temp;                // temporary variable
    bit uart_end = 0;                       // end of transmission flag

    if(uart_sent==3*uart_len)               // send a newline after
        result = 0x0a;                      // the last data byte
    else
	if(uart_sent==3*uart_len+1)
    {
        uart_end=1;
        result = 0x0d;
    }
    else
	if( (uart_sent % 3) == 0)               // separate bytes of data with 
		result = ' ';                       // blanks
	else
	if( (uart_sent % 3) == 1)               // first digit of a byte
	{
        uart_temp = RTC_Read();             // read RTC reg. or NVRAM
        
        // convert to character the most significant nibble
		result = num2char((uart_temp >> 4) & 0x0f) ;
	}
	else
	if( (uart_sent % 3) == 2)               // second digit of a byte
	{
        // convert to character the least significant nibble
		result = num2char(uart_temp & 0x0f);
	}

	if(uart_end)                            // end of transmission
    {
        uart_len=0;                         // clear data length
    	uart_sent=0;                        // clear sent bytes counter
    }
    else
        uart_sent++;                        // increment sent bytes counter

    return result;
}


//-----------------------------------------------------------------------------
// UART_rec
//-----------------------------------------------------------------------------
//
// Updates the RTC registers and NVRAM with data received from UART
//
void UART_rec(unsigned char c)
{
    unsigned char uart_temp;                // temporary variable

    if( (uart_cnt-4) <= (2*uart_len) )      // there still is data to receive
	{       
		if((uart_cnt-4) & 1 == 1)           // first digit of a byte                    
        {
			uart_temp = char2num(c);        // convert the character received
            uart_temp <<= 4;                // to most significant nibble of
                                            // the data byte
        }
		else                                // second digit of a byte
		{
			uart_temp += char2num(c);       // add the least significant nibble
			RTC_Write(uart_temp);           // write to RTC reg. or NVRAM
            Bin_Time();
		}														

		if( (uart_cnt-4) == (2*uart_len) )  // last data byte was received
		{
			uart_write=0;                   // clear write flag
			uart_len=0;                     // clear data length
			uart_cnt=0;                     // clear UART counter
            if(flash_write)                 // the NVRAM area has been written
            {
                NVRAM_Update();             // save to FLASH the NVRAM buffer
                flash_write = 0;
            }
		}
	}
}


#endif                                      // using UART communication


//-----------------------------------------------------------------------------
// RTC_Init
//-----------------------------------------------------------------------------
//
// Initializes RTC registers and NVRAM buffer
//
void RTC_Init(void)
{
	unsigned char i;

	Seconds = 0;                            // initialize RTC to 00:00:00
    Minutes = 0;                            // Saturday, 01.01.2000
    Hours = 0;
    Day = 6;
    Date = 1;
    Month = 1;
    Year = 0;

    for(i=0;i<56;i++)                       // initialize NVRAM buffer
		RTC_NVRAM[i]=FLASH_NVRAM[i];
}



//-----------------------------------------------------------------------------
// Interrupt_Init
//-----------------------------------------------------------------------------
//
// Enables the interrupts and sets their priorities
//
void Interrupt_Init(void)
{
    PT2 = 0;                                // Timer2 interrupt low priority
    ET2 = 1;                                // Timer2 interrupt enable	
#ifdef _UART_
    PS0 = 0;                                // UART interrupt low priority
    ES0 = 1;                                // UART interrupt enable
#else
	PT0 = 1;                                // Timer0 interrupt high priority
	ET0 = 1;                                // Timer0 interrupt enable
    EIP1 &= ~0x01;                          // SMBUS interrupt low priority
    EIE1 |= 0x01;                           // SMBUS interrupt enable
#endif
        
    EA = 1;                                 // enable interrupts
}



//-----------------------------------------------------------------------------
// T0_WaitMS
//-----------------------------------------------------------------------------
//
// Configure Timer0 to wait for <ms> milliseconds using SYSCLK as its time
// base.
//
void T0_WaitMS (unsigned ms)
{
   TCON &= ~0x30;                           // Stop Timer0; Clear TF0
   TMOD &= ~0x0f;                           // 16-bit free run mode
   TMOD |=  0x01;

   CKCON |= 0x08;

   while (ms) {
      TR0 = 0;                              // stop Timer0
      TH0 = -(SYSCLK/1000 >> 8);            // overflow in 1ms
      TL0 = -(SYSCLK/1000);
      TF0 = 0;                              // clear overflow indicator
      TR0 = 1;                              // start Timer0
      while (!TF0);                         // wait for overflow
      ms--;                                 // update ms counter
   }

   TR0 = 0;                                 // Stop Timer0
}


#ifdef _UART_

//-----------------------------------------------------------------------------
// UART_Print
//-----------------------------------------------------------------------------
//
// Send on UART time, date and temperature
// 
void UART_Print(void)
{
    TI0=1;                                  // set transmission interrupt flag

    // Time: HH:MM:SS
    if(Hours & 0x40)                        // 12 hours format
    {
        if(Hours & 0x20)                    // PM
        {
            printf("%02d:%02d:%02d PM",(unsigned int)(Hours & 0x1F),
                    (unsigned int)Minutes, (unsigned int)Seconds);
        }
        else                                // AM
        {
            printf("%02d:%02d:%02d AM",(unsigned int)(Hours & 0x1F),
                    (unsigned int)Minutes, (unsigned int)Seconds);
        }
    }
    else                                    // 24 hours format
    {
        printf("%02d:%02d:%02d",(unsigned int)Hours, (unsigned int)Minutes,
                (unsigned int)Seconds);
    }
    
    // Date: day of the week, DD.MM.YYYY
    printf("\t%s, %02d.%02d.20%02d", day_names[Day], (unsigned int)Date,
            (unsigned int)Month, (unsigned int)Year);

    // Temperature
    printf("\tTemperature:%d.%02d deg C\r\n", temperature/100, temperature%100);
}

#endif

//-----------------------------------------------------------------------------
// end of tcrtc_main.c
//-----------------------------------------------------------------------------