//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by HID_Blinky.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_HID_Blinky_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDC_Connect                     1001
#define IDC_EDIT1                       1002
#define IDC_EDIT3                       1004
#define IDC_Rate                        1006
#define IDC_GetStats                    1007
#define IDC_Stat1                       1008
#define IDC_Stat2                       1009
#define IDC_DISCONNECT                  1011
#define IDC_T1LED1                      1018
#define IDC_T1LED2                      1019
#define IDC_T2LED1                      1020
#define IDC_T2LED2                      1021
#define IDC_T3LED1                      1022
#define IDC_T3LED2                      1023
#define IDC_T4LED4                      1025
#define IDC_T4LED2                      1026
#define IDC_T5LED1                      1027
#define IDC_T5LED2                      1028
#define IDC_T6LED1                      1029
#define IDC_T6LED2                      1030
#define IDC_T7LED1                      1031
#define IDC_T7LED2                      1032
#define IDC_T8LED1                      1033
#define IDC_T8LED2                      1034
#define IDC_UpdateCustomBlinking        1037
#define IDC_RADIOCustom                 1038
#define IDC_RADIOStandard               1039
#define IDC_CHECK_Blink_Enable          1042
#define IDC_SLIDER1                     1043
#define IDC_EDIT2                       1046
#define IDC_HELP_CONNECTION             1048
#define IDC_HELP_STANDARD_BLINK         1049
#define IDC_IDC_HELP_CUSTOM_BLINK       1050
#define IDC_BLINK_CONTROLS              1051
#define IDC_BUTTON5                     1053
#define IDC_HELP_STATS                  1053

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1049
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
