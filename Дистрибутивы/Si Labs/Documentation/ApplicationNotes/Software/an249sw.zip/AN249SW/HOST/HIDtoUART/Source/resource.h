//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by HIDtoUARTExample.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_HIDTOUARTEXAMPLE_DIALOG     102
#define IDR_MAINFRAME                   128
#define IDC_CONNECT                     1000
#define IDC_OUTPUT                      1001
#define IDC_INPUT                       1002
#define IDC_TRANSMITNOWCHECK            1003
#define IDC_TRANSMITNOW                 1004
#define IDC_CLEAROUTPUTBUTTON           1005
#define IDC_CLEARINPUTBUTTON            1006
#define IDC_OUTPUTFILEBUTTON            1007
#define IDC_INPUTFILEBUTTON             1008
#define IDC_OUTPUTFILEBOX               1009
#define IDC_INPUTFILEBOX                1010
#define IDC_RADIO_TERMINALMODE          1011
#define IDC_RADIO_TRANSFERMODE          1012
#define IDC_OUTPUTFROMDEVICESTATIC      1013
#define IDC_INPUTTODEVICESTATIC         1014
#define IDC_EDIT3                       1015
#define IDC_BYTESTRANSMITTEDBOX         1015
#define IDC_EDIT4                       1016
#define IDC_BYTESRECEIVEDBOX            1016
#define IDC_CLEARBYTESTXEDBUTTON        1017
#define IDC_CLEARBYTESRXEDBUTTON        1018
#define IDC_TRANSFERFILE                1019
#define IDC_CLEAROUTPUTFILECHECK        1020
#define IDC_INPUTTODEVICESTATIC2        1021
#define IDC_INPUTTODEVICESTATIC3        1022
#define IDC_DOWNLOADREPORTSBUTTON       1023
#define IDC_CLEARREPORTBUFFERBUTTON     1024
#define IDC_DOWNLOADPARSEDREPORTS       1025
#define IDC_DOWNLOADOUTREPORTSBUTTON2   1026
#define IDC_DOWNLOADPARSEDREPORTS2      1027
#define IDC_DOWNLOADPARSEDOUTREPORTS2   1027
#define IDC_TESTPATTERNBUTTOn           1028
#define IDC_CHECKRESULTSBUTTON          1029
#define IDC_PROGRESS1                   1030
#define IDC_EDIT1                       1031
#define IDC_BYTESPERREPORTBOX           1031
#define IDC_EDIT2                       1032
#define IDC_NUMBEROFREPORTSBOX          1032
#define IDC_BYTESTRANSMITTEDTEXT        1033
#define IDC_BYTESRECEIVEDTEXT           1034
#define IDC_GETBAUDRATEBUTTON           1035
#define IDC_BAUDRATEBOX                 1036
#define IDC_SETBAUDRATEBUTTON           1037
#define IDC_BAUDRATESTATIC              1038
#define IDC_RAWDATASTATIC               1039
#define IDC_PARSEDDATASTATIC            1040
#define IDC_REPORTLOGDESCRIPTIONSTATIC  1041
#define IDC_INASCIIBUTTON               1042
#define IDC_BUTTON2                     1043
#define IDC_OUTASCIIBUTTON              1043
#define IDC_TESTNOTESTATIC              1044
#define IDC_BYTESPERREPORTSTATIC        1045
#define IDC_NUMBEROFREPORTSSTATIC       1046

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1047
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
