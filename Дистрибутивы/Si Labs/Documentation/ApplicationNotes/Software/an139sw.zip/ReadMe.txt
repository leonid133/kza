AN039 - USB Firmware Programmer's Guide 

v1.1 Last updated 16 JUL 2003

To exercise the example firmware:

1. Extract the contents of the AN039.zip file (if using WinZip, use the "Extract" function to retain sub-directory information).
2. Open the Cygnal IDE (v1.72 or later).
3. From IDE menu Options->Debug Interface, select Cygnal 2-Wire.
4. Connect to the target C8051F32x device (Alt+C, or IDE menu Debug->Connect).
5. From the Project menu, select "Open Project" (a warning dialogue may appear; this is expected).
6. Browse to directory \AN039\Firmware and select file FirmwareProgramGuide.wsp.
7. Through IDE menu Project->Tool Chain Integration, select the path to your compiler and linker. The default is C:\Cygnal\IDEFiles\C51\Bin\.
8. Build the project (F7, or through IDE menu Project->Build/Make Project). 
9. Download the firmware (Alt+D).
10. Connect a USB cable between the target device and the host PC.
11. Run (F5, or IDE menu Debug->Go).
12. When Windows detects the device and the driver installation wizard opens:
   a. Choose "Search for a suitable driver for my device", and click Next.
   b. Check the box "Specify a location", and click Next.
   c. Browse to directory \AN039\Application and select the file CygnalInt.inf, and click OK.
   d. Follow the dialogue to finish driver installation.
13. After the driver has been installed, run the USBTest.exe application from directory \AN039\Application.


Notes:
- Firmware works with the Cygnal IDE v1.71 or later and the Keil C51 tool chain. Project and code modifications will be necessary for use with different tool chains.
- Compiler optimization emphasis is selected as "favor small code". This selection is necessary for the project to be compiled with the trial version of the Keil C51 Compiler (under 4k code space).
- If using the C8051F320TB target board, jumper J2 should be installed if the board is wall-powered; jumper J11 should be installed if bus-powered.
- Windows application and driver supports Win2K and XP only.
