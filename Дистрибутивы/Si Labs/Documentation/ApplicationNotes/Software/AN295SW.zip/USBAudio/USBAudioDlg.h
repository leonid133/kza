// USBAudioDlg.h : header file
//

#pragma once
#include "USBAudioDevice.h"

// CUSBAudioDlg dialog
class CUSBAudioDlg : public CDialog
{
// Construction
public:
	CUSBAudioDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_USBAUDIO_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

    CUSBAudioDevice IsoDevice;
	AudioData  m_AudioData;
	bool Connected;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg HCURSOR OnQueryDragIcon();

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedCancel();
	UINT m_DEBUG_InBuffer;
	UINT m_DEBUG_Out_Buffer;
	UINT m_DEBUG_3;
	long m_In_Count;
	long m_Out_Count;
};
