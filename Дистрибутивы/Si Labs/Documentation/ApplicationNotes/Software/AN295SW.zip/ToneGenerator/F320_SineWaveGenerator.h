//-----------------------------------------------------------------------------
// F320_SineWaveGenerator.h
//-----------------------------------------------------------------------------
// Copyright 2005 Silicon Laboratories, Inc.
// http://www.silabs.com
//
// Program Description:
//
// This is the header file for Tone Generator project.
//
// FID:            32X000073
// Target:         C8051F320
// Tool chain:     KEIL C51 7.0.0.1
//                 Silicon Laboratories IDE version 2.3
// Command Line:   See Readme.txt
// Project Name:   F320_TONE_GENERATOR
//
// Release 1.0
//    -Initial Revision (PD)
//    -05 JUL 2006
//

// Custom App
#ifndef F320_SINEWAVEGENERATOR_H_
#define F320_SINEWAVEGENERATOR_H_

void Handler_In3 (void);               // Prototype


#endif

//-----------------------------------------------------------------------------
// End Of File
//-----------------------------------------------------------------------------