//-----------------------------------------------------------------------------
// F320_Custom.h
//-----------------------------------------------------------------------------
// Copyright 2005 Silicon Laboratories, Inc.
// http://www.silabs.com
//
// Program Description:
//
// This is the header file for the USB Audio firmware template.
//
// FID:            32X000054
// Target:         C8051F320
// Tool chain:     KEIL C51 7.0.0.1
//                 Silicon Laboratories IDE version 2.3
// Command Line:   See Readme.txt
// Project Name:   F320_DEFAULT
//
// Release 1.0
//    -Initial Revision (PD)
//    -05 JUL 2006
//

#ifndef F320_CUSTOM_H_
#define F320_CUSTOM_H_

void Handle_In3(void);


#endif

//-----------------------------------------------------------------------------
// End Of File
//-----------------------------------------------------------------------------