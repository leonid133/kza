#if !defined(AFX_SETTINGSDLG_H__62F93E22_C850_4A83_91E5_73C0F5730B76__INCLUDED_)
#define AFX_SETTINGSDLG_H__62F93E22_C850_4A83_91E5_73C0F5730B76__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SettingsDlg.h : header file
//

#include "resource.h"
#include "FMRadioDevice.h"

/////////////////////////////////////////////////////////////////////////////
// CSettingsDlg dialog

class CSettingsDlg : public CDialog
{
// Construction
public:
	CSettingsDlg(CWnd* pParent = NULL);   // standard constructor

	RadioData	m_RadioData;
	int			m_RadioIndex;

// Dialog Data
	//{{AFX_DATA(CSettingsDlg)
	enum { IDD = IDD_DIALOG_SETTINGS };
	CSliderCtrl	m_ScanTime;
	CSliderCtrl	m_SeekThreshold;
	CSliderCtrl	m_BufferSize;
	BOOL	m_MonoStereo;
	BOOL	m_AlwaysOnTop;
	BOOL	m_ShowInTitleBar;
	BOOL	m_ShowInTray;
	BOOL	m_MuteOnStartup;
	double	m_Preset1;
	double	m_Preset2;
	double	m_Preset3;
	double	m_Preset4;
	double	m_Preset5;
	double	m_Preset6;
	double	m_Preset7;
	double	m_Preset8;
	double	m_Preset9;
	double	m_Preset10;
	double	m_Preset11;
	double	m_Preset12;
	BOOL	m_IgnoreABFlag;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSettingsDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSettingsDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnButtonAbout();
	afx_msg void OnButtonAudioinput();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SETTINGSDLG_H__62F93E22_C850_4A83_91E5_73C0F5730B76__INCLUDED_)
