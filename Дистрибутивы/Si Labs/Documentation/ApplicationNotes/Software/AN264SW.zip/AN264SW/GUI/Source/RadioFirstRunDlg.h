#if !defined(AFX_RADIOFIRSTRUNDLG_H__F6B0C9EC_2118_4BA3_B327_485085969B44__INCLUDED_)
#define AFX_RADIOFIRSTRUNDLG_H__F6B0C9EC_2118_4BA3_B327_485085969B44__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RadioFirstRunDlg.h : header file
//

#include "resource.h"
#include "FMRadioDevice.h"

/////////////////////////////////////////////////////////////////////////////
// CRadioFirstRunDlg dialog

class CRadioFirstRunDlg : public CDialog
{
// Construction
public:
	CRadioFirstRunDlg(CWnd* pParent = NULL);   // standard constructor

	RadioData	m_RadioData;

// Dialog Data
	//{{AFX_DATA(CRadioFirstRunDlg)
	enum { IDD = IDD_DIALOG_FIRSTRUN };
	double	m_Preset1;
	double	m_Preset2;
	double	m_Preset3;
	double	m_Preset4;
	double	m_Preset5;
	double	m_Preset6;
	double	m_Preset7;
	double	m_Preset8;
	double	m_Preset9;
	double	m_Preset10;
	double	m_Preset11;
	double	m_Preset12;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRadioFirstRunDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CRadioFirstRunDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RADIOFIRSTRUNDLG_H__F6B0C9EC_2118_4BA3_B327_485085969B44__INCLUDED_)
