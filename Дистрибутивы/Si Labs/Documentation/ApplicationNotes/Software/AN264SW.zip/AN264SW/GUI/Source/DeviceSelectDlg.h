#if !defined(AFX_DEVICESELECTDLG_H__6904614B_41D0_4941_A36D_D31C05B5870B__INCLUDED_)
#define AFX_DEVICESELECTDLG_H__6904614B_41D0_4941_A36D_D31C05B5870B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DeviceSelectDlg.h : header file
//

#include "resource.h"
#include <vector>

/////////////////////////////////////////////////////////////////////////////
// CDeviceSelectDlg dialog

class CDeviceSelectDlg : public CDialog
{
// Construction
public:
	CDeviceSelectDlg(std::vector<CString>* deviceList = NULL, int lastKnownIndex = -1, CWnd* pParent = NULL);   // standard constructor

	int GetIndex();

// Dialog Data
	//{{AFX_DATA(CDeviceSelectDlg)
	enum { IDD = IDD_DIALOG_DEVICESELECT };
	CListBox	m_DeviceList;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDeviceSelectDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	std::vector<CString>* m_pDeviceList;
	int m_Index;

	// Generated message map functions
	//{{AFX_MSG(CDeviceSelectDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnDblclkListDevice();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DEVICESELECTDLG_H__6904614B_41D0_4941_A36D_D31C05B5870B__INCLUDED_)
