// RadioFirstRunDlg.cpp : implementation file
//

#include "stdafx.h"
#include "USBRadio.h"
#include "RadioFirstRunDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRadioFirstRunDlg dialog


CRadioFirstRunDlg::CRadioFirstRunDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CRadioFirstRunDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRadioFirstRunDlg)
	m_Preset1 = 88.0;
	m_Preset2 = 89.0;
	m_Preset3 = 90.0;
	m_Preset4 = 91.0;
	m_Preset5 = 92.0;
	m_Preset6 = 93.0;
	m_Preset7 = 94.0;
	m_Preset8 = 95.0;
	m_Preset9 = 96.0;
	m_Preset10 = 97.0;
	m_Preset11 = 98.0;
	m_Preset12 = 99.0;
	//}}AFX_DATA_INIT
}


void CRadioFirstRunDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRadioFirstRunDlg)
	DDX_Text(pDX, IDC_EDIT_PRESET1, m_Preset1);
	DDV_MinMaxDouble(pDX, m_Preset1, 76., 108.);
	DDX_Text(pDX, IDC_EDIT_PRESET2, m_Preset2);
	DDV_MinMaxDouble(pDX, m_Preset2, 76., 108.);
	DDX_Text(pDX, IDC_EDIT_PRESET3, m_Preset3);
	DDV_MinMaxDouble(pDX, m_Preset3, 76., 108.);
	DDX_Text(pDX, IDC_EDIT_PRESET4, m_Preset4);
	DDV_MinMaxDouble(pDX, m_Preset4, 76., 108.);
	DDX_Text(pDX, IDC_EDIT_PRESET5, m_Preset5);
	DDV_MinMaxDouble(pDX, m_Preset5, 76., 108.);
	DDX_Text(pDX, IDC_EDIT_PRESET6, m_Preset6);
	DDV_MinMaxDouble(pDX, m_Preset6, 76., 108.);
	DDX_Text(pDX, IDC_EDIT_PRESET7, m_Preset7);
	DDV_MinMaxDouble(pDX, m_Preset7, 76., 108.);
	DDX_Text(pDX, IDC_EDIT_PRESET8, m_Preset8);
	DDV_MinMaxDouble(pDX, m_Preset8, 76., 108.);
	DDX_Text(pDX, IDC_EDIT_PRESET9, m_Preset9);
	DDV_MinMaxDouble(pDX, m_Preset9, 76., 108.);
	DDX_Text(pDX, IDC_EDIT_PRESET10, m_Preset10);
	DDV_MinMaxDouble(pDX, m_Preset10, 76., 108.);
	DDX_Text(pDX, IDC_EDIT_PRESET11, m_Preset11);
	DDV_MinMaxDouble(pDX, m_Preset11, 76., 108.);
	DDX_Text(pDX, IDC_EDIT_PRESET12, m_Preset12);
	DDV_MinMaxDouble(pDX, m_Preset12, 76., 108.);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRadioFirstRunDlg, CDialog)
	//{{AFX_MSG_MAP(CRadioFirstRunDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRadioFirstRunDlg message handlers

BOOL CRadioFirstRunDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	//Initialize to defaults to begin

	m_Preset1 = m_RadioData.preset[0];
	m_Preset2 = m_RadioData.preset[1];
	m_Preset3 = m_RadioData.preset[2];
	m_Preset4 = m_RadioData.preset[3];
	m_Preset5 = m_RadioData.preset[4];
	m_Preset6 = m_RadioData.preset[5];
	m_Preset7 = m_RadioData.preset[6];
	m_Preset8 = m_RadioData.preset[7];
	m_Preset9 = m_RadioData.preset[8];
	m_Preset10 = m_RadioData.preset[9];
	m_Preset11 = m_RadioData.preset[10];
	m_Preset12 = m_RadioData.preset[11];

	CheckRadioButton(IDC_RADIO_USA, IDC_RADIO_OTHER, IDC_RADIO_USA);

	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CRadioFirstRunDlg::OnOK() 
{
	//On OK, update the settings, and store the settings for options chosen by the user
	if (UpdateData(TRUE))
	{
		m_RadioData.firstRun = false;
		
		switch (GetCheckedRadioButton(IDC_RADIO_USA, IDC_RADIO_OTHER))
		{
		case IDC_RADIO_USA			:	m_RadioData.band = DATA_BAND_875_108MHZ;
										m_RadioData.spacing = DATA_SPACING_200KHZ;
										m_RadioData.deemphasis = DATA_DEEMPHASIS_75;
										break;

		case IDC_RADIO_EUROPE		:	m_RadioData.band = DATA_BAND_875_108MHZ;
										m_RadioData.spacing = DATA_SPACING_100KHZ;
										m_RadioData.deemphasis = DATA_DEEMPHASIS_50;
										break;

		case IDC_RADIO_JAPAN		:	m_RadioData.band = DATA_BAND_76_90MHZ;
										m_RadioData.spacing = DATA_SPACING_100KHZ;
										m_RadioData.deemphasis = DATA_DEEMPHASIS_75;
										break;

		case IDC_RADIO_AUSTRALIA	:	m_RadioData.band = DATA_BAND_875_108MHZ;
										m_RadioData.spacing = DATA_SPACING_200KHZ;
										m_RadioData.deemphasis = DATA_DEEMPHASIS_50;
										break;

		default						:	m_RadioData.band = DATA_BAND_875_108MHZ;
										m_RadioData.spacing = DATA_SPACING_100KHZ;
										m_RadioData.deemphasis = DATA_DEEMPHASIS_75;
										break;
		}

		m_RadioData.preset[0] = m_Preset1;
		m_RadioData.preset[1] = m_Preset2;
		m_RadioData.preset[2] = m_Preset3;
		m_RadioData.preset[3] = m_Preset4;
		m_RadioData.preset[4] = m_Preset5;
		m_RadioData.preset[5] = m_Preset6;
		m_RadioData.preset[6] = m_Preset7;
		m_RadioData.preset[7] = m_Preset8;
		m_RadioData.preset[8] = m_Preset9;
		m_RadioData.preset[9] = m_Preset10;
		m_RadioData.preset[10] = m_Preset11;
		m_RadioData.preset[11] = m_Preset12;

		CDialog::OnOK();
	}
}
