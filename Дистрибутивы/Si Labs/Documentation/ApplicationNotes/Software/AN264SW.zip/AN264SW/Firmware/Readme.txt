-------------------------------------------------------------------------------
 Readme.txt
-------------------------------------------------------------------------------

Copyright 2006 Silicon Laboratories, Inc.
http://www.silabs.com

Program Description:
-------------------

The purpose of this program is to demonstrate the C8051F320 isochronous USB
capability while highlighting the audio quality of the Si470x FM tuner.


Target and Tool Chain Information:
---------------------------------

FID:           32X000044
Target:        C8051F320
Tool chain:    KEIL C51 7.0.0.1 / KEIL A51 7.0.0.1 / KEIL BL51 5.0.0.1
               Silicon Laboratories IDE version 2.3
Project Name:  F320_FM_Radio


Command Line Options:
--------------------

Assembler   :  XR GEN DB EP NOMOD51
Compiler    :  DB OE
Linker      :  CODE(?CO?F320_COMMAND_INTERPRETER(0x3600),
               ?PR?RADIO_FLASHER?F320_COMMAND_INTERPRETER(0x3800), 
               ?PR*F320_COMMAND_INTERPRETER) RS(256) PL(68) PW(78)


File List:
---------

Readme.txt                          this file

c8051F320.h                         SFR Header file
F320_FM_RadioMain.h                 Main Project Header
F320_LED_Control.h                  LED Header
F320_Si470x_Interface.h             Si4701 Header
F320_USB_Common.h                   USB Common Header
F320_USB_Descriptor.h               USB Descriptor Types
F320_USB_Register.h                 USB Register Header

F320_Command_Interpretter.c         Code Loader Module
F320_FM_RadioMain.c                 Main Module
F320_LED_Control.c                  LED Module
F320_TimeCritical.asm               Mixed C/ASM created by F320_TimeCritical.c
F320_TimeCritical.c                 Mixed C/ASM
F320_USB_Class_Specific_Requests.c  USB Audio and HID Class Requests
F320_USB_Common.c                   Common USB Functions Module
F320_USB_Descriptors.c              Defines USB Descriptors
F320_USB_Standard_Requests.c        Chapter Nine of USB Spec Standard Requests


Release Information:
-------------------

Release 1.1
   -Changed Oscillator_Init to start clock multiplier correctly (DM)
   -Changed compiler optimization to 8 to locate all command interpreter
   code together.  Level 9 placed a common block incorrectly (DM)
   -Changed linker command syntax to place any common blocks from
   command_interpreter module in correct code location (DM)
   -Increased software version to 7 (DM)
   -16 JAN 2006

Release 1.0
   -Initial Release

-------------------------------------------------------------------------------
 End Of File
-------------------------------------------------------------------------------