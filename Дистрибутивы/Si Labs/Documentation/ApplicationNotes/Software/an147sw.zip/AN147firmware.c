//-----------------------------------------------------------------------------
// Wireless Voice Transmitter/Receiver
//-----------------------------------------------------------------------------
//
// AUTH: PD
// DATE:
//
// This software system is written to control the PCB designed with AN 147.
//

//-----------------------------------------------------------------------------
// Includes
//-----------------------------------------------------------------------------
#include <c8051f330.h>                 // SFR declarations
#include <intrins.h>                   // includes the _nop_() command

//-----------------------------------------------------------------------------
// Global CONSTANTS
//-----------------------------------------------------------------------------


#define SYSCLK 24500000                // speed of internal clock
#define SAMPLE_RATE 8000               // sampling rate for the ADC
#define SPI_DATARATE 153600            // used for timing in SPI state machine

#define TransmitFIFO_FIFOSIZE   236         // sets the size of data buffers
#define ReceiveFIFO_FIFOSIZE   236
#define ADCRXFIFO_FIFOSIZE 10
#define DACTXFIFO_FIFOSIZE 10


#define DAC_UPDATERATE 8000             // rate of DAC sample output

// Transmission-Related Constants
#define RXTX_BytesOfData 200           // number of bytes of compressed audio
                                       // data to be transmitted per data
                                       // packet


#define TransmitFIFO_TARGET 200             // target size of TransmitFIFO, used to make
                                       // sampling rate adjustments to avoid
                                       // FIFO over- and underflows

#define ReceiveFIFO_TARGET 10              // target size of ReceiveFIFO, used to make
                                       // sampling rate adjustments to avoid
                                       // FIFO over- and underflows


#define RXTX_NoPreambleLevel 20        // consecutive number of data packets
                                       // that will be missed before the
                                       // RF signal is considered lost and
                                       // transmission shuts down


#define I_TX 0x02                      // this value is written to the RF
                                       // transceiver's Interface register when
                                       // the RF switch is to be placed in the
                                       // TX position
#define I_RX 0x01                      // this value is written to the RF
                                       // transceiver's Interface register when
                                       // the RF switch is to be placed in the
                                       // RX position



#define Audio_QuietThreshold 2         // difference threshold in ADC codes
                                       // between two consecutive samples that
                                       // is used to determine whether a
                                       // signal is "loud" enough to transmit


#define AudioStateQuietToLoud 10       // number of instances where
                                       // the difference between consecutive
                                       // ADC samples is GREATER than
                                       // <Audio_QuietThreshold> that must be
                                       // accumulated before a "quiet"
                                       // audio signal should be considered
                                       // "loud"

#define AudioStateLoudToQuiet 400      // number of instances where
                                       // the difference between consecutive
                                       // ADC samples is LESS than
                                       // <Audio_QuietThreshold> that must
                                       // CONSECUTIVELY occur before a "loud"
                                       // audio  signal should be considered
                                       // "quiet"

#define RX_MinBytesInitPreamble 5      // number of consecutively received
                                       // preamble bytes that must be received
                                       // before the incoming data for the
                                       // first received packet can be
                                       // considered valid

#define TX_NumBytesInitPreamble 50     // number of preamble bytes sent during
                                       // a RXTX_Master's first data packet
                                       // transmission

#define TX_NumBytesPreamble 8          // number of preamble bytes transmitted
                                       // before each data packet, excluding
                                       // the RXTX_Master's first packet

#define RX_MinBytesPreamble 2         // minimum number of preamble bytes
                                       // the must be received before incoming
                                       // data can be considered valid,
                                       // excluding the reception of the
                                       // RXTX_Master's first packet


#define RXTX_SyncWordSize 3            // used to re-sync the slave <SPI_Timer>

#define Audio_StateSize   1            // used to re-sync the slave <SPI_Timer>



#define DPCM_MULTIPLIER 2              // used to amplify the decompressed
                                       // audio samples


// 10-bit DPCM quantization codes
#define low_low 1
#define low_mid 2
#define low_high 4
#define middle 8
#define high_low 16
#define high_mid 32
#define high_high 64


//-----------------------------------------------------------------------------
// CC1020 Registers
//-----------------------------------------------------------------------------
#define  MAIN            0x00
#define  INTERFACE       0x01
#define  RESETT          0x02
#define  SEQUENCING      0x03
#define  FREQ_2A         0x04
#define  FREQ_1A         0x05
#define  FREQ_0A         0x06
#define  CLOCK_A         0x07
#define  FREQ_2B         0x08
#define  FREQ_1B         0x09
#define  FREQ_0B         0x0A
#define  CLOCK_B         0x0B
#define  VCO             0x0C
#define  MODEM           0x0D
#define  DEVIATION       0x0E
#define  AFC_CONTROL     0x0F
#define  FILTER          0x10
#define  VGA1            0x11
#define  VGA2            0x12
#define  VGA3            0x13
#define  VGA4            0x14
#define  LOCK            0x15
#define  FRONTEND        0x16
#define  ANALOG          0x17
#define  BUFF_SWING      0x18
#define  BUFF_CURRENT    0x19
#define  PLL_BW          0x1A
#define  CALIBRATE       0x1B
#define  PA_POWER        0x1C
#define  MATCH           0x1D
#define  PHASE_COMP      0x1E
#define  GAIN_COMP       0x1F
#define  POWERDOWN       0x20
#define  TEST1           0x21
#define  TEST2           0x22
#define  TEST3           0x23
#define  TEST4           0x24
#define  TEST5           0x25
#define  TEST6           0x26
#define  TEST7           0x27
#define  STATUS          0x40
#define  RESET_DONE      0x41
#define  RSS             0x42
#define  AFC             0x43
#define  GAUSS_FILTER    0x44
#define  STATUS1         0x45
#define  STATUS2         0x46
#define  STATUS3         0x47
#define  STATUS4         0x48
#define  STATUS5         0x49
#define  STATUS6         0x4A
#define  STATUS7         0x4B

#define  TEST_NFC        0x28


//-----------------------------------------------------------------------------
// 16-bit SFR Definitions for 'F33x
//-----------------------------------------------------------------------------

sfr16 DP       = 0x82;                 // data pointer
sfr16 TMR3RL   = 0x92;                 // Timer3 reload value
sfr16 TMR3     = 0x94;                 // Timer3 counter
sfr16 IDA0     = 0x96;                 // IDAC0 data
sfr16 ADC0     = 0xbd;                 // ADC0 data
sfr16 ADC0GT   = 0xc3;                 // ADC0 Greater-Than
sfr16 ADC0LT   = 0xc5;                 // ADC0 Less-Than
sfr16 TMR2RL   = 0xca;                 // Timer2 reload value
sfr16 TMR2     = 0xcc;                 // Timer2 counter
sfr16 PCA0CP1  = 0xe9;                 // PCA0 Module 1 Capture/Compare
sfr16 PCA0CP2  = 0xeb;                 // PCA0 Module 2 Capture/Compare
sfr16 PCA0     = 0xf9;                 // PCA0 counter
sfr16 PCA0CP0  = 0xfb;                 // PCA0 Module 0 Capture/Compare



//-----------------------------------------------------------------------------
// Function PROTOTYPES
//-----------------------------------------------------------------------------
void SYSCLK_Init (void);               // initialize system clock to 24.5 MHz
void PORT_Init (void);                 // initialize crossbar
void ADC0_Init (void);                 // ADC captures on Tmr2 overflows
                                       // interrupts enabled
void Timer0_Init(void);                // used for  WaitUS()
void Timer2_Init (unsigned int);       // ADC start-of-conversion clock source
void Timer3_Init(unsigned int);        // sets DAC output rate
void IDAC0_Init(void);                 // enables IDAC output on P0.1
void SPI_Init(void);                   // enable 3-wire Slave SPI for RF trans.
                                       // DATA interface
void Variables_Init(void);             // set global variables to reset values

void PCA0_Init(void);                  // configure PCA0 to edge-triggered
                                       // capture mode

void Timer3_ISR (void);                // updates the DAC
void UART0_ISR (void);                 // RX and TX with RF transceiver
void ADC0_ISR (void);                  // checks for a quiet signal,
                                       // pushes samples onto ADCRXFIFO
// FIFO Routines
unsigned char TransmitFIFO_Pull();          // pulls compressed sample to be TXed
unsigned char ReceiveFIFO_Pull();          // pulls RXed compressed sample
unsigned short ADCRXFIFO_Pull();       // pulls ADC sample
unsigned short DACTXFIFO_Pull();       // pulls decompressed sample
void TransmitFIFO_Push(unsigned char);      // pushes compressed sample to be TXed
void ReceiveFIFO_Push(unsigned char);      // pushes RXed compressed sample
void ADCRXFIFO_Push(unsigned short);   // pushes ADC sample
void DACTXFIFO_Push(unsigned short);   // pushes decompressed sample
unsigned short ADCRXFIFO_Newest(void); // returns the value most recently
                                       // pushed onto the ADC FIFO, but does
                                       // not alter any of the index values

void CLEAR_FIFOS(void);                // resets all FIFOs to default values

// DPCM Compression Algorithms
void DPCM_Decompress(void);            // Compresses an ADC sample
void DPCM_Compress(void);              // Decompresses received samples

// RF Transceiver Register Routines
void SETREG(unsigned char, unsigned char);
                                       // updates register to value parameter

unsigned char READREG(unsigned char);  // return register value
unsigned char CC1020_Init(void);       // initializes RF transceiver
void CC1020_SwitchToRX(void);          // sets RF transceiver settings to RX
void CC1020_SwitchToTX(void);          // sets RF transceiver settings to TX
void C1020_POWERDOWN(void);            // shuts down components of the RF
                                       // transceiver to conserve power

void ASLEEP(void);                     // function that runs when the
                                       // communications channel is idle
void WaitUS(unsigned int);             // function will delay controller
                                       // for a set number of microseconds
void WaitMS(unsigned int);

void FIFO_ManagementRoutine(void);     // encapsulates all foreground function
                                       // calls concerning buffers, and
                                       // all checks and tests on buffer
                                       // sizes

void RXTX_InitMaster(void);
void RXTX_InitSlave(void);


//-----------------------------------------------------------------------------
// User-Defined Types
//-----------------------------------------------------------------------------


typedef union USHORT {                 // access a short variable as two
      unsigned short S;                // 8-bit integer values
      unsigned char C[2];
   } USHORT;

enum Logic{ FALSE, TRUE};

enum RXTX_Classes{
   RXTX_Master,
   // designates the endpoint that initiates the creation of the Communication
   // Channel

   RXTX_Slave,
   // designates the endpoint that joins an initiated Communication Channel

   RXTX_Searching
   // designates an endpoint that is searching for a master

};

typedef enum RXTX_StateMachineStates {

   RX_SearchForMaster,
   // Search for <RX_MinBytesInitPreamble> consecutive preamble bytes in
   // the RF transceiver's output data stream

   TX_InitPreamble,
   // Transmit <TX_NumBytesInitPreamble> preamble bytes before transmitting
   // the first data packet

   TX_Preamble,
   // Transmit <TX_NumBytesPreamble> preamble bytes

   TX_SyncWord,
   // Transmit sync word 0xFFFFEE

   TX_SwitchTime,
   // Delay for a time period specified in the SPI ISR's Transmission State
   // Machine, using the timer variable <SPI_Timer> as the time base

   TX_AudioState,
   // Transmit local shutdown state

   TX_Data,
   // Transmit <RXTX_BytesOfData> bytes from the TransmitFIFO

   RX_Preamble,
   // Search for <RX_MinBytesPreamble> consecutive bytes of received preamble

   RX_SyncWord,
   // Search for and synchronize receiver to the sync word 0xFFFFEE

   RX_AudioState,
   // Receive the remote (transmitter's) Shutdown State

   RX_Data,
   // Receive <RXTX_BytesOfData> bytes and push each to the ReceiveFIFO

   RXTX_TimeOut,
   // state is entered when <SPI_TIMER> times out.  Variable
   // <TimeOut_EntryMode> should be set before entering state <RXTX_TimeOut>


   Switch_ToTX01,
   Switch_ToTX02,
   Switch_ToTX03,
   Switch_ToTX04,
   Switch_ToTX05,
   Switch_ToTX06,
   Switch_ToTX07,
   // These states configure the RF Transceiver to its transmit mode

   Switch_ToRX01,
   Switch_ToRX02,
   Switch_ToRX03,
   Switch_ToRX04,
   Switch_ToRX05,
   Switch_ToRX06,
   // These states configure the RF Transceiver to its receive mode

   RXTX_WaitForTimeOut,
   // this state will pause state machine progress until the
   // RXTX_StateMachine's time base <SPI_Timer> reaches its time-out value

   RXTX_Shutdown,
   // Entered when the Communication Channel is to be terminated

   Uninitialized
   // Reset state of the RF state machine

} RXTX_StateMachineStates;

typedef enum TimeOut_EntryModes{
   TimeOut_RXSuccessful,
   // indicates that the state machine has just successfully completed the
   // reception of a data packet

   TimeOut_TXSuccessful,
   // indicates that the state machine has just successfully completed the
   // transmission of a data packet

   TimeOut_RXNoPreamble,
   // state machine failed to find the minimum number of bytes of preamble
   // needed to determine that a valid data packet has been received before
   // SPI_Timer reached its terminal value

   TimeOut_RXNoSyncWord
   // state machine failed to find a valid Sync Word before SPI_Timer reached
   // its terminal value

} TimeOut_EntryModes;



typedef enum Audio_States{
   Audio_Quiet = 0x10,
   // state indicates that audio is below the audible threshold

   Audio_Loud = 0x30,
   // audio is above audible threshold

   Audio_ChannelShutdown = 0x40
   // special state transmitted after both Endpoints' Audio States have
   // been set to

} Audio_States;


//-----------------------------------------------------------------------------
// Global Variables
//-----------------------------------------------------------------------------


unsigned char code RegValue[] = {
//      CLOCK_A, (this register is configured separately inside CC1020_Init() )
//      0x25,

//    CLOCK_B,
      0x25,

//    VCO,
      0x44,

//    MODEM,
      0x50,

//    DEVIATION,
      0x5A,

//    AFC_CONTROL,
      0xCC,

//    FILTER,
      0x80,

//    VGA1,
      0x65,

//    VGA2,
      0x57,

//    VGA3,
      0x34,

//    VGA4,
      0x3E,

//    LOCK,
      0x20,

//    FRONTEND,
      0x76,

//    ANALOG,
      0x86,

//    BUFF_SWING,
      0x50,

//    BUFF_CURRENT,
      0x25,

//    PLL_BW,
      0xAE,

//    CALIBRATE,
      0x35,

//    PA_POWER,
      0xFF,

//    MATCH,
      0x22,

//    PHASE_COMP,
      0x00,

//    GAIN_COMP,
      0x00,

//    POWERDOWN,
      0x00,

//    TEST1,
      0x4D,

//    TEST2,
      0x10,

//    TEST3,
      0x06,

//    TEST4,
      0x00,

//    TEST5,
      0x40,

//    TEST6,
      0x00,

//    TEST7,
      0x00

};


// 1/2 Period Sine Wave Table
static char code Audio_SineTable[16] = {
   0x00,0x18,0x30,0x47,0x5a,0x6a,0x76,0x7d,
   0x7f,0x7d,0x76,0x6a,0x5a,0x47,0x30,0x18
};



// the mapping from DPCM quantization values to dpcm codes (array index)
short code Q_VALUES[16] = {0,
                     -high_high,
                     -high_mid,
                     -high_low,
                     -middle,
                     -low_high,
                     -low_mid,
                     -low_low,
                     0,
                     low_low,
                     low_mid,
                     low_high,
                     middle,
                     high_low,
                     high_mid,
                     high_high};

// CC1020 Interface Bits
sbit PALE = P0^2;
sbit DIO = P1^2;
sbit DCLK = P1^0;
sbit PCLK = P0^3;
sbit PDI = P0^6;
sbit PDO = P0^7;

// AN147 PCB Pins
sbit DEBUG= P1^4;
sbit LED1 = P1^5;
sbit LED2 = P1^6;
sbit SW2  = P1^7;


// RX/TX State Machine variables, flags
RXTX_StateMachineStates RXTX_StateMachine;
void CLEAR_FIFOS(void);                // resets all FIFOs to default values

bit RXTX_ResetVariables;               // indicates to RF state machines that
                                       // variables should be re-initialized

unsigned char RXTX_MasterSelect;       // determines whether RF state machine
                                       // behaves as slave or master across
                                       // the RF link

bit RXTX_RunInitSlave;                 // signals RF state machine to run
                                       // as slave

bit SPI_TimeOutEvent;                  // set when SPI_Timer reaches its
                                       // terminal value

unsigned int SPI_Timer;                // time base for RF state machine

unsigned char SPI_DataBytes;           // counts number of data bytes
                                       // transmitted or received during
                                       // current packet time

int DAC_Error;                         // used to measure how far buffers are
                                       // from defined ideal value

unsigned char RXTX_NoPreambleCount;    // counts number of consecutive packet
                                       // receptions that have failed due to
                                       // finding no preamble bytes

bit SPI_TimerEnable;                   // signals that SPI_Timer should
                                       // be incremented

TimeOut_EntryModes TimeOut_EntryMode;  // indicates whether packet
                                       // reception/transmission was successful
                                       // or unsuccessful

Audio_States Audio_LocalState;         // shows whether audio signal is
Audio_States Audio_RemoteState;        // "quiet" or "loud"

bit RXTX_Indicator;                    // shows whether RF state machine is in
                                       // transmit or receive mode

bit OutputByteReady;                   // toggles to indicate whether both
                                       // nibbles of OutputByte inside
                                       // DPCM_Compress contain valid compressed
                                       // data

// TransmitFIFO Variables
unsigned char TransmitFIFO_COUNT;
bit TransmitFIFO_EMPTY;
bit TransmitFIFO_OF;
bit TransmitFIFO_UF;
bit TransmitFIFO_FULL;
bit CC1020_StartUpCall;
unsigned char idata TransmitFIFO_FIRST;
unsigned char idata TransmitFIFO_LAST;
unsigned char xdata TransmitFIFO_FIFO[TransmitFIFO_FIFOSIZE];


// ReceiveFIFO Variables
unsigned char ReceiveFIFO_COUNT;
bit ReceiveFIFO_EMPTY;
bit ReceiveFIFO_OF;
bit ReceiveFIFO_UF;
bit ReceiveFIFO_FULL;
unsigned char idata ReceiveFIFO_FIRST;
unsigned char idata ReceiveFIFO_LAST;
unsigned char xdata ReceiveFIFO_FIFO[ReceiveFIFO_FIFOSIZE];



// ADCRXFIFO Variables
unsigned char ADCRXFIFO_COUNT;
bit ADCRXFIFO_EMPTY;
bit ADCRXFIFO_OF;
bit ADCRXFIFO_UF;
bit ADCRXFIFO_FULL;
unsigned char idata ADCRXFIFO_FIRST;
unsigned char idata ADCRXFIFO_LAST;
int xdata ADCRXFIFO_FIFO[ADCRXFIFO_FIFOSIZE];


// DACTXFIFO Variables
unsigned char DACTXFIFO_COUNT;
bit DACTXFIFO_EMPTY;
bit DACTXFIFO_OF;
bit DACTXFIFO_UF;
bit DACTXFIFO_FULL;
bit DACTXFIFO_DECOMPRESS_HALT;
unsigned char idata DACTXFIFO_FIRST;
unsigned char idata DACTXFIFO_LAST;
unsigned int xdata DACTXFIFO_FIFO[DACTXFIFO_FIFOSIZE];



//-----------------------------------------------------------------------------
// Macros
//-----------------------------------------------------------------------------

// configures Cross Bar to route SPI to port pins
#define RouteSPI() P1SKIP &= ~0x07;  P1MDOUT |= 0x10;  XBR1 = 0x41;  XBR0 = 0x02

// configures Cross Bar to route PCA0 module 0 to port pins
#define RoutePCA() P1SKIP &= ~0x07;  P1MDOUT &=~0x10;  P1SKIP |=  0x03;  XBR0 = 0x00;  XBR1 = 0x41

// used in RF state machine to determine SPI_Timer timing thresholds
#define SPI_ms(x) (x * SPI_DATARATE / 8) / 1000
#define SPI_us(x) ((x * SPI_DATARATE / 8) / 1000) / 1000

#define SPI_SlopTimeOut SPI_ms(1) + SPI_us(500)

#define SPI_CalibrationWaitTime SPI_ms(1)

#define SPI_PacketTime SPI_ms(17)

#define SPI_TX()  P1MDIN |=  0x02; P1MDOUT |=  0x02
#define SPI_RX()  P1MDIN &= ~0x02; P1MDOUT &= ~0x02

//-----------------------------------------------------------------------------
// MAIN Routine
//-----------------------------------------------------------------------------
void main (void) {

   PCA0MD &= ~0x40;                    // disable watchdog timer

   PORT_Init();                        // initialize and enable the Crossbar
   SYSCLK_Init();                      // initialize oscillator
   Timer2_Init(SYSCLK/SAMPLE_RATE);    // initialize timer to overflow
                                       // at SAMPLE_RATE

   ADC0_Init();                        // ADC samples on Timer 2 interrupts
   SPI_Init();                         // init
   Timer3_Init(SYSCLK/DAC_UPDATERATE); // initialize timer 3 to overflow at
                                       // DACUPDATERATE
   PCA0_Init();                        // initialize PCA0 module 0 for
                                       // edge-triggered interrupts
   IDAC0_Init();                       // enable DAC outputs at P0.1

   Variables_Init();

   WaitMS(500);


   CC1020_StartUpCall = TRUE;          // forces CC1020_Init to turn on all
                                       // RF transceiver components

   while(!CC1020_Init()){}             // initalize the RF transceiver

   CC1020_StartUpCall = FALSE;

   WaitMS(200);

   RXTX_InitSlave();                   // configure RF state machine to slave
                                       // mode, where it will search for a
                                       // Communication Channel


   AD0EN = 1;                          // enables ADC0
   EA = 1;                             // enables all interrupts

   while (1)
   {

      FIFO_ManagementRoutine();        // compresses and decompresses
                                       // audio samples

      // if audile signal present is present at the audio input and the
      // system is not already communicating across the RF line,
      // then initiate a Communication Channel
      if((Audio_LocalState == Audio_Loud) &&
         (RXTX_MasterSelect == RXTX_Searching) &&
         (RXTX_RunInitSlave != TRUE))
      {
         EA = 0;                       // disable interrupts
         RXTX_InitMaster();            // configure to be master endpoint
         EA = 1;                       // re-enable interrupts
      }


      if(Audio_LocalState == Audio_Loud) LED1 = 0; else LED1 = 1;


      // only run the following conditional if SPIBSY == 0, that is
      // if the Audio_ShutdownChannel Audio_Level command has been transmitted
      // so that the receiving slave will no to end transmission
      if((RXTX_RunInitSlave == TRUE) && !(SPI0CFG & 0x80))
      {
         EA = 0;                       // disable interrupts
         RXTX_InitSlave();             // configure to be slave endpoint
                                       // and search for a transmitting master
         EA = 1;                       // re-enable interrupts
      }

  } // end while(1)

} // end void main()


//-----------------------------------------------------------------------------
// Initialization Functions
//-----------------------------------------------------------------------------
//

//-----------------------------------------------------------------------------
// SYSCLK_Init
//-----------------------------------------------------------------------------
//
// This routine initializes the system clock to use the internal 24.5MHz
// oscillator as its clock source.  Also enables missing clock detector
// reset and enables the VDD monitor as a reset source.
//
void SYSCLK_Init (void)
{
   OSCICN |= 0x03;                     // set clock to 24.5 MHz
   RSTSRC  = 0x06;                     // enable missing clock detector
}

//-----------------------------------------------------------------------------
// ADC0_Init
//-----------------------------------------------------------------------------
//
// Configure ADC0 to use Timer2 overflows as conversion source, and to
// generate an interrupt on conversion complete.
// Enables ADC end of conversion interrupt. Leaves ADC disabled.
//
void ADC0_Init(void)
{
   REF0CN = 0x03;                      // set VREF pin as voltage reference,
                                       // enable internal bias generator and
                                       // internal reference buffer

   ADC0CN = 0x02;                      // overflow on Timer 2 starts
                                       // conversion
                                       // ADC0 disabled and in normal
                                       // tracking mode
   AMX0P  = 0x0B;                      // select P1.3 as positive conv. source
   AMX0N  = 0x11;                      // set ADC to single-ended mode
   ADC0CF = (SYSCLK/3000000) << 3;     // ADC Conversion clock = 3 MHz
   ADC0CF&= ~0x04;                     // ADC readings are right-justified
   EIE1  |= 0x08;                      // enable ADC0 EOC interrupt
}

//-----------------------------------------------------------------------------
// PORT_Init
//-----------------------------------------------------------------------------
//
// P0.0 - VREF
// P0.1 - IDAC0 Output
// P0.2 - PSEL
// P0.3 - PCLK
// P0.4 -
// P0.5 -
// P0.6 - PDI
// P0.7 - PDO
// P1.0 - SCK (DCLK)
// P1.1 - MISO (DIO)
// P1.2 - MOSI (DIO)
// P1.3 - Audio Input
// P1.4 - Test Point
// P1.5 - LED1
// P1.6 - LED2
// P1.7 - Switch

void PORT_Init (void)
{

   P0SKIP  = 0xFF;                     // skip all port 0 pins
   P1SKIP = 0x08;                      // skip ADC input P1.3
   P1MDIN &= ~0x08;                    // set P0.0 to analog input
   P0MDOUT |= 0x4C;                    // set P0.2, P0.3, P0.6 to push-pull
   P1MDOUT |= 0x68;                    // Audio input, debug pins
   RouteSPI();                         // routes SPI pins to port pins
   XBR1   |= 0x40;                     // Enable crossbar, CEX0 at port pin
}

//-----------------------------------------------------------------------------
// SPI_Init
//-----------------------------------------------------------------------------
//
// Set SPI to master, CKPHA = 0, CKPOL = 1.  Set SPI to 3 wire mode, and
// enable SPI.  SPI0CKR = 11, SCLK = 24.5Mhz / 12 = 1.021 MHz.
//
void SPI_Init(void)
{
   SPI0CFG = 0x00;                     // Master disable, CKPOL = 0
   SPI0CN  = 0;                        // clear all flags
   IE |= 0x40;                         // enable SPI interrupts
   SPIEN = 0;                          // leave SPI disabled
   IP |= 0x40;                         // make SPI ISR high priority
}


//-----------------------------------------------------------------------------
// IDAC0_Init
//-----------------------------------------------------------------------------
//
// Configure IDAC to update with every Timer 3 overflow, using 2.0 mA
// full-scale output current.
//

void IDAC0_Init(void)
{
   IDA0CN &= ~0x70;                    // Clear Update Source Select Bits
   IDA0CN |=  0x30;                    // Set DAC to update on Tmr 3 Overflows
   IDA0CN |=  0x80;                    // Enable DAC

}


//
//-----------------------------------------------------------------------------
// PCA0_Init
//-----------------------------------------------------------------------------
//
// The PCA is used to watch for the edges of the Sync Word at the SPI MOSI pin.
// Module 0 is configured for edge-triggered captures, and count sysclocks.
// PCA interrupts are enabled.  Leaves PCA disabled.
//
void PCA0_Init(void)
{
   PCA0CPM0 = 0x42;                    // set PCA0 to edge-triggered capture
                                       // mode
   PCA0MD |= 4<<1;                     // Set PCA0 to count sys clocks
   CR = 1;                             // enable PCA0 timer
}

//----------------------------------------------------------------------------
// Timer2_Init
//----------------------------------------------------------------------------
//
// Timer 2 is used as the start of conversion clock source for the ADC,
// and controls the audio sampling rate.
//
void Timer2_Init(unsigned int counts)
{
   TMR2CN = 0x00;                      // resets Timer 2, sets to 16 bit mode
   CKCON |= 0x10;                      // use system clock
   TMR2RL = -counts;                   // Initial reload value
   TMR2 = -counts;                     // init timer
   ET2 = 0;                            // disable Timer 2 interrupts
   TR2 = 1;                            // start Timer 2
}



//-----------------------------------------------------------------------------
// Timer3_Init
//-----------------------------------------------------------------------------
//
// Configure Timer3 to auto-reload at interval specified by <counts>
// using SYSCLK as its time base.  Interrupts are enabled.  Timer 3 controls
// the DAC output rate.
//
void Timer3_Init(unsigned int counts)
{
   TMR3CN  = 0x00;                     // resets Timer 3, sets to 16 bit mode
   CKCON  |= 0x40;                     // use system clock
   TMR3RL  = -counts;                  // Initial reload value

   TMR3    = -counts;                  // init timer
   EIE1   |= 0x80;                     // enable Timer 3 interrupts
   TMR3CN  = 0x04;                     // start Timer 3
}


//-----------------------------------------------------------------------------
// Variables_Init
//-----------------------------------------------------------------------------
//
void Variables_Init(void)
{
   Audio_LocalState = Audio_Quiet;
   Audio_RemoteState = Audio_Quiet;

   CLEAR_FIFOS();
}


//-----------------------------------------------------------------------------
// Interrupt Service Routines
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// ADC0_ISR
//-----------------------------------------------------------------------------
// This routine captures and saves an audio input sample, and then
// compares it to past samples to find out whether or not the audio
// stream is quiet.  The ISR also acts as a timer to measure the 250us
// delay when issuing an RX->TX or TX->RX command to the RF transceiver.
//

void ADC0_ISR(void) interrupt 10
{
   signed short SampleDifference;      // stores difference between current
                                       // and previous ADC0 values
   static short OldADCValue;           // previous ADC value
   static short NewADCValue;           // newest ADC value
   static unsigned short  AudioStateThreshold;
                                       // stores number of consecutive audio
                                       // bytes that have fallen outside
                                       // the defined threshold used to
                                       // determine if the audio state should
                                       // switch from "quiet" to "loud" or
                                       // "loud" to "quiet"
   static unsigned char TableIndex = 0;// index into sine table

   AD0INT = 0;                         // acknowledge end-of-conversion
                                       // interrupt

   OldADCValue = NewADCValue;          // save old ADC value
   NewADCValue = ADC0 - 512;           // add bias to new ADC value

   // if the button on AN147's PCB has been pressed, add a sine wave to the
   // the audio input signal
   if(!SW2)
   {
      TableIndex += 1;                 // increment sine table index value
      if(TableIndex >= 32) TableIndex = 0;
                                       // step through 16-element 1/2 period
                                       // sine table twice to produce a sine
                                       // wave's complete period

      // conditional adjusts the sine wave so that the first cycle
      // through the sine table produces the half of the period with values
      // higher than 0, and the second cycle produces values less than 0
      // Also, amplifies the sine wave by shifting the index value to the
      // left, which is equivalent to a gain of 2
      if(TableIndex < 16)
         NewADCValue += (unsigned char)(Audio_SineTable[TableIndex] << 1);
      else
         NewADCValue -= (unsigned char)(Audio_SineTable[TableIndex - 16]) << 1;
   }


   // This section of the ADC0 ISR determines whether the signal present at the
   // audio input should be considered "loud" or "quiet"
   SampleDifference = (signed)OldADCValue - (signed)NewADCValue;

   // measure whether difference between the current sample and the
   // last sample is greater than the threshold value <Audio_QuietThreshold>
   if( (SampleDifference > (signed)Audio_QuietThreshold) ||
      (SampleDifference < (-(signed)Audio_QuietThreshold)) )
   {
      if(Audio_LocalState == Audio_Quiet)
      {
         // add one to accumulator and check to see if
         // the critical accumulator value has been reached
         if(AudioStateThreshold++ == AudioStateQuietToLoud)
         {
            Audio_LocalState = Audio_Loud;
            AudioStateThreshold = 0;
         }
      }
      else if(Audio_LocalState == Audio_Loud)
      {
         // reset accumulator
         AudioStateThreshold = 0;
      }
   }

   // else <SampleDifference> is below the threshold value
   else
   {
      if(Audio_LocalState == Audio_Quiet)
      {
         if(AudioStateThreshold > 0)
         {
            AudioStateThreshold--;
         }
      }
      else if(Audio_LocalState == Audio_Loud)
      {
         // add one to accumulator and check to see if
         // the critical accumulator value has been reached
         if(AudioStateThreshold++ == AudioStateLoudToQuiet)
         {
            Audio_LocalState = Audio_Quiet;
            AudioStateThreshold = 0;
         }
      }
   }

   ADCRXFIFO_Push(NewADCValue);        // save ADC value for compression


}



//-----------------------------------------------------------------------------
// Timer3_ISR
//-----------------------------------------------------------------------------
// This ISR updates the DAC output at a rate of DACUPDATERATE.  It also
// fetches the most recently captured local ADC sample, attenuates the sample,
// and adds the signal to the DAC output for a loop back.
//

void TIMER3_ISR(void) interrupt 14
{
      static unsigned short new_value;
      USHORT tempvalue;
      TMR3CN &= ~0xC0;                 // acknowledge interrupt

      if (!DACTXFIFO_EMPTY)            // if new DAC data is available,
      {                                // update output information
         new_value = DACTXFIFO_Pull();

         // only play received audio if the remote endpoint as determined
         // that the audio is of audible amplitude
         if(Audio_RemoteState == Audio_Loud)
         {

            // DAC output must be left-justified, and loaded
            // low byte first
            tempvalue.S = new_value;
//            tempvalue.S = tempvalue.S + ADCRXFIFO_Newest()>>4;
            tempvalue.S = tempvalue.S << 6;

            IDA0L = tempvalue.C[1];
            IDA0H = tempvalue.C[0];

         }
      }

}

//-----------------------------------------------------------------------------
// PCA0_ISR
//-----------------------------------------------------------------------------
//
//  The PCA ISR is used to synchronize with the data stream from
//  the CC1020 along byte boundaries using the Sync Word 0xFFFFEE.
//  The PCA is set to interrupt on the falling edge of the DIO line.
//  When the interrupt gets requested, the PCA ISR will spin while it
//  looks for another rising edge.  Upon finding the second rising edge,
//  the PCA will disable itself, route SPI back to the port pins, and
//  enable the SPI interface.
//
void PCA0_ISR(void) interrupt 11
{


   if(CCF0)
   {
      // acknowledge interrupt
      CCF0 = 0;

      // wait until rising edge after first received '0' in Sync Word stream
      while(!DIO);
      _nop_();

      // wait until falling edge of second '0' in stream
      while(DIO);
      _nop_();

      // wait for rising edge in DCLK
      while(!DCLK);
      _nop_();

      // wait for falling edge
      while(DCLK);

      // route SPI back to port pins
      RouteSPI();

      EIE1 &= ~0x10;                   // Disable PCA0 interrupts
      PCA0CPM0 = 0x42;                 // set to 8-bit PWM output

      SPIF = 0;                        // clear pending interrupt flag
      SPIEN = 1;                       // re-enable SPI

   }
   else if(CCF1)
   {
   }
   else if(CCF2)
   {
   }

}


//-----------------------------------------------------------------------------
// SPI_ISR
//-----------------------------------------------------------------------------
//
//  SPI ISR contains the RF state machine.  An interrupt will be requested
//  after 8 bits of data have been shifted out to or in from the RF
//  transceiver.  Progress through the state machine is gated by byte counters
//  that increment once per interrupt servicing.
//
void SPI0_ISR(void) interrupt 6
{
   static unsigned char PreambleByte;  // counts Preamble bytes transmitted
   static unsigned char SyncWordByte;  // counts Sync Word bytes transmitted
   unsigned char SPI_Input;            // saves the received byte acquired
                                       // from SPI0DAT

   SPI_Input = SPI0DAT;

   // test for all SPI error conditions
   if(SPI0CN & 0x70)
   {
      SPI0CN &= ~0x70;                 // acknowledge error conditions, clear
                                       // flags
   }

   // bit is set inside RF state machine initialization routines
   if(RXTX_ResetVariables)
   {
      RXTX_ResetVariables = FALSE;     // clear flag
      RXTX_NoPreambleCount = 0;        // reset all counters
      PreambleByte = 0;
      SyncWordByte = 0;
   }

   if(SPIF)
   {
      SPIF = 0;                        // acknowledge interrupt

      switch(RXTX_StateMachine)
      {

         case(RX_SearchForMaster):

            // if received byte is Preamble, take appropriate action
            if((SPI0DAT == 0x55) || (SPI0DAT == 0xAA))
            {
               if(++PreambleByte == RX_MinBytesInitPreamble)
               {
                  RXTX_StateMachine = RX_SyncWord;

                  // timer will synchronize with master's at the end
                  // of the first received data packet
                  SPI_TimerEnable = TRUE;
                  SPI_Timer = SPI_SlopTimeOut + TX_NumBytesPreamble;

                  RXTX_MasterSelect = RXTX_Slave;

                  // reset counter
                  PreambleByte = 0;
               }
            }
            else // received byte was not Preamble
            {
               // reset counter
               PreambleByte = 0;
            }

         break;

         case(RX_Preamble):
         {

            if(!SPI_TimeOutEvent)
            {
               // of byte received is Preamble, increment counter
               if((SPI0DAT == 0x55) || (SPI0DAT == 0xAA))
               {
                  // if minimum number of Preamble bytes has been received,
                  // begin searching for the Sync word
                  if(PreambleByte++ >= RX_MinBytesPreamble)
                  {
                     RXTX_StateMachine = RX_SyncWord;
                     PreambleByte = 0;
                     SPI_DataBytes = 0;
                  }
               }
               else
               {
                  // received byte was not Preamble, reset counter
                  PreambleByte = 0;
               }
            }
            // if time allotted to finding preamble has expired, enter
            // Time Out state with failure information
            else  // (SPI_TimeOutEvent)
            {
               TimeOut_EntryMode = TimeOut_RXNoPreamble;
               RXTX_StateMachine = RXTX_TimeOut;
               PreambleByte = 0;
            }
         }

         break;

         case(RX_SyncWord):
         {
            // only acknowledge time-outs during data reception

            //Sync Word not found before SPI TimeOut Event
            if(SPI_TimeOutEvent == TRUE)
            {
               TimeOut_EntryMode = TimeOut_RXNoSyncWord;
               RXTX_StateMachine = RXTX_TimeOut;
            }

            else if(SPI_Input == 0xFF)
            {
               // configure external interrupt to trigger on falling edge
               // of MOSI data line

               SPIEN = 0;              // disable SPI, re-enabled in PCA ISR

               PCA0CPM0 = 3<<4;        // Set PCA to edge-capture on rising
                                       // and falling edges
               PCA0CPM0 |= 1;          // enable CCF0 interrupts

               // route PCA CEX0 instead of SPI to RF transceiver data line
               RoutePCA();

               // enable PCA to edge-capture mode on P1.1

               EIE1 |= 0x10;           // enable PCA0 interrupts
               CCF0 = 0;               // clear pending interrupt flag

               RXTX_StateMachine = RX_AudioState;

            }


         }

         break;

         case(RX_AudioState):
         {
            Audio_RemoteState = SPI0DAT;

            // if local endpoint is designated as slave, and the shutdown
            // command has been received, configure the RF state machine
            // to shutdown
            if((RXTX_MasterSelect == RXTX_Slave) &&
               (Audio_RemoteState == Audio_ChannelShutdown))
            {
               RXTX_StateMachine = RXTX_Shutdown;
            }
            // else receive a packet of data
            else
            {
               RXTX_StateMachine = RX_Data;
            }
         }

         break;


         case(RX_Data):
         {

            ReceiveFIFO_Push(SPI0DAT);     // store received byte

            SPI_DataBytes++;           // increment received bytes counter

            // once all packet's bytes have been received, exit state
            if(SPI_DataBytes == RXTX_BytesOfData)
            {
               // configure state machine to enter time out state a
               // fter SPI_Timer reaches terminal value
               TimeOut_EntryMode = TimeOut_RXSuccessful;
               RXTX_StateMachine = RXTX_WaitForTimeOut;

               // reset the SPI timer to the value it should be during
               // this point in packet reception
               if(RXTX_MasterSelect == RXTX_Slave)
               {
                  // The slave should re-sync the SPI clock to the
                  // reception of the last transmitted master CRC
                  SPI_Timer = SPI_SlopTimeOut + TX_NumBytesPreamble
                              + RXTX_SyncWordSize + Audio_StateSize
                              + RXTX_BytesOfData;
               }


               // This code will adjust the output rate of the DAC
               // in order to avoid data overflows and underflows
               DAC_Error = (signed int)ReceiveFIFO_COUNT -
                           (signed int)ReceiveFIFO_TARGET;
               DAC_Error *= 5;
               TMR3RL = -((SYSCLK/DAC_UPDATERATE) - DAC_Error);

            }

         }
         break;

         case(TX_SwitchTime):
         {
            // spin until defined time period has passed
            if(SPI_Timer <= SPI_SlopTimeOut)
            {
               SPI0DAT = 0xFF;
            }
            else
            {
               SPI0DAT = 0xFF;
               RXTX_StateMachine = TX_Preamble;
            }
         }

         break;

         case (TX_InitPreamble):

            if(PreambleByte++ != TX_NumBytesInitPreamble - 1)
            {
               // only write to SPI0DAt if the transmit buffer is empty
               if(TXBMT)
               {
                  SPI0DAT = 0x55;
               }
               _nop_();

               if(TXBMT)
               {
                  // conditional should execute only once
                  SPI0DAT = 0x55;
               }
            }

            else // transmit last byte of Preamble
            {
               SPI0DAT = 0x55;

               SPI_TimerEnable = TRUE;

               // set timer to position it would be in at this
               // point during a normal data transmission
               SPI_Timer = SPI_SlopTimeOut + TX_NumBytesPreamble;

               RXTX_StateMachine = TX_SyncWord;
               PreambleByte = 0;
               SPI_DataBytes = 0;
            }

         break;

         case(TX_Preamble):

            if(PreambleByte++ != TX_NumBytesPreamble - 1)
            {
               if(TXBMT)
               {
                  SPI0DAT = 0x55;
               }
               _nop_();

               if(TXBMT)
               {
                  // conditional should execute only once
                  SPI0DAT = 0x55;
               }
            }

            else
            {
               SPI0DAT = 0x55;
               RXTX_StateMachine = TX_SyncWord;
               PreambleByte = 0;
               SPI_DataBytes = 0;
            }

         break;

         case(TX_SyncWord):
         {
            // State Transmits 0xFFFFEE
             if(SyncWordByte < 2)
            {
               SPI0DAT = 0xFF;
               ++SyncWordByte;
            }
            else
            {
               SPI0DAT = 0xEE;
               RXTX_StateMachine = TX_AudioState;
               SyncWordByte = 0;
            }
          break;
          }

         case(TX_AudioState):
         {

            // if both endpoints' audio signals are "quiet" and the
            // local endpoint is designated as the master, transmit
            // the Shutdown command to terminate the Communication Channel
            if((RXTX_MasterSelect == RXTX_Master) &&
               (Audio_RemoteState == Audio_Quiet)
            && (Audio_LocalState == Audio_Quiet))
            {
               SPI0DAT = Audio_ChannelShutdown;
               RXTX_StateMachine = RXTX_Shutdown;
            }
            else
            {
               SPI0DAT = Audio_LocalState;
               RXTX_StateMachine = TX_Data;
            }
         }
         break;

         case(TX_Data):
         {

           SPI0DAT = TransmitFIFO_Pull();   // pull compressed byte and transmit


           SPI_DataBytes++;            // increment byte counter

           // once defined number of bytes has been transmitted, exit state
           if(SPI_DataBytes == RXTX_BytesOfData)
           {
               SPI_DataBytes = 0;
               SPI_DataBytes = 0;
               TimeOut_EntryMode = TimeOut_TXSuccessful;
               RXTX_StateMachine = RXTX_WaitForTimeOut;

               // This code adjusts the sampling rate of the ADC
               // in order to avoid data overflows or underflows
               DAC_Error = (signed int)TransmitFIFO_COUNT -
                           (signed int)TransmitFIFO_TARGET;
               DAC_Error *= 5;
               // adjust ADC sample rate
               TMR2RL = -((SYSCLK/DAC_UPDATERATE) + DAC_Error);
             }

         }

         break;

         case(RXTX_WaitForTimeOut):
         {
            // state machine will exit state after SPI_Timer has reached its
            // terminal value
            if(TXBMT)
            {
               SPI0DAT = 0x00;
            }
            if(SPI_TimeOutEvent == TRUE)
            {
               RXTX_StateMachine = RXTX_TimeOut;
            }
         }

         break;


         case(RXTX_TimeOut):


            SPI_TimeOutEvent = FALSE;  // clear flag

            // reset RX failure counter if receive was successful
            if(TimeOut_EntryMode == TimeOut_RXSuccessful)
            {
               RXTX_NoPreambleCount = 0;
            }

            switch(TimeOut_EntryMode)
            {
               case(TimeOut_RXSuccessful):
                  // toggle LED on to indicate that RF is
                  // entering transmit mode
                  LED2 = 0;

                  RXTX_StateMachine = Switch_ToTX01;

               break;

               case(TimeOut_TXSuccessful):
                  // toggle LED off to indicate that RF is
                  // entering receive mode
                  LED2 = 1;

                  RXTX_StateMachine = Switch_ToRX01;

               break;

               case(TimeOut_RXNoPreamble):

                  LED2 = 0;

                  // count consecutive failed preamble detections,
                  // make decision based on count

                  if(++RXTX_NoPreambleCount == RXTX_NoPreambleLevel)
                  {
                     RXTX_NoPreambleCount = 0;
                     RXTX_StateMachine = RXTX_Shutdown;
                  }
                  // else if endpoint is master, transmit a packet
                  else if(RXTX_MasterSelect == RXTX_Master)
                  {
                     RXTX_StateMachine = Switch_ToTX01;
                  }
                  // if endpoint is slave, continue trying to receive a packet
                  else
                  {
                     RXTX_StateMachine = RX_Preamble;
                  }

               break;

               case(TimeOut_RXNoSyncWord):
                  // if master, transmit a packet
                  if(RXTX_MasterSelect == RXTX_Master)
                  {
                     RXTX_StateMachine = Switch_ToTX01;
                  }
                  // if slave, try to receive a packet again
                  else
                  {
                     RXTX_StateMachine = RX_Preamble;
                  }

               break;
            } // switch(TimeOut_EntryMode)

         break;


         case(RXTX_Shutdown):

            // set system to search for a Communication Channel
            RXTX_MasterSelect = RXTX_Searching;
            RXTX_RunInitSlave = TRUE;

            SPI_TimerEnable = FALSE;

            RXTX_StateMachine = Uninitialized;

         break;

         case(Uninitialized):

         break;


         case(Switch_ToTX01):

            SPI0DAT = 0xFF;
            _nop_();
            if(TXBMT) SPI0DAT = 0xFF;

            // route RF transceiver's output through the RF switch
            SETREG(INTERFACE,I_TX);

            // configure transceiver to TX mode
            SETREG(MAIN,0xC1);
            RXTX_StateMachine = Switch_ToTX02;

          break;

          case(Switch_ToTX02):

            SPI0DAT = 0xFF;
            if(SPI_Timer >= SPI_CalibrationWaitTime)
            {
               if((READREG(STATUS) & 0x10) != 0)
               {
                   SETREG(PA_POWER,0xFF);

                   RXTX_StateMachine = TX_SwitchTime;

                   SPI_TX();           // set MISO pin to push-pull
               }
               else
               {
                  RXTX_StateMachine = Switch_ToTX02;
               }
          }
          break;

          case(Switch_ToRX01):

             SPI0DAT = 0xFF;
             _nop_();

             if(TXBMT) SPI0DAT = 0xFF;

             // set RF transceiver to lowest output power setting
             SETREG(PA_POWER, 0x00);

             // configure RF transceiver to RX mode
             SETREG(MAIN,0x01);
             RXTX_StateMachine = Switch_ToRX02;

          break;

          case(Switch_ToRX02):

            SPI0DAT = 0xFF;
            if(SPI_Timer >= SPI_CalibrationWaitTime)
            {
               if((READREG(STATUS) & 0x10) != 0)
               {
                  // route antenna to the input pin of the RF transceiver
                  SETREG(INTERFACE,I_RX);

                  RXTX_StateMachine = RX_Preamble;

                  SPI_RX();            // disconnect MISO pin by configuring it
                                       // to analog input
               }
            }
            else
            {
               RXTX_StateMachine = Switch_ToRX02;
            }

            break;

      }// end switch(RXTX_StateMachine)

   }// end if(SPIF)



   // this section of code increments the SPI_Timer, if enabled
   if(SPI_TimerEnable == TRUE)
   {
      SPI_Timer++;

      if(SPI_Timer == SPI_PacketTime)
      {
        SPI_TimeOutEvent = TRUE;
        SPI_Timer = 0;
      }
   }
   else
   {
      SPI_Timer = 0;
      SPI_TimeOutEvent = FALSE;
   }
}

//-----------------------------------------------------------------------------
// RF State Machine Functions
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// RXTX_InitMaster(void)
//-----------------------------------------------------------------------------
//
// This function switches the RF transceiver to transmit and sets variables
// to indicate that this endpoint is designated as master.
//
void RXTX_InitMaster(void)
{

   SPIEN = 0;                          // disable SPI
   SPIF = 0;                           // clear any pending interrupt flag

   CC1020_SwitchToTX();                // configure system to transmit

   RXTX_ResetVariables = TRUE;         // signal RF state machine to
                                       // reset variables

   RXTX_StateMachine = TX_InitPreamble;// set state machine to transmit
                                       // initial preamble

   RXTX_MasterSelect = RXTX_Master;    // designate endpoint as master

   SPIEN = 1;                          // re-enable SPI

   // pad SPI0DAT with known values to be shifted out
   SPI0DAT = 0x00;

   _nop_();

   if(TXBMT) SPI0DAT = 0x00;


}

//-----------------------------------------------------------------------------
// RXTX_InitSlave(void)
//-----------------------------------------------------------------------------
//
// This function switches the RF transceiver to receive and sets variables
// to indicate that the endpoint is designated as slave.
//

void RXTX_InitSlave(void)
{

   SPIEN = 0;                          // disable SPI
   SPIF = 0;                           // clear any pending interrupt flags

   CC1020_SwitchToRX();                // configure system to receive

   RXTX_RunInitSlave = FALSE;          // clear signal flag

   RXTX_ResetVariables = TRUE;         // signal state machine to reset
                                       // variables

   // set RF state machine to search for a transmitting master endpoint
   RXTX_StateMachine = RX_SearchForMaster;

   RXTX_MasterSelect = RXTX_Searching; // designate endpoint as neither master
                                       // or slave

   SPIEN = 1;                          // re-enable SPI

   SPI0DAT = 0x00;                     // pad SPI0DAT with known values

   _nop_();

   if(TXBMT) SPI0DAT = 0x00;

}


//-----------------------------------------------------------------------------
// CC1020 Functions
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// SETREG
//-----------------------------------------------------------------------------
// Writing registers in the CC1020 transceiver is accomplished using the
// SPI interface.  Two bytes are sent, an address byte and a data byte.
// First PALE is driven low.  The address byte contains the 7-bit address,
// and then a logic '1', signifying "write mode".  Then PALE is brought
// high and the data byte is transmitted.
//
void SETREG(unsigned char address, unsigned char value)
{
   unsigned char output,count;


   output = address << 1 | 0x01;       // 7 address bits + WRITE

   PCLK = 0;

   PALE = 0;                           // selects the RF transceiver


   // bit-banged interface sends the register address to the RF transceiver
   for (count = 0;count<8;count++)
   {
      PCLK = 0;                        // data is clocked into the RF
                                       // transceiver on the rising edge
                                       // of the clock

      if(output & 0x80) PDI = 1;       // set or clear the config data line
      else PDI = 0;                    // to transmit data MSB first

      PCLK = 1;                        // clock in the data bit
      output = output<<1;              // shift to read the next data bit
   }

   output = value;                     // prepare to shift out new register
                                       // value

   for (count = 0;count<8;count++)
   {
      PCLK = 0;

      if(output & 0x80) PDI = 1;       // set or clear config data line
      else PDI = 0;                    // with data out MSB first

      PCLK = 1;                        // clock out data

      output = output<<1;              // shift to prepare next bit's output
   }

   PCLK = 0;


   PALE = 1;                           // deselect the RF transceiver

}


//-----------------------------------------------------------------------------
// READREG
//-----------------------------------------------------------------------------
// Reading registers is accomplished by sending the address of the
// register to be read and then receiving a data byte in return.
// PALE is driven low, and a byte consisting of the 7-bit address
// plus a bit set to '0' signifying "read mode" is sent.  PALE is
// then raised high and a data byte is read in through SPI.
//
unsigned char READREG(unsigned char address)
{

   unsigned char output,input,count;

   output = address<<1;                // 7 address bits + READ

   PCLK = 0;

   PALE = 0;                           // select the RF transceiver

   for(count = 0;count<8;count++)
   {
      PCLK = 0;

      if(output & 0x80) PDI = 1;       // shift out register address
      else PDI = 0;                    // MSB first


      PCLK = 1;

      output = output<<1;              // prepare next bit to shift out
   }

   for(count = 0;count<8;count++)
   {
      PCLK = 0;

      _nop_();
      _nop_();
      _nop_();
      _nop_();

      PCLK = 1;                        // clock in register value MSB first

      // save bit of register value
      if(PDO == 1)
      {
         input = (input<<1) | 1;
      }
      else
      {
         input<<=1;
      }
   }

   PCLK = 0;

   PALE = 1;                           // deselect the RF transceiver

   return input;

}

//-----------------------------------------------------------------------------
// CC1020_Init
//-----------------------------------------------------------------------------
// This function will initialize the transceiver and calibrate it to
// transmit and receive on a defined frequency.
//
unsigned char cal_complete;

unsigned int idata count;

unsigned char CC1020_Init(void)
{
   unsigned char temp_reg;
   unsigned char RegAddress;

   if(CC1020_StartUpCall)
   {
      SETREG(MAIN,0x0E);
      SETREG(MAIN,0x0F);
      SETREG(INTERFACE,I_RX);
      SETREG(RESETT,0xFF);
      SETREG(SEQUENCING,0x8F);


   }

      // Configure receive frequency of 908 MHz
      SETREG(FREQ_2A,0x3c);
      SETREG(FREQ_1A,0xCE);
      SETREG(FREQ_0A,0x8E);

      // Configure transmit frequency of 908 MHz
      SETREG(FREQ_2B,0x3c);
      SETREG(FREQ_1B,0xd3);
      SETREG(FREQ_0B,0xe3);

   if(CC1020_StartUpCall)
   {

      // CLOCK_A is not located in a space contiguous with the
      // other registers to be programmed
      SETREG(CLOCK_A,0x25);

      // this loop writes to each register of the CC1020 a
      // corresponding value found in RegValue
      for(RegAddress = CLOCK_B;RegAddress != TEST7 + 1;)
      {
         temp_reg = RegValue[RegAddress - CLOCK_B];
         SETREG(RegAddress,RegValue[RegAddress - CLOCK_B]);
         RegAddress++;
      }

      SETREG(MAIN,0x0B);
      WaitMS (5*200);                  // wait for oscillator to stabilize
      SETREG(MAIN,0x09);
      WaitMS (1*200);                  // wait for bias generator to stabilize
      SETREG(MAIN,0x01);


   }


   // Calibration Routine
   count = 0;                          // reset counter
   cal_complete = 0;                   // clear temporary storage variable
   SETREG(MAIN,0x11);
   SETREG(CALIBRATE,0x85);

   // check for calibration complete
   do
   {
      count++;
      cal_complete = READREG(STATUS);
   } while (!(cal_complete & 0x80) && (count != 0xFFFF));

   // if the count is too high or too low, an error occurred during
   // calibration, exit the initialization and re-run
   if(!(cal_complete & 0x80))
   {
      return 0;
   }

   // now check for lock
   count = 0;                          // reset counter
   do
   {
      count++;                         // increment counter
      cal_complete = READREG (STATUS);
      WaitUS(1);
      // spin until a lock is detected
   } while (!(cal_complete & 0x10) && (count != 0xFFFE));


   // if count timed out, exit function
   if (!(cal_complete & 0x10))
   {//|| (count < 2)) {
      return 0;
   }



   count = 0;                          // reset counter
   SETREG(MAIN,0xD1);

   SETREG(CALIBRATE,0x85);
   do
   {
      count++;          // increment counter
      cal_complete = READREG(STATUS);
   } while (!(cal_complete & 0x80) && (count != 0xFFFF));

   // if the count is too high or too low, an error occurred during
   // calibration, exit the initialization and re-run
   if((count < 10) || (!(cal_complete & 0x80)))
   {
      return 0;
   }


   // now check for lock
   count = 0;                          // reset counter
   do
   {
      count++;                         // increment counter
      cal_complete = READREG (STATUS);
      // spin until lock detected
   } while (!(cal_complete & 0x10) && (count != 0xFFFF));


   // if count timed out, exit initialization and re-run
   if (!(cal_complete & 0x10))
   {//|| (count < 2)) {
      return 0;
   }

   WaitMS(3);

   // Configure RF transceiver to receive by default
   SETREG(MAIN,0x01);

   return 1;


}


//-----------------------------------------------------------------------------
// CC1020_SwitchToRX(void)
//-----------------------------------------------------------------------------
//
// Function configures the RF transceiver's power amplifier to its lowest
// output setting, routes the antenna to the RF input pin using the RF switch,
// and configures the transceiver to receive.
//
void CC1020_SwitchToRX(void)
{
   SETREG(PA_POWER,0x00);              // configure PA to lowest setting

   SETREG(INTERFACE,I_RX);             // configure RF switch to RX path

   SETREG(MAIN,0x01);                  // configure transceiver to receive

   WaitMS(1);

   // wait for the PLL to lock
   while(!(READREG(STATUS) & 0x10)){};

   SPI_RX();                           // configure MISO as analog input
                                       // to disconnect pin from DIO trace
                                       // and avoid contention

}

//-----------------------------------------------------------------------------
// CC1020_SwitchToTX(void)
//-----------------------------------------------------------------------------
//
// Function configures PA to lowest setting,
//
void CC1020_SwitchToTX(void)
{

   SETREG(PA_POWER,0x00);              // configure internal PA to lowest
                                       // setting

   SETREG(MAIN,0xC1);                  // set RF transceiver to transmit

   WaitMS(1);

   // wait for the PLL to lock
   while(!(READREG(STATUS) & 0x10)){};

   SETREG(PA_POWER,0xFF);              // set PA to maximum transmit setting

   SETREG(INTERFACE,I_TX);             // route antenna to TX pin using RF
                                       // switch

   SPI_TX();                           // set MISO to push-pull

}




//-----------------------------------------------------------------------------
// FIFO Routines
//-----------------------------------------------------------------------------
// All FIFO functions pass a pointer to the fifo.  Pull functions return
// either a short or a char, and push functions have the data to be pushed
// as an additional parameter.
// Pushes and pulls update EMPTY, COUNT, and OF variables.
//
unsigned char TransmitFIFO_Pull(void)
{
   unsigned char output;

   if(TransmitFIFO_EMPTY)
   {
      // if buffer is empty, set the underflow flag and exit function
      TransmitFIFO_UF = 1;
      return 0;
   }
   else
   {
      TransmitFIFO_FULL = 0;                // if byte is pulled, buffer can no
                                       // longer be full

      // wrap FIFO pointer if necessary
      if (TransmitFIFO_FIRST==TransmitFIFO_FIFOSIZE-1) TransmitFIFO_FIRST = 0;
      else (TransmitFIFO_FIRST)++;

      // pull value from fifo
      output = TransmitFIFO_FIFO[TransmitFIFO_FIRST];

      // set empty indicator if necessary
      if (--(TransmitFIFO_COUNT) == 0) TransmitFIFO_EMPTY = 1;

      return output;
   }
}

void TransmitFIFO_Push(unsigned char num)
{
   TransmitFIFO_EMPTY = 0;                  // buffer is no longer empty


   if (!TransmitFIFO_FULL) {
      (TransmitFIFO_LAST)++;                // increment, wrap if necessary
      if (TransmitFIFO_LAST == TransmitFIFO_FIFOSIZE)
      {
         TransmitFIFO_LAST = 0;
      }

      TransmitFIFO_FIFO[TransmitFIFO_LAST]=num;  // push value to FIFO


      TransmitFIFO_COUNT++;                 // increment count

      // check for full buffer
      if ( TransmitFIFO_COUNT == TransmitFIFO_FIFOSIZE)
      {
         TransmitFIFO_FULL = 1;
      }
   }
   else // buffer is full
   {
      // if buffer is full, do not push byte, just set overflow flag
      // and exit
      TransmitFIFO_OF = 1;
   }
}

unsigned char ReceiveFIFO_Pull(void)
{
   unsigned char output;

   if(ReceiveFIFO_EMPTY)
   {
      // if buffer is empty, set underflow flag and exit
      ReceiveFIFO_UF = 1;

      return 0;
   }
   else
   {
      ReceiveFIFO_FULL = 0;                // buffer is no longer full

      // wrap FIFO pointer if necessary
      if (ReceiveFIFO_FIRST==ReceiveFIFO_FIFOSIZE-1) ReceiveFIFO_FIRST = 0;
      else (ReceiveFIFO_FIRST)++;

      // pull value from fifo
      output = ReceiveFIFO_FIFO[ReceiveFIFO_FIRST];

      // set empty indicator if necessary
      if (--(ReceiveFIFO_COUNT) == 0) ReceiveFIFO_EMPTY = 1;

      return output;
   }
}


void ReceiveFIFO_Push(unsigned char num)
{

   ReceiveFIFO_EMPTY = 0;                  // FIFO is no longer empty
   if (!ReceiveFIFO_FULL) {

      (ReceiveFIFO_LAST)++;                // increment, wrap if necessary
      if (ReceiveFIFO_LAST == ReceiveFIFO_FIFOSIZE)
      {
         ReceiveFIFO_LAST = 0;
      }

      ReceiveFIFO_FIFO[ReceiveFIFO_LAST]=num;  // push value to FIFO

      ReceiveFIFO_COUNT++;

      if ( ReceiveFIFO_COUNT == ReceiveFIFO_FIFOSIZE)
      {
         ReceiveFIFO_FULL = 1;
      }
   // buffer is full
   } else {
      // only set overflow flag and exit
      ReceiveFIFO_OF = 1;
   }
}

void ADCRXFIFO_Push(unsigned short num)
{
   ADCRXFIFO_EMPTY = 0;                // buffer is no longer empty

   if (!ADCRXFIFO_FULL) {
      (ADCRXFIFO_LAST)++;              // increment, wrap around if necessary
      if (ADCRXFIFO_LAST == ADCRXFIFO_FIFOSIZE)
      {
         ADCRXFIFO_LAST = 0;
      }


      ADCRXFIFO_FIFO[ADCRXFIFO_LAST]=num;

      // update count, check for an overflow
      ++ADCRXFIFO_COUNT;

      if(ADCRXFIFO_COUNT == ADCRXFIFO_FIFOSIZE)
      {
         ADCRXFIFO_FULL = 1;
      }
   } else {
      ADCRXFIFO_OF = 1;
   }
}

unsigned short ADCRXFIFO_Pull(void)
{
   unsigned short output;

   // if a function tries to pull a value from an empty buffer, set the
   // underflow flag and exit the function
   if(ADCRXFIFO_EMPTY)
   {
      ADCRXFIFO_UF = 1;
      return 0;
   }

   // else the buffer is not empty, pull the value and return it
   else
   {
      ADCRXFIFO_FULL = 0;
      // update the first pointer, wrap around if necessary
      if (ADCRXFIFO_FIRST==ADCRXFIFO_FIFOSIZE-1) ADCRXFIFO_FIRST = 0;
      else (ADCRXFIFO_FIRST)++;

      // save output value
      output = ADCRXFIFO_FIFO[ADCRXFIFO_FIRST];

      // decrement buffer size
      if (--(ADCRXFIFO_COUNT) == 0) ADCRXFIFO_EMPTY = 1;

      return output;
   }
}


void DACTXFIFO_Push(unsigned short num)
{
   DACTXFIFO_EMPTY = 0;                // buffer is no longer empty

   if (!DACTXFIFO_FULL) {
      (DACTXFIFO_LAST)++;              // increment, wrap around if necessary
      if (DACTXFIFO_LAST == DACTXFIFO_FIFOSIZE)
      {
         DACTXFIFO_LAST = 0;
      }

      DACTXFIFO_FIFO[DACTXFIFO_LAST]=num;



      // update count, check for an overflow
      ++DACTXFIFO_COUNT;
      if (DACTXFIFO_COUNT == DACTXFIFO_FIFOSIZE - 1)
      {
         // the decompression routine will push two decompressed
         // audio samples per call to the routine, and
         // DACTXFIFO_DECOMPRESS_HALT is set when the buffer can only
         // store 1 more decompressed sample.
         // The flag will be cleared when at least one buffer byte is pulled
         DACTXFIFO_DECOMPRESS_HALT = 1;
      }
      else if (DACTXFIFO_COUNT == DACTXFIFO_FIFOSIZE)
      {
         DACTXFIFO_DECOMPRESS_HALT = 1;
         DACTXFIFO_FULL = 1;
      }
      else if ( DACTXFIFO_COUNT == DACTXFIFO_FIFOSIZE+1)
      {
         DACTXFIFO_DECOMPRESS_HALT = 1;
         DACTXFIFO_FULL = 1;
         DACTXFIFO_OF = 1;
      }
   } else {
      DACTXFIFO_OF = 1;
   }
}

unsigned short DACTXFIFO_Pull(void)
{
   unsigned short output;

   // if a function tries to pull a value from an empty buffer, set the
   // underflow flag and exit the function
   if(DACTXFIFO_EMPTY)
   {
      DACTXFIFO_UF = 1;
      return 0;
   }

   // else the buffer is not empty, pull the value and return it
   else
   {
      DACTXFIFO_FULL = 0;
      // update the first pointer, wrap around if necessary
      if (DACTXFIFO_FIRST==DACTXFIFO_FIFOSIZE-1) DACTXFIFO_FIRST = 0;
      else (DACTXFIFO_FIRST)++;

      // save output value
      output = DACTXFIFO_FIFO[DACTXFIFO_FIRST];

      // decrement buffer size
      if (--(DACTXFIFO_COUNT) == 0) DACTXFIFO_EMPTY = 1;

      if((DACTXFIFO_DECOMPRESS_HALT) &&
         (DACTXFIFO_COUNT <= DACTXFIFO_FIFOSIZE - 2))
      {
         DACTXFIFO_DECOMPRESS_HALT = 0;
      }

      return output;
   }
}

//-----------------------------------------------------------------------------
// ADCRXFIFO_Newest()
//-----------------------------------------------------------------------------
//
// This function returns the newest received ADC sample, which can be used
// to loop back the local audio signal during communication.
//
unsigned short ADCRXFIFO_Newest(void)
{
   return ADCRXFIFO_FIFO[ADCRXFIFO_LAST];
}

//-----------------------------------------------------------------------------
// CLEAR_FIFOS()
//-----------------------------------------------------------------------------
//
// Routine resets all buffers; index values and flags to initial values.
//
void CLEAR_FIFOS(void)
{
   // reset the ADCRX FIFO
   ADCRXFIFO_EMPTY = 1;
   ADCRXFIFO_FIRST = 0;
   ADCRXFIFO_LAST = 0;
   ADCRXFIFO_COUNT = 0;
   ADCRXFIFO_OF = 0;
   ADCRXFIFO_FULL = 0;

   // reset the DACTX FIFO
   DACTXFIFO_EMPTY = 1;
   DACTXFIFO_FIRST = 0;
   DACTXFIFO_LAST = 0;
   DACTXFIFO_COUNT = 0;
   DACTXFIFO_OF = 0;
   DACTXFIFO_FULL = 0;

   // reset the UART TX FIFO
   TransmitFIFO_EMPTY = 1;
   TransmitFIFO_FIRST = 0;
   TransmitFIFO_LAST = 0;
   TransmitFIFO_COUNT = 0;
   TransmitFIFO_OF = 0;
   TransmitFIFO_FULL = 0;

   // reset the UART RX FIFO
   ReceiveFIFO_EMPTY = 1;
   ReceiveFIFO_FIRST = 0;
   ReceiveFIFO_LAST = 0;
   ReceiveFIFO_COUNT = 0;
   ReceiveFIFO_OF = 0;
   ReceiveFIFO_FULL = 0;

}

//-----------------------------------------------------------------------------
// FIFO_ManagementRoutine()
//-----------------------------------------------------------------------------
//
//
//
void FIFO_ManagementRoutine(void)
{
   bit EAState;

   EAState = EA;
   EA = 0;



   PCA0CPH0 = ReceiveFIFO_COUNT;

   if (!ADCRXFIFO_EMPTY)               // The compression algorithm should run
      DPCM_Compress();                 // any time samples exist to compress
   EA = EAState;

   EAState = EA;
   EA = 0;
   if ((!ReceiveFIFO_EMPTY) && (!DACTXFIFO_DECOMPRESS_HALT))
   {
                                       // Decompress received samples when
      DPCM_Decompress();               // available
   }
   EA = EAState;

   EAState = EA;
   EA = 0;
   if(ADCRXFIFO_FULL)
   {
      ADCRXFIFO_Pull();
   }
   EA = EAState;

   EAState = EA;
   EA = 0;
    if(ReceiveFIFO_FULL)
   {

      ReceiveFIFO_Pull();
   }
   EA = EAState;

   EAState = EA;
   EA = 0;
   if(TransmitFIFO_FULL)
   {
      TransmitFIFO_Pull();
   }
   EA = EAState;

   EAState = EA;
   EA = 0;
   if(DACTXFIFO_OF)
   {
      DACTXFIFO_Pull();
   }
   EA = EAState;


}

//-----------------------------------------------------------------------------
// DPCM_Encode
//-----------------------------------------------------------------------------
//
// Encode the 8-bit (MSBs of 10-bit sample) sample using DPCM compression.
// INPUTS:
//    sample_diff -  8-bit difference between the predicted value and the 8
//                   MSBs of the sample from the ADC
// OUTPUTS:
//    dpcm_code - the 4-bit quantized DPCM code
//
//    The difference will be rounded down if positive and rounded up if
//    negative (i.e. 41 => 32, and -41 => -32).
//
   volatile short data encoderpredsample;
void DPCM_Compress (void)
{
   short isr_count1 = TMR2;
   short sample_diff;
   unsigned short sample_diff_us;
   unsigned char dpcm_code;
   static unsigned char OutputByte;

   bit EAstate;

   EAstate = EA;
   EA = 0;
   sample_diff = ADCRXFIFO_Pull();
   EA = EAstate;

   sample_diff -= encoderpredsample;

   // determine if the difference is positive or negative
   if (sample_diff < 0)
   {
      sample_diff_us = -sample_diff;   // use the absolute value
   }
   else
   {
      sample_diff_us = sample_diff;
   }

   // narrow down which bits need to be set to use the proper
   // quantization code using a binary search algorithm (divide in halves)
   // the sign of the difference no longer matters, so only use the
   // lower 8 bits
   if (sample_diff_us >= middle)
   {
      if (sample_diff_us >= high_mid)
      {
         if (sample_diff_us >= high_high)
         {
            dpcm_code = 15;
         }
         else
         {
            dpcm_code = 14;
         }
      }
      else
      {
         if (sample_diff_us >= high_low)
         {
            dpcm_code = 13;
         }
         else
         {
            dpcm_code = 12;
         }
      }
   }
   else
   {
      if (sample_diff_us >= low_mid)
      {
         if (sample_diff_us >= low_high)
         {
            dpcm_code = 11;
         }
         else
         {
            dpcm_code = 10;
         }
      }
      else
      {
         if (sample_diff_us >= low_low)
         {
            dpcm_code = 9;
         }
         else
         {
            dpcm_code = 8;
         }
      }
   }


   if (sample_diff < 0)
   {
      dpcm_code = ~dpcm_code + 1;      // use the 2's compliment of
                                       // the dpcm code
      dpcm_code &= 0x0F;               // use only the 4 LSBs for the
                                       // dpcm code
   }

   isr_count1 = Q_VALUES[dpcm_code];
   isr_count1 = isr_count1;
   encoderpredsample = encoderpredsample + Q_VALUES[dpcm_code];

   if(!OutputByteReady)
   {
	  OutputByteReady = TRUE;
	  OutputByte = dpcm_code;
      OutputByte<<=4;
   }
   else
   {
      OutputByteReady = FALSE;
      OutputByte |= dpcm_code & 0x0F;
      EAstate = EA;
      EA = 0;
      TransmitFIFO_Push(OutputByte);
      EA = EAstate;
   }

}

//-----------------------------------------------------------------------------
// DPCM_Decode
//-----------------------------------------------------------------------------
//
// decode the 8-bit (MSBs of 10-bit sample) sample using DPCM compression.
// INPUTS:
//    old_prediction - the 8-bit unsigned predicted value from the current
//                     cycle which will be used to calculate the new predicted
//                     value
//    dpcm_code -   the 4-bit code indicating the quantized difference between
//                  the old_prediction and the current sample values
//                  (see DPCM_Encode for the dpcm_code values)
// OUTPUTS:
//    new_prediction - the 8-bit unsigned predicted value for the next cycle
//
void DPCM_Decompress (void)
{
	unsigned char CompressedByte, CompressedSample;
	static signed short UncompressedWord;
   bit EAstate;

   EAstate = EA;
   EA = 0;
	CompressedByte = ReceiveFIFO_Pull();
	EA = EAstate;

	CompressedSample = CompressedByte>>4;

	UncompressedWord = UncompressedWord + Q_VALUES[CompressedSample];

   if (UncompressedWord > 3)
   {
      UncompressedWord--;
   }
   else
   if (UncompressedWord < 3)
   {
      UncompressedWord++;
   }

   if (UncompressedWord > 511)
   {
      UncompressedWord = 511;
   }
   else
   if (UncompressedWord < -512)
   {
      UncompressedWord = -512;
   }

   EAstate = EA;
   EA = 0;
   DACTXFIFO_Push(UncompressedWord + 512);
   EA = EAstate;

	CompressedSample = CompressedByte & 0x0F;

	UncompressedWord = UncompressedWord + Q_VALUES[CompressedSample];

   if (UncompressedWord > 3)
   {
      UncompressedWord--;
   }
   else
   if (UncompressedWord < 3)
   {
      UncompressedWord++;
   }

   if (UncompressedWord > 511)
   {
      UncompressedWord = 511;
   }
   else
   if (UncompressedWord < -512)
   {
      UncompressedWord = -512;
   }

	EAstate = EA;
	EA = 0;
   DACTXFIFO_Push(UncompressedWord + 512);
   EA = EAstate;

}
//-----------------------------------------------------------------------------
// Wait Functions
//-----------------------------------------------------------------------------
// These functions cause the micro controller to spin for a time defined by the
// functions' input parameter.
//

void WaitUS (unsigned int count)
{
   TCON &= ~0x30;                      // Stop Timer0; clear TF0
   TMOD &= ~0x0F;                      // Timer0 in 8-bit autoreload mode
   TMOD |=  0x03;
   CKCON |= 0x04;                      // Timer0 counts SYSCLKs

   TH0 = (-SYSCLK / 10000000);         // overflow in 1us
   TL0 = TH0;

   TR0 = 1;                            // Start Timer0
   do {
      while (!TF0);                    // wait for overflow
      TF0 = 0;                         // clear overflow flag
      count--;                         // update counter
   } while (count != 0);               // continue for <count> us

   TR0 = 0;                            // Stop Timer0
}

void WaitMS (unsigned int count)
{

   TCON &= ~0x30;                      // Stop Timer0; clear TF0
   TMOD &= ~0x0F;                      // Timer0 in 16-bit mode
   TMOD |=  0x01;
   CKCON |= 0x04;                      // Timer0 counts SYSCLKs

   TH0 = (-SYSCLK / 1000) >> 8;        // overflow in 1ms
   TL0 = (-SYSCLK / 1000);

   TR0 = 1;                            // Start Timer0
   do {

      while (!TF0);                    // wait for overflow
      TR0 = 0;                         // Stop Timer0
      TF0 = 0;                         // clear overflow flag

      TH0 = (-SYSCLK / 1000) >> 8;     // overflow in 1ms
      TL0 = (-SYSCLK / 1000);

      TR0 = 1;                         // Start Timer0

      count--;                         // update counter
   } while (count != 0);               // continue for <count> ms

   TR0 = 0;                            // Stop Timer0
}