//-----------------------------------------------------------------------------
// OSC_RTC_Cal1.c
//-----------------------------------------------------------------------------
// Copyright 2002 Cygnal Integrated Products, Inc.
//
// AUTH: BW
// DATE: 01 MAR 02
//
// This program shows an example of how an external crystal oscillator
// can be used to measure the internal oscillator frequency to a sufficient
// degree to enable UART operation (better than +/- 2.5%).
//
// In this example, a 32.768kHz watch crystal (with associated loading
// capacitors) is connected between XTAL1 and XTAL2.  The PCA counter is
// used as a generic 16-bit counter that uses EXTCLK / 8 as its time base.
// We preload it to generate an overflow in 8 counts.  Timer0 is configured
// as a 16-bit counter that is set to count SYSCLKs.  The internal oscillator
// is configured to its highest setting, and provides the system clock source.
//
// The number of 16 MHz clock cycles that occur in 4096 cycles of
// EXTCLK / 8 when EXTCLK = 32.768kHz is  16,000,000.  It is calculated as 
// follows: 16MHz / 32.768kHz * 8 * 8 * 512 = 31,250 * 512 = 16,000,000. 
//
// The measurement algorithm used in SYSCLK_Measure () counts the total number
// of system clocks in 4096 periods of EXTCLK / 8 (1 full second) and maintains
// overflow counters using Timer0. The result is given in MHz.
//
// The system clock frequency is then stored in a global variable SYSCLK.  The
// target UART baud rate is stored in a global constant BAUDRATE.
//
// A set of RTC values for seconds, minutes, hours, and days are also
// maintained by the interrupt handler for Timer 3, which is configured
// to use EXTCLK / 8 as its time base and to reload every 4096 counts.
// This generates an interrupt once every second.
//
// Target: C8051F02x
// Tool chain: KEIL C51 6.03 / KEIL EVAL C51
//

//-----------------------------------------------------------------------------
// Includes
//-----------------------------------------------------------------------------

#include <c8051f020.h>                 // SFR declarations
#include <stdio.h>
#include <math.h>

//-----------------------------------------------------------------------------
// 16-bit SFR Definitions for 'F02x
//-----------------------------------------------------------------------------

sfr16 DP       = 0x82;                 // data pointer
sfr16 TMR3RL   = 0x92;                 // Timer3 reload value
sfr16 TMR3     = 0x94;                 // Timer3 counter
sfr16 ADC0     = 0xbe;                 // ADC0 data
sfr16 ADC0GT   = 0xc4;                 // ADC0 greater than window
sfr16 ADC0LT   = 0xc6;                 // ADC0 less than window
sfr16 RCAP2    = 0xca;                 // Timer2 capture/reload
sfr16 T2       = 0xcc;                 // Timer2
sfr16 RCAP4    = 0xe4;                 // Timer4 capture/reload
sfr16 T4       = 0xf4;                 // Timer4
sfr16 DAC0     = 0xd2;                 // DAC0 data
sfr16 DAC1     = 0xd5;                 // DAC1 data

//-----------------------------------------------------------------------------
// Global CONSTANTS
//-----------------------------------------------------------------------------

//#define SYSCLK       22118400          // SYSCLK frequency in Hz
#define BAUDRATE     19200             // Baud rate of UART in bps

sbit LED = P1^6;                       // LED = 1 means ON

//-----------------------------------------------------------------------------
// Structures, Unions, Enumerations, and Type definitions
//-----------------------------------------------------------------------------

typedef union ULong {
   long Long;
   unsigned int UInt[2];
   unsigned char Char[4];
} ULong;

//-----------------------------------------------------------------------------
// Function PROTOTYPES
//-----------------------------------------------------------------------------

void SYSCLK_Init (void);
void PORT_Init (void);
void UART0_Init (void);
void Timer3_Init (void);
void SYSCLK_Measure (void);

void Timer3_ISR (void);

//-----------------------------------------------------------------------------
// Global VARIABLES
//-----------------------------------------------------------------------------

long SYSCLK;                           // holds SYSCLK frequency in Hz
unsigned char SECONDS;                 // seconds counter
unsigned char MINUTES;                 // minutes counter
unsigned char HOURS;                   // hours counter
unsigned int DAYS;                     // days counter

//-----------------------------------------------------------------------------
// MAIN Routine
//-----------------------------------------------------------------------------

void main (void) {

   WDTCN = 0xde;                       // disable watchdog timer
   WDTCN = 0xad;

   SYSCLK_Init ();                     // initialize oscillator
   PORT_Init ();                       // initialize crossbar and GPIO

   Timer3_Init ();                     // initialize Timer 3 for RTC mode

   EA = 1;                             // enable global interrupts

   SYSCLK_Measure ();                 // measure internal oscillator and
                                       // update SYSCLK variable

   UART0_Init ();                      // initialize UART0

   printf ("\nSYSCLK = %ld Hz\n\n", SYSCLK);
 
   while (1) {

      OSCICN = 0x07;                   // switch to fast internal osc

      LED = 1;                         // turn LED on

      printf ("%u Days, %02u:%02u:%02u\n", DAYS, (unsigned) HOURS,
              (unsigned) MINUTES, (unsigned) SECONDS);

      while (TI0 == 0);                // wait for end of transmission

      OSCICN = 0x08;                   // switch to EXTOSC

      LED = 0;                         // turn LED off

      PCON |= 0x01;                    // go into IDLE mode (CPU will be
                                       // awakened by the next interrupt,
                                       // and will re-print the RTC
                                       // values).
   }
}

//-----------------------------------------------------------------------------
// Initialization Subroutines
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// SYSCLK_Init
//-----------------------------------------------------------------------------
//
// This routine initializes the system clock to use a low-frequency crystal
// as its clock source.
//
void SYSCLK_Init (void)
{
   int i;                              // delay counter
   int current, last;                  // used in osc. stabilization check
   int tolerance_count;

   OSCXCN = 0x60;                      // start external oscillator with
                                       // low-frequency crystal

   for (i=0; i < 256; i++) ;           // wait for osc to start up

   while (!(OSCXCN & 0x80)) ;          // Wait for crystal osc. to settle

   OSCICN = 0x07;                      // select internal oscillator at its
                                       // fastest setting as the system
                                       // clock source

   // low-frequency crystal stabilization wait routine
   // Here we measure the number of system clocks in 8 EXTCLK / 8 periods.
   // We compare successive measurements.  When we obtain 1000 measurements
   // in a row that are all within 20 system clocks of each other, the
   // routine will exit.  This condition will only occur once the crystal
   // oscillator has fully stabilized at its resonant frequency.  
   // 
   // Note that this can take several seconds.

   // init PCA0
   PCA0CN = 0x00;                         // Stop counter; clear all flags
   PCA0MD = 0x0b;                         // PCA counts in IDLE mode;
                                          // EXTCLK / 8 is time base;
                                          // overflow interrupt is enabled

   // init Timer0
   TCON &= ~0x30;                         // Stop timer; clear TF0
   TMOD &= ~0x0f;                         // Timer0 in 16-bit counter mode
   TMOD |=  0x01;
   CKCON |= 0x08;                         // Timer0 counts SYSCLKs

   tolerance_count = 1000;                // wait for 1000 cycles in a row
                                          // to lie within 20 clocks of each
                                          // other
   current = 0;
   do {
      PCA0CN = 0x00;
      PCA0L = 0xFF;                       // set PCA time base to '-1'
      PCA0H = 0xFF;
      TCON &= ~0x30;
      TH0 = 0x00;                         // init T0 time base
      TL0 = 0x00;

      // start PCA0
      CR = 1;
      while (CF == 0);                    // wait for edge
      TR0 = 1;                            // Start Timer0
      CF = 0;                             // clear PCA overflow
      PCA0L = -8;                         // set PCA to overflow in 8 cycles
      PCA0H = (-8) >> 8;
      while (CF == 0);
      TR0 = 0;
      last = current;
      current = (TH0 << 8) | TL0;
      if (abs (current - last) > 20) {
         tolerance_count = 1000;          // falls outside bounds; reset
                                          // counter
      } else {
         tolerance_count--;               // in-bounds; update counter
      }
   } while (tolerance_count != 0);
}

//-----------------------------------------------------------------------------
// PORT_Init
//-----------------------------------------------------------------------------
//
// Configure the Crossbar and GPIO ports
//
void PORT_Init (void)
{
   XBR0    |= 0x04;                    // Enable UART0
   XBR2    |= 0x40;                    // Enable crossbar and weak pull-ups
   P0MDOUT |= 0x01;                    // enable TX0 as a push-pull output
   P1MDOUT |= 0x40;                    // enable LED as push-pull output
}

//-----------------------------------------------------------------------------
// UART0_Init
//-----------------------------------------------------------------------------
//
// Configure the UART0 using Timer1, for <baudrate> and 8-N-1.
//
void UART0_Init (void)
{
   SCON0  = 0x50;                      // SCON0: mode 1, 8-bit UART, enable RX
   TMOD   = 0x20;                      // TMOD: timer 1, mode 2, 8-bit reload
   TH1    = -(SYSCLK/BAUDRATE/16);     // set Timer1 reload value for baudrate
   TR1    = 1;                         // start Timer1
   CKCON |= 0x10;                      // Timer1 uses SYSCLK as time base
   PCON  |= 0x80;                      // SMOD00 = 1
   ES0    = 0;                         // disable UART0 interrupts
   TI0    = 1;                         // indicate ready for TX
}

//-----------------------------------------------------------------------------
// Timer3_Init
//-----------------------------------------------------------------------------
//
// Configure Timer3 for 16-bit auto-reload mode using EXTCLK / 8 as its time
// base and to reload every 4096 counts.  This will generate one interrupt
// every second.
//
void Timer3_Init (void)
{
   TMR3CN = 0x01;                      // Stop Timer3; Clear TF3; Timer3
                                       // counts SYSCLK / 8
   TMR3RL = -4096;                     // reload every 4096 counts
   TMR3 = TMR3RL;                      // init T3
   EIE2 |= 0x01;                       // Enable Timer3 interrupts
   TMR3CN |= 0x04;                     // Start Timer3
}

//-----------------------------------------------------------------------------
// SYSCLK_Measure
//-----------------------------------------------------------------------------
//
// This routine uses the external oscillator to measure the frequency of the
// internal oscillator.  Assumes that the external oscillator has been
// started and settled.  Also assumes that the internal oscillator operating
// at its highest frequency is selected as the system clock source.
//
// The measurement algorithm is as follows:
// 1. PCA set to '-1'; Timer0 set to 0x0000; PCA stopped; Timer0 stopped
// 2. PCA started (CR = 1)
// 3. On CF, Timer0 is started (TR0 = 1); CF is cleared, PCA remains running
// 4. PCA set to '-4096' (note, we have about 4000 system clocks to
//    perform this operation before actually missing a count)
// 5. On CF, Timer0 is stopped (TR0 = 0);
// 6. Timer0 contains the number of 16 MHz SYSCLKs in 4096 periods of EXTCLK/8
//
// Upon completion, the global variable SYSCLK contains the internal 
// oscillator frequency in Hz.
//
// I believe the worst-case measurement error is around 20 system clocks.
// 20 / 16e6 = 1.3 ppm (far less than typical crystal ppm's of 20)
//
void SYSCLK_Measure (void)
{
   unsigned int T0_high;                  // keeps track of Timer0 overflows
   ULong temp;                            // byte-addressable Long

   // init PCA0
   PCA0CN = 0x00;                         // Stop counter; clear all flags
   PCA0MD = 0x0b;                         // PCA counts in IDLE mode;
                                          // EXTCLK / 8 is time base;
                                          // overflow interrupt is enabled
   PCA0L = 0xFF;                          // set time base to '-1'
   PCA0H = 0xFF;

   // init Timer0
   T0_high = 0;                           // clear overflow counter
   CKCON |= 0x08;                         // Timer0 counts SYSCLKs
   TCON &= ~0x30;                         // Stop timer; clear TF0
   TMOD &= ~0x0f;                         // Timer0 in 16-bit counter mode
   TMOD |=  0x01;
   TH0 = 0x00;                            // init time base
   TL0 = 0x00;

   // start PCA0
   CR = 1;
   while (CF == 0);                       // wait for edge
   TR0 = 1;                               // Start Timer0
   CF = 0;                                // clear PCA overflow
   PCA0L = -4096;                         // set PCA to overflow in 4096 
                                          // cycles (1 second)
   PCA0H = (-4096) >> 8;

   while (CF == 0) {                      // wait for 1 second
      if (TF0) {                          // handle T0 overflow
         T0_high++;
         TF0 = 0;
      }
   }
   TR0 = 0;                               // Stop Timer0

   // read Timer0 value

   //SYSCLK = (T0_high << 16) | (TH0 << 8) | TL0; // 0xa0 clock cycles
   // = 0x1a clock cycles using the optimization below
   temp.UInt[0] = T0_high;
   temp.Char[2] = TH0;
   temp.Char[3] = TL0;

   SYSCLK = temp.Long;
}

//-----------------------------------------------------------------------------
// Timer3_ISR
//-----------------------------------------------------------------------------
//
// This ISR is called on overflow of Timer3, which occurs once every second.
// Here we update a set of global RTC counters for seconds, minutes, hours,
// and days.
//
void Timer3_ISR (void) interrupt 14 using 3
{
   TMR3CN &= ~0x80;                       // clear Timer 3 overflow flag

   SECONDS++;
   if (SECONDS == 60) {
      SECONDS = 0;
      MINUTES++;
      if (MINUTES == 60) {
         MINUTES = 0;
         HOURS++;
         if (HOURS == 24) {
            HOURS = 0;
            DAYS++;
         }
      }
   }
}