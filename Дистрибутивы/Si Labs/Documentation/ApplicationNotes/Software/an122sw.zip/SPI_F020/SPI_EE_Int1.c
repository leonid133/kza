//-----------------------------------------------------------------------------
// SPI_EE_Int1.c
//-----------------------------------------------------------------------------
// Copyright 2001 Cygnal Integrated Products, Inc.
//
// AUTH: BW
// DATE: 14 SEP 01
//
// This program shows an example of how to interface to an SPI EEPROM using
// the SPI0 interface in interrupt-mode. The SPI EEPROM used here is a 
// Microchip 25LC320 (4k bytes).  The hardware connections are as follows:
//
// P0.0 - TX -- UART used for display/testing purposes
// P0.1 - RX
//
// P0.2 - SCK  (connected to SCK on EEPROM)
// P0.3 - MISO (connected to SI on EEPROM)
// P0.4 - MOSI (connected to SO on EEPROM)
// P0.5 - NSS  (unconnected, but pulled high by on-chip pull-up resistor)
//
// P1.7 - EE_CS (connected to /CS on EEPROM)
//
// Assumes an 22.1184MHz crystal is attached between XTAL1 and XTAL2.
//
// In this example, the attached SPI device is loaded with a test pattern.
// The EEPROM contents are then verified with the test pattern.  If the test
// pattern is verified with no errors, the LED blinks on operation complete.
// Otherwise, the LED stays off.  Progress can also be monitored by a terminal
// connected to UART0 operating at 115.2kbps.
//
// Target: C8051F02x 
// Tool chain: KEIL C51 6.03 / KEIL EVAL C51
//

//-----------------------------------------------------------------------------
// Includes
//-----------------------------------------------------------------------------

#include <c8051f020.h>                 // SFR declarations
#include <stdio.h>

//-----------------------------------------------------------------------------
// 16-bit SFR Definitions for 'F00x
//-----------------------------------------------------------------------------

sfr16 DP       = 0x82;                 // data pointer
sfr16 TMR3RL   = 0x92;                 // Timer3 reload value
sfr16 TMR3     = 0x94;                 // Timer3 counter
sfr16 ADC0     = 0xbe;                 // ADC0 data
sfr16 ADC0GT   = 0xc4;                 // ADC0 greater than window
sfr16 ADC0LT   = 0xc6;                 // ADC0 less than window
sfr16 RCAP2    = 0xca;                 // Timer2 capture/reload
sfr16 T2       = 0xcc;                 // Timer2
sfr16 DAC0     = 0xd2;                 // DAC0 data
sfr16 DAC1     = 0xd5;                 // DAC1 data

//-----------------------------------------------------------------------------
// Global CONSTANTS
//-----------------------------------------------------------------------------

#define     TRUE     1
#define     FALSE    0

#define     SYSCLK   22118400          // SYSCLK frequency in Hz
#define     BAUDRATE 115200            // Baud rate of UART in bps

sbit        LED = P1^6;                // LED='1' means ON
sbit        EE_CS = P1^7;              // EEPROM CS signal

#define     EE_SIZE     4096           // EEPROM size in bytes
#define     EE_READ     0x03           // EEPROM Read command
#define     EE_WRITE    0x02           // EEPROM Write command
#define     EE_WRDI     0x04           // EEPROM Write disable command
#define     EE_WREN     0x06           // EEPROM Write enable command
#define     EE_RDSR     0x05           // EEPROM Read status register
#define     EE_WRSR     0x01           // EEPROM Write status register

//-----------------------------------------------------------------------------
// Function PROTOTYPES
//-----------------------------------------------------------------------------

void SYSCLK_Init (void);
void PORT_Init (void);
void UART0_Init (void);
void SPI0_Init (void);
void Timer0_Init (void);
void Timer0_ms (unsigned ms);

unsigned char EE_Read (unsigned Addr);
void EE_Write (unsigned Addr, unsigned char value);

//-----------------------------------------------------------------------------
// Global VARIABLES
//-----------------------------------------------------------------------------

bit EE_Ready = FALSE;                  // semaphore for SPI0/EEPROM
bit EE_WR = FALSE;                     // TRUE = write; FALSE = read
unsigned EE_Addr = 0x0000;             // EEPROM address
unsigned char EE_Data = 0x00;          // EEPROM data

//-----------------------------------------------------------------------------
// MAIN Routine
//-----------------------------------------------------------------------------

void main (void) {

   unsigned test_addr;                 // address of EEPROM byte
   unsigned char test_byte;

   WDTCN = 0xde;                       // disable watchdog timer
   WDTCN = 0xad;

   SYSCLK_Init ();                     // initialize oscillator
   PORT_Init ();                       // initialize crossbar and GPIO
   UART0_Init ();                      // initialize UART0
   Timer0_Init ();                     // initialize Timer0

   SPI0_Init ();                       // initialize SPI0

   EA = 1;                             // enable global interrupts

   // fill EEPROM with 0xFF's
   LED = 1;
   for (test_addr = 0; test_addr < EE_SIZE; test_addr++) {
      test_byte = 0xff;
      EE_Write (test_addr, test_byte);

      // print status to UART0
      if ((test_addr % 16) == 0) {
         printf ("\nwriting 0x%04x: %02x ", test_addr, (unsigned) test_byte);
      } else {
         printf ("%02x ", (unsigned) test_byte);
      }
   }

   // verify EEPROM with 0xFF's
   LED = 0;
   for (test_addr = 0; test_addr < EE_SIZE; test_addr++) {
      test_byte = EE_Read (test_addr);

      // print status to UART0
      if ((test_addr % 16) == 0) {
         printf ("\nverifying 0x%04x: %02x ", test_addr, (unsigned) test_byte);
      } else {
         printf ("%02x ", (unsigned) test_byte);
      }
      if (test_byte != 0xFF) {
         printf ("Error at %u\n", test_addr);
         while (1);                    // stop here on error
      }
   }

   // fill EEPROM memory with LSB of EEPROM address.
   LED = 1;
   for (test_addr = 0; test_addr < EE_SIZE; test_addr++) {
      test_byte = test_addr & 0xff;
      EE_Write (test_addr, test_byte);

      // print status to UART0
      if ((test_addr % 16) == 0) {
         printf ("\nwriting 0x%04x: %02x ", test_addr, (unsigned) test_byte);
      } else {
         printf ("%02x ", (unsigned) test_byte);
      }
   }

   // verify EEPROM memory with LSB of EEPROM address
   LED = 0;
   for (test_addr = 0; test_addr < EE_SIZE; test_addr++) {
      test_byte = EE_Read (test_addr);

      // print status to UART0
      if ((test_addr % 16) == 0) {
         printf ("\nverifying 0x%04x: %02x ", test_addr, (unsigned) test_byte);
      } else {
         printf ("%02x ", (unsigned) test_byte);
      }
      if (test_byte != (test_addr & 0xFF)) {
         printf ("Error at %u\n", test_addr);
         while (1);                    // stop here on error
      }
   }

   ET0 = 0;                            // disable Timer0 interrupts

   while (1) {                         // Flash LED when done
      Timer0_ms (100);
      LED = ~LED;
   }
}

//-----------------------------------------------------------------------------
// Subroutines
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// SYSCLK_Init
//-----------------------------------------------------------------------------
//
// This routine initializes the system clock to use an 22.1184 MHz crystal
// as its clock source.
//
void SYSCLK_Init (void)
{
   int i;                              // delay counter

   OSCXCN = 0x67;                      // start external oscillator with
                                       // 22.1184 MHz crystal

   for (i=0; i < 256; i++) ;           // Wait for osc. to start up

   while (!(OSCXCN & 0x80)) ;          // Wait for crystal osc. to settle

   OSCICN = 0x88;                      // select external oscillator as SYSCLK
                                       // source and enable missing clock
                                       // detector
}

//-----------------------------------------------------------------------------
// PORT_Init
//-----------------------------------------------------------------------------
//
// Configure the Crossbar and GPIO ports
//
void PORT_Init (void)
{
   XBR0   |= 0x06;                     // Enable SPI0 and UART0
   XBR1    = 0x00;
   XBR2    = 0x40;                     // Enable crossbar and weak pull-ups
   P0MDOUT |= 0x15;                    // enable P0.0 (TX), P0.2 (SCK), and 
                                       // P0.4 (MOSI) as push-pull outputs 
   P1MDOUT |= 0xC0;                    // enable P1.6 (LED) and P1.7 (EE_CS)
                                       // as push-pull outputs
}

//-----------------------------------------------------------------------------
// SPI0_Init
//-----------------------------------------------------------------------------
//
// Configure SPI0 for 8-bit, 2MHz SCK, Master mode, interrupt operation, data 
// sampled on 1st SCK rising edge.  SPI0 interrupts are enabled here
//
void SPI0_Init (void)
{
   SPI0CFG = 0x07;                     // data sampled on 1st SCK rising edge
                                       // 8-bit data words

   SPI0CN = 0x03;                      // Master mode; SPI enabled; flags
                                       // cleared
   SPI0CKR = SYSCLK/2/2000000;         // SPI clock <= 2MHz (limited by 
                                       // EEPROM spec.)
   EE_Ready = TRUE;                    // post SPI0/EEPROM available
   EIE1 |= 0x01;                       // enable SPI0 interrupts
}

//-----------------------------------------------------------------------------
// UART0_Init
//-----------------------------------------------------------------------------
//
// Configure the UART0 using Timer1, for <baudrate> and 8-N-1.
//
void UART0_Init (void)
{
   SCON0  = 0x50;                      // SCON0: mode 1, 8-bit UART, enable RX
   TMOD   = 0x20;                      // TMOD: timer 1, mode 2, 8-bit reload
   TH1    = -(SYSCLK/BAUDRATE/16);     // set Timer1 reload value for baudrate
   TR1    = 1;                         // start Timer1
   CKCON |= 0x10;                      // Timer1 uses SYSCLK as time base
   PCON  |= 0x80;                      // SMOD00 = 1 (disable baud rate 
                                       // divide-by-two)
   TI0    = 1;                         // Indicate TX0 ready
}

//-----------------------------------------------------------------------------
// Timer0_Init
//-----------------------------------------------------------------------------
//
// Configure Timer0 for 16-bit interrupt mode.
//
void Timer0_Init (void)
{
   TCON  &= ~0x30;                     // STOP Timer0 and clear overflow flag
   TMOD  &= ~0x0f;                     // configure Timer0 to 16-bit mode
   TMOD  |=  0x01;
   CKCON |=  0x08;                     // Timer0 counts SYSCLKs
}

//-----------------------------------------------------------------------------
// Timer0_ms
//-----------------------------------------------------------------------------
//
// Configure Timer0 to delay <ms> milliseconds before returning.
//
void Timer0_ms (unsigned ms)
{
   unsigned i;                         // millisecond counter

   TCON  &= ~0x30;                     // STOP Timer0 and clear overflow flag
   TMOD  &= ~0x0f;                     // configure Timer0 to 16-bit mode
   TMOD  |=  0x01;
   CKCON |=  0x08;                     // Timer0 counts SYSCLKs

   for (i = 0; i < ms; i++) {          // count milliseconds
      TR0 = 0;                         // STOP Timer0
      TH0 = (-SYSCLK/1000) >> 8;       // set Timer0 to overflow in 1ms
      TL0 = -SYSCLK/1000;
      TR0 = 1;                         // START Timer0
      while (TF0 == 0);                // wait for overflow
      TF0 = 0;                         // clear overflow indicator
   }
}

//-----------------------------------------------------------------------------
// EE_Read
//-----------------------------------------------------------------------------
//
// This routine reads and returns a single EEPROM byte whose address is
// given in <Addr>.
//
unsigned char EE_Read (unsigned Addr)
{
   while (EE_Ready == FALSE);          // wait for EEPROM available

   EE_Ready = FALSE;                   // claim EEPROM

   EE_Addr = Addr;                     // initialize EEPROM address
   EE_WR = FALSE;                      // set up for READ operation

   SPIF = 1;                           // initiate EEPROM operation

   while (EE_Ready == FALSE);          // wait for operation complete

   return EE_Data;                     // return data
}

//-----------------------------------------------------------------------------
// EE_Write
//-----------------------------------------------------------------------------
//
// This routine writes a single EEPROM byte <value> to address <Addr>.  Here
// we implement pre-write polling.
//
void EE_Write (unsigned Addr, unsigned char value)
{
   while (EE_Ready == FALSE);          // wait for EEPROM available

   EE_Ready = FALSE;                   // claim EEPROM

   EE_Addr = Addr;                     // initialize EEPROM address
   EE_Data = value;                    // initialize EEPROM data
   EE_WR = TRUE;                       // set up for WRITE operation

   SPIF = 1;                           // initiate EEPROM operation
}

//-----------------------------------------------------------------------------
// Timer0_ISR
//-----------------------------------------------------------------------------
//
// Timer0 implements a delay which is used by the SPI0_ISR to manage setup
// and hold requirements on the EE_CS line.  This ISR initiates a SPI0 
// interrupt when called, and stops Timer0.
//
void Timer0_ISR (void) interrupt 1 using 3
{
   TR0 = 0;                            // STOP Timer0
   SPIF = 1;                           // initiate SPI0 interrupt
}

//-----------------------------------------------------------------------------
// SPI0_ISR
//-----------------------------------------------------------------------------
//
// This ISR implements a state machine which handles byte-level read and
// write operations to an attached EEPROM.
//
void SPI0_ISR (void) interrupt 6 using 3
{
   enum SPI0_state { RESET, RD_S0, RD_S1, RD_S2, RD_S3, RD_S4, RD_S5, RD_S6,
                     RD_S7, WR_S0, WR_S1, WR_S2, WR_S3, WR_S4, WR_S5, WR_S6,
                     WR_S7, WR_S8, WR_S9, WR_S10, WR_S11, WR_S12, WR_S13,
                     WR_S14, WR_S15};

   static enum SPI0_state state = RESET;

   SPIF = 0;                           // clear SPI interrupt flag

   switch (state) {
      case RESET: // assert EE_CS; set Timer0 to cause SPI0 interrupt in
                  // 250ns (CS setup time); decode EE_WR to determine 
                  // whether next state is RD_S0 (read) or WR_S0 (write).
         EE_CS = 0;                    // assert CS signal on EEPROM

         // set Timer0 to interrupt 250ns from now
         ET0 = 0;                      // disable Timer0 interrupts
         TCON &= ~0x30;                // STOP Timer0 and clear overflow flag
         TH0 = (-SYSCLK/4000000) >> 8; // set Timer0 to overflow in 250ns
         TL0 = -SYSCLK/4000000;
         ET0 = 1;                      // enable Timer0 interrupts
         TR0 = 1;                      // START Timer0

         // decode EE_Write flag to determine whether operation is a read
         // or a write
         if (EE_WR == TRUE) {
            state = WR_S0;             // set up for a write
         } else {
            state = RD_S0;             // set up for a read
         }
         break;

      case RD_S0: // transmit READ op-code
         SPI0DAT = EE_READ;            // transmit READ opcode
         state = RD_S1;                // advance to next state
         break;

      case RD_S1: // transmit MSB of Address
         SPI0DAT = EE_Addr >> 8;       // transmit MSB of Address
         state = RD_S2;                // advance to next state
         break;

      case RD_S2: // transmit LSB of Address
         SPI0DAT = EE_Addr;            // transmit LSB of Address
         state = RD_S3;                // advance to next state
         break;

      case RD_S3: // transmit dummy read to get data from EEPROM
         SPI0DAT = 0;                  // transmit dummy read
         state = RD_S4;                // advance to next state
         break;

      case RD_S4: // wait 250ns (EEPROM CS hold time)

         // set Timer0 to interrupt 250ns from now
         ET0 = 0;                      // disable Timer0 interrupts
         TCON &= ~0x30;                // STOP Timer0 and clear overflow flag
         TH0 = (-SYSCLK/4000000) >> 8; // set Timer0 to overflow in 250ns
         TL0 = -SYSCLK/4000000;
         ET0 = 1;                      // enable Timer0 interrupts
         TR0 = 1;                      // START Timer0
         state = RD_S5;                // advance to next state
         break;

      case RD_S5: // raise CS and wait 500ns (EEPROM CS disable time)
         EE_CS = 1;                    // de-assert EEPROM CS

         // set Timer0 to interrupt 500ns from now
         ET0 = 0;                      // disable Timer0 interrupts
         TCON &= ~0x30;                // STOP Timer0 and clear overflow flag
         TH0 = (-SYSCLK/2000000) >> 8; // set Timer0 to overflow in 500ns
         TL0 = -SYSCLK/2000000;
         ET0 = 1;                      // enable Timer0 interrupts
         TR0 = 1;                      // START Timer0

         state = RD_S6;                // advance to next state
         break;

      case RD_S6: // read data from SPI0 and post EEPROM ready
         EE_Data = SPI0DAT;            // read EEPROM data from SPI0
         EE_Ready = TRUE;              // indicate EEPROM ready for
                                       // next operation
         state = RESET;                // reset state variable
         break;

      case WR_S0: // transmit WRITE ENABLE opcode
         SPI0DAT = EE_WREN;            // transmit WREN opcode
         state = WR_S1;                // advance to next state
         break;

      case WR_S1: // wait at least 250ns (CS hold time)
         // set Timer0 to interrupt 250ns from now
         ET0 = 0;                      // disable Timer0 interrupts
         TCON &= ~0x30;                // STOP Timer0 and clear overflow flag
         TH0 = (-SYSCLK/4000000) >> 8; // set Timer0 to overflow in 250ns
         TL0 = -SYSCLK/4000000;
         ET0 = 1;                      // enable Timer0 interrupts
         TR0 = 1;                      // START Timer0

         state = WR_S2;                // advance to next state
         break;

      case WR_S2: // raise CS and wait 500ns (CS disable time)
         EE_CS = 1;                    // deassert CS

         // set Timer0 to interrupt 500ns from now
         ET0 = 0;                      // disable Timer0 interrupts
         TCON &= ~0x30;                // STOP Timer0 and clear overflow flag
         TH0 = (-SYSCLK/2000000) >> 8; // set Timer0 to overflow in 500ns
         TL0 = -SYSCLK/2000000;
         ET0 = 1;                      // enable Timer0 interrupts
         TR0 = 1;                      // START Timer0

         state = WR_S3;                // advance to next state
         break;

      case WR_S3: // assert CS and wait 250ns (CS setup time)
         EE_CS = 0;                    // assert CS

         // set Timer0 to interrupt 250ns from now
         ET0 = 0;                      // disable Timer0 interrupts
         TCON &= ~0x30;                // STOP Timer0 and clear overflow flag
         TH0 = (-SYSCLK/4000000) >> 8; // set Timer0 to overflow in 250ns
         TL0 = -SYSCLK/4000000;
         ET0 = 1;                      // enable Timer0 interrupts
         TR0 = 1;                      // START Timer0

         state = WR_S4;                // advance to next state
         break;

      case WR_S4: // transmit WRITE opcode
         SPI0DAT = EE_WRITE;           // transmit WRITE opcode
         state = WR_S5;                // advance to next state
         break;

      case WR_S5: // transmit MSB of Address
         SPI0DAT = EE_Addr >> 8;       // transmit MSB of Address
         state = WR_S6;                // advance to next state
         break;

      case WR_S6: // transmit LSB of Address
         SPI0DAT = EE_Addr;            // transmit LSB of Address
         state = WR_S7;                // advance to next state
         break;

      case WR_S7: // transmit DATA
         SPI0DAT = EE_Data;            // transmit DATA
         state = WR_S8;                // advance to next state
         break;

      case WR_S8: // wait 250ns (CS hold time)
         // set Timer0 to interrupt 250ns from now
         ET0 = 0;                      // disable Timer0 interrupts
         TCON &= ~0x30;                // STOP Timer0 and clear overflow flag
         TH0 = (-SYSCLK/4000000) >> 8; // set Timer0 to overflow in 250ns
         TL0 = -SYSCLK/4000000;
         ET0 = 1;                      // enable Timer0 interrupts
         TR0 = 1;                      // START Timer0

         state = WR_S9;                // advance to next state
         break;

      case WR_S9: // deassert CS and wait 500ns (CS disable time)
         EE_CS = 1;                    // deassert CS

         // set Timer0 to interrupt 500ns from now
         ET0 = 0;                      // disable Timer0 interrupts
         TCON &= ~0x30;                // STOP Timer0 and clear overflow flag
         TH0 = (-SYSCLK/2000000) >> 8; // set Timer0 to overflow in 500ns
         TL0 = -SYSCLK/2000000;
         ET0 = 1;                      // enable Timer0 interrupts
         TR0 = 1;                      // START Timer0

         state = WR_S10;               // advance to next state
         break;

      case WR_S10: // assert CS and wait 250ns (begin polling RDSR)
         EE_CS = 0;                    // assert CS

         // set Timer0 to interrupt 250ns from now
         ET0 = 0;                      // disable Timer0 interrupts
         TCON &= ~0x30;                // STOP Timer0 and clear overflow flag
         TH0 = (-SYSCLK/4000000) >> 8; // set Timer0 to overflow in 250ns
         TL0 = -SYSCLK/4000000;
         ET0 = 1;                      // enable Timer0 interrupts
         TR0 = 1;                      // START Timer0

         state = WR_S11;               // advance to next state
         break;

      case WR_S11: // transmit Read Status Register opcode
         SPI0DAT = EE_RDSR;            // transmit RDSR opcode
         state = WR_S12;               // advance to next state
         break;

      case WR_S12: // transmit dummy write to read Status Register
         SPI0DAT = 0;                  // dummy write (after this completes,
                                       // SPI0DAT will contain Read Status
                                       // Register contents, which are decoded
                                       // in WR_S15 below)
         state = WR_S13;               // advance to next state
         break;

      case WR_S13: // wait 250ns (CS hold time)
         // set Timer0 to interrupt 250ns from now
         ET0 = 0;                      // disable Timer0 interrupts
         TCON &= ~0x30;                // STOP Timer0 and clear overflow flag
         TH0 = (-SYSCLK/4000000) >> 8; // set Timer0 to overflow in 250ns
         TL0 = -SYSCLK/4000000;
         ET0 = 1;                      // enable Timer0 interrupts
         TR0 = 1;                      // START Timer0

         state = WR_S14;               // advance to next state
         break;

      case WR_S14: // deassert CS and wait 500ns (CS disable time)
         EE_CS = 1;                    // deassert CS

         // set Timer0 to interrupt 500ns from now
         ET0 = 0;                      // disable Timer0 interrupts
         TCON &= ~0x30;                // STOP Timer0 and clear overflow flag
         TH0 = (-SYSCLK/2000000) >> 8; // set Timer0 to overflow in 500ns
         TL0 = -SYSCLK/2000000;
         ET0 = 1;                      // enable Timer0 interrupts
         TR0 = 1;                      // START Timer0

         state = WR_S15;               // advance to next state
         break;

      case WR_S15: // check WIP bit (LSB of RDSR): if '1', then poll again;
                   // otherwise, RESET and post Write Complete
         if (SPI0DAT & 0x01) {         // TRUE if write in progress
            state = WR_S10;            // poll RDSR again
            SPIF = 1;                  // initiate new polling operation
         } else {                      // we're done. clean up.
            EE_Ready = TRUE;           // indicate EEPROM available
            state = RESET;             // reset state variable
         }
         break;

      default:
         while (1);                    // error
   }
}