//-----------------------------------------------------------------------------
// UART1_Int1.c
//-----------------------------------------------------------------------------
// Copyright 2001 Cygnal Integrated Products, Inc.
//
// AUTH: BW
// DATE: 30 OCT 01
//
// This program configures UART1 to operate in interrupt mode, showing an
// example of a string transmitter and a string receiver.  These strings are
// assumed to be NULL-terminated.
//
// Assumes an 22.1184MHz crystal is attached between XTAL1 and XTAL2.
// 
// The system clock frequency is stored in a global constant SYSCLK.  The
// target UART baud rate is stored in a global constant BAUDRATE.
//
// Target: C8051F02x
// Tool chain: KEIL C51 6.03 / KEIL EVAL C51
//

//-----------------------------------------------------------------------------
// Includes
//-----------------------------------------------------------------------------

#include <c8051f020.h>                 // SFR declarations
#include <stdio.h>
#include <string.h>

//-----------------------------------------------------------------------------
// 16-bit SFR Definitions for 'F02x
//-----------------------------------------------------------------------------

sfr16 DP       = 0x82;                 // data pointer
sfr16 TMR3RL   = 0x92;                 // Timer3 reload value
sfr16 TMR3     = 0x94;                 // Timer3 counter
sfr16 ADC0     = 0xbe;                 // ADC0 data
sfr16 ADC0GT   = 0xc4;                 // ADC0 greater than window
sfr16 ADC0LT   = 0xc6;                 // ADC0 less than window
sfr16 RCAP2    = 0xca;                 // Timer2 capture/reload
sfr16 T2       = 0xcc;                 // Timer2
sfr16 RCAP4    = 0xe4;                 // Timer4 capture/reload
sfr16 T4       = 0xf4;                 // Timer4
sfr16 DAC0     = 0xd2;                 // DAC0 data
sfr16 DAC1     = 0xd5;                 // DAC1 data

//-----------------------------------------------------------------------------
// Global CONSTANTS
//-----------------------------------------------------------------------------

#define SYSCLK       22118400          // SYSCLK frequency in Hz
#define BAUDRATE     115200            // Baud rate of UART in bps
#define RX_LENGTH    16                // length of UART RX buffer

sbit LED = P1^6;                       // LED = 1 means ON

//-----------------------------------------------------------------------------
// Function PROTOTYPES
//-----------------------------------------------------------------------------

void SYSCLK_Init (void);
void PORT_Init (void);
void UART1_Init (void);
void UART1_ISR (void);

//-----------------------------------------------------------------------------
// Global VARIABLES
//-----------------------------------------------------------------------------

bit TX_Ready;                          // '1' means okay to TX
char *TX_ptr;                          // pointer to string to transmit

bit RX_Ready;                          // '1' means RX string received
char idata RX_Buf[RX_LENGTH];          // receive string storage buffer

//-----------------------------------------------------------------------------
// MAIN Routine
//-----------------------------------------------------------------------------
void main (void) {
   int i;                              // loop counter
   char tx_buf[8];                     // transmit buffer

   WDTCN = 0xde;                       // disable watchdog timer
   WDTCN = 0xad;

   SYSCLK_Init ();                     // initialize oscillator
   PORT_Init ();                       // initialize crossbar and GPIO
   UART1_Init ();                      // initialize UART0

   EA = 1;                             // enable global interrupts

   // transmit example: here we print the numbers 0 through 999, one
   // per line to UART0.

   while (!TX_Ready);                  // wait for TX ready
   TX_Ready = 0;                       // claim transmitter
   TX_ptr = "Howdy!";                  // set buffer pointer
   SCON1 |= 0x02;                      // TI1 = 1; start transmit

   for (i = 0; i < 1000; i++) {
      while (!TX_Ready);               // wait for TX ready
      TX_Ready = 0;                    // claim transmitter
      sprintf (tx_buf, "%d\r\n", i);   // build a string
      TX_ptr = tx_buf;                 // set buffer pointer
      SCON1 |= 0x02;                   // TI1 = 1; start transmit
   }

   // receive example: here we input a line using the receive function
   // and print the line using the transmit function.

   while (1) {                         // echo messages
      while (RX_Ready == 0) ;          // wait for string
      while (!TX_Ready) ;              // wait for transmitter to be available
      TX_Ready = 0;                    // claim transmitter
      TX_ptr = RX_Buf;                 // set TX buffer pointer to point to 
                                       // received message
      SCON1 |= 0x02;                   // TI1 = 1; start transmit
      while (!TX_Ready) ;              // wait for transmission to complete
      TX_Ready = 0;
      TX_ptr = "\r\n";                 // send CR+LF
      SCON1 |= 0x02;                   // TI1 = 1; start transmit
      while (!TX_Ready) ;              // wait for transmission to complete
      RX_Ready = 0;                    // free the receiver
   }
}

//-----------------------------------------------------------------------------
// Initialization Subroutines
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// SYSCLK_Init
//-----------------------------------------------------------------------------
//
// This routine initializes the system clock to use an 22.1184MHz crystal
// as its clock source.
//
void SYSCLK_Init (void)
{
   int i;                              // delay counter

   OSCXCN = 0x67;                      // start external oscillator with
                                       // 22.1184MHz crystal

   for (i=0; i < 256; i++) ;           // wait for crystal osc. to start up

   while (!(OSCXCN & 0x80)) ;          // Wait for crystal osc. to settle

   OSCICN = 0x88;                      // select external oscillator as SYSCLK
                                       // source and enable missing clock
                                       // detector
}

//-----------------------------------------------------------------------------
// PORT_Init
//-----------------------------------------------------------------------------
//
// Configure the Crossbar and GPIO ports
//
void PORT_Init (void)
{
   XBR2    |= 0x44;                    // Enable UART1, crossbar and weak 
                                       // pull-ups
   P0MDOUT |= 0x01;                    // enable TX1 as a push-pull output
   P1MDOUT |= 0x40;                    // enable LED as push-pull output
}

//-----------------------------------------------------------------------------
// UART1_Init
//-----------------------------------------------------------------------------
//
// Configure UART1 using Timer1, for <baudrate> and 8-N-1.
//
void UART1_Init (void)
{
   SCON1  = 0x50;                      // SCON1: mode 1, 8-bit UART, enable RX
   TMOD   = 0x20;                      // TMOD: timer 1, mode 2, 8-bit reload
   TH1    = -(SYSCLK/BAUDRATE/16);     // set Timer1 reload value for baudrate
   TR1    = 1;                         // start Timer1
   CKCON |= 0x10;                      // Timer1 uses SYSCLK as time base
   PCON  |= 0x10;                      // SMOD1 = 1
   EIE2  |= 0x40;                      // enable UART1 interrupts

   TX_Ready = 1;                       // indicate TX ready for transmit
   RX_Ready = 0;                       // indicate RX string not ready
   TX_ptr = NULL;
}

/*
//-----------------------------------------------------------------------------
// UART1_Init
//-----------------------------------------------------------------------------
//
// Configure UART1 using Timer4, for <baudrate> and 8-N-1.
//
void UART1_Init (void)
{
   SCON1  = 0x50;                      // SCON1: mode 1, 8-bit UART, enable RX
   T4CON  = 0x30;                      // Stop Timer; clear int flags; enable
                                       // UART baudrate mode; enable 16-bit 
                                       // auto-reload timer function; disable
                                       // external count and capture modes
   RCAP4  = -(SYSCLK/BAUDRATE/32);     // set Timer reload value for baudrate
   T4     = RCAP4;                     // initialize Timer value
   CKCON |= 0x40;                      // Timer4 uses SYSCLK as time base

   T4CON |= 0x04;                      // TR4 = 1; start Timer4
   PCON  |= 0x10;                      // SMOD1 = 1
   EIE2  |= 0x40;                      // enable UART1 interrupts

   TX_Ready = 1;                       // indicate TX ready for transmit
   RX_Ready = 0;                       // indicate RX string not ready
   TX_ptr = NULL;
}
*/

//-----------------------------------------------------------------------------
// Interrupt Handlers
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// UART1_ISR
//-----------------------------------------------------------------------------
//
// Interrupt Service Routine for UART1:
// Transmit function is implemented as a NULL-terminated string transmitter
// that uses the global variable <TX_ptr> and the global semaphore <TX_Ready>.
// Example usage:
//    while (TX_Ready == 0);           // wait for transmitter to be available
//    TX_Ready = 0;                    // claim transmitter
//    TX_ptr = <pointer to string to transmit>;
//    SCON1 |= 0x02;                   // TI1 = 1; initiate transmit
//
// Receive function is implemented as a CR-terminated string receiver
// that uses the global buffer <RX_Buf> and global indicator <RX_Ready>.
// Once the message is received, <RX_Ready> is set to '1'.  Characters
// received while <RX_Ready> is '1' are ignored.
//
void UART1_ISR (void) interrupt 20 using 3
{
   static unsigned char RX_index = 0;  // receive buffer index
   unsigned char the_char;

   if ((SCON1 & 0x01) == 0x01) {       // handle receive function
      SCON1 &= ~0x01;                  // RI1 = 0; clear RX complete 
                                       // indicator
      if (RX_Ready != 1) {             // check to see if message pending
         the_char = SBUF1;
         if (the_char != '\r') {       // check for end of message
            // store the character
            RX_Buf[RX_index] = the_char;
            // increment buffer pointer and wrap if necessary
            if (RX_index < (RX_LENGTH - 2)) {
               RX_index++;
            } else {
               RX_index = 0;           // if length exceeded, 
               RX_Ready = 1;           // post message complete, and
                                       // NULL-terminate string
               RX_Buf[RX_index-1] = '\0';
            }
         } else {
            RX_Buf[RX_index] = '\0';   // NULL-terminate message
            RX_Ready = 1;              // post message ready
            RX_index = 0;              // reset RX message index
         }
      } else {
         ; // ignore character -- previous message has not been processed
      }
   } else if ((SCON1 & 0x02) == 0x02) {// handle transmit function
      SCON1 &= ~0x02;                  // TI1 = 0; clear TX complete 
                                       // indicator
      the_char = *TX_ptr;              // read next character in string
      if (the_char != '\0') {
         SBUF1 = the_char;             // transmit it
         TX_ptr++;                     // get ready for next character
      } else {                         // character is NULL
         TX_Ready = 1;                 // indicate ready for next TX
      }
   }
}