//-----------------------------------------------------------------------------
// ADC0_Buf1.c
//-----------------------------------------------------------------------------
// Copyright 2001 Cygnal Integrated Products, Inc.
//
// AUTH: BW
// DATE: 27 AUG 01
//
// This program shows an example of using ADC0 in interrupt mode using Timer3
// overflows as a start-of-conversion to sample AIN0 <NUM_SAMPLES> times, 
// storing the results in XDATA space.  Once <NUM_SAMPLES> have been
// collected, the samples are transmitted out UART0.  Once the transmission
// has completed, another <NUM_SAMPLES> of data are collected and the process
// repeats.
//
// Assumes an 22.1184MHz crystal is attached between XTAL1 and  XTAL2.
// 
// The system clock frequency is stored in a global constant SYSCLK.  The
// target UART baud rate is stored in a global constant BAUDRATE.  The
// ADC0 sampling rate is stored in a global constant SAMPLERATE0.  The number
// of samples collected during each batch is stored in <NUM_SAMPLES>.  The
// maximum value of <NUM_SAMPLES> is 2048 on a C8051F02x device with 4096
// bytes of XRAM (assuming no external RAM is connected to the External
// Memory Interface).
//
// Target: C8051F02x
// Tool chain: KEIL C51 6.03 / KEIL EVAL C51
//

//-----------------------------------------------------------------------------
// Includes
//-----------------------------------------------------------------------------

#include <c8051f020.h>                 // SFR declarations
#include <stdio.h>

//-----------------------------------------------------------------------------
// 16-bit SFR Definitions for 'F02x
//-----------------------------------------------------------------------------

sfr16 DP       = 0x82;                 // data pointer
sfr16 TMR3RL   = 0x92;                 // Timer3 reload value
sfr16 TMR3     = 0x94;                 // Timer3 counter
sfr16 ADC0     = 0xbe;                 // ADC0 data
sfr16 ADC0GT   = 0xc4;                 // ADC0 greater than window
sfr16 ADC0LT   = 0xc6;                 // ADC0 less than window
sfr16 RCAP2    = 0xca;                 // Timer2 capture/reload
sfr16 T2       = 0xcc;                 // Timer2
sfr16 RCAP4    = 0xe4;                 // Timer4 capture/reload
sfr16 T4       = 0xf4;                 // Timer4
sfr16 DAC0     = 0xd2;                 // DAC0 data
sfr16 DAC1     = 0xd5;                 // DAC1 data

//-----------------------------------------------------------------------------
// Global CONSTANTS
//-----------------------------------------------------------------------------

#define SYSCLK       22118400          // SYSCLK frequency in Hz
#define BAUDRATE     115200            // Baud rate of UART in bps
#define SAMPLERATE0  50000             // ADC0 Sample frequency in Hz
#define NUM_SAMPLES  2048              // number of ADC0 samples to take in
                                       // sequence
#define TRUE 1
#define FALSE 0

sbit LED = P1^6;                       // LED='1' means ON
sbit SW1 = P3^7;                       // SW1='0' means switch pressed

//-----------------------------------------------------------------------------
// Function PROTOTYPES
//-----------------------------------------------------------------------------

void SYSCLK_Init (void);
void PORT_Init (void);
void UART0_Init (void);
void ADC0_Init (void);
void Timer3_Init (int counts);
void ADC0_ISR (void);

//-----------------------------------------------------------------------------
// Global VARIABLES
//-----------------------------------------------------------------------------

xdata unsigned samples[NUM_SAMPLES];   // array to store ADC0 results
bit ADC0_DONE;                         // TRUE when NUM_SAMPLES have been
                                       // collected

//-----------------------------------------------------------------------------
// MAIN Routine
//-----------------------------------------------------------------------------

void main (void) {
   int i;                              // loop counter

   WDTCN = 0xde;                       // disable watchdog timer
   WDTCN = 0xad;

   SYSCLK_Init ();                     // initialize oscillator
   PORT_Init ();                       // initialize crossbar and GPIO
   UART0_Init ();                      // initialize UART0
   Timer3_Init (SYSCLK/SAMPLERATE0);   // initialize Timer3 to overflow at
                                       // desired ADC0 sample rate

   ADC0_Init ();                       // init ADC

   EA = 1;                             // Enable global interrupts

   while (1) {
      // collect samples...
      ADC0_DONE = FALSE;
      LED = 1;                         // turn LED on during sample process
      EIE2 |= 0x02;                    // enable ADC0 interrupts
      while (ADC0_DONE == FALSE);      // wait for samples to be taken

      // upload samples to UART0
      LED = 0;                         // turn LED off during upload process
      for (i = 0; i < NUM_SAMPLES; i++) {
         printf ("%u\n", samples[i]);
      }
      printf ("\n");
   }
}

//-----------------------------------------------------------------------------
// Initialization Subroutines
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// SYSCLK_Init
//-----------------------------------------------------------------------------
//
// This routine initializes the system clock to use an 22.1184MHz crystal
// as its clock source.
//
void SYSCLK_Init (void)
{
   int i;                              // delay counter

   OSCXCN = 0x67;                      // start external oscillator with
                                       // 22.1184MHz crystal

   for (i=0; i < 256; i++) ;           // Wait for osc. to start up

   while (!(OSCXCN & 0x80)) ;          // Wait for crystal osc. to settle

   OSCICN = 0x88;                      // select external oscillator as SYSCLK
                                       // source and enable missing clock
                                       // detector
}

//-----------------------------------------------------------------------------
// PORT_Init
//-----------------------------------------------------------------------------
//
// Configure the Crossbar and GPIO ports
//
void PORT_Init (void)
{
   XBR0    = 0x04;                     // Enable UART0
   XBR1    = 0x00;
   XBR2    = 0x40;                     // Enable crossbar and weak pull-ups
   P0MDOUT |= 0x01;                    // enable TX0 as a push-pull output
   P1MDOUT |= 0x40;                    // enable P1.6 (LED) as push-pull output
}

//-----------------------------------------------------------------------------
// UART0_Init
//-----------------------------------------------------------------------------
//
// Configure the UART0 using Timer1, for <baudrate> and 8-N-1.
//
void UART0_Init (void)
{
   SCON0   = 0x50;                     // SCON0: mode 1, 8-bit UART, enable RX
   TMOD    = 0x20;                     // TMOD: timer 1, mode 2, 8-bit reload
   TH1    = -(SYSCLK/BAUDRATE/16);     // set Timer1 reload value for baudrate
   TR1    = 1;                         // start Timer1
   CKCON |= 0x10;                      // Timer1 uses SYSCLK as time base
   PCON  |= 0x80;                      // SMOD00 = 1
   TI0    = 1;                         // Indicate TX0 ready
}

//-----------------------------------------------------------------------------
// ADC0_Init
//-----------------------------------------------------------------------------
//
// Configure ADC0 to use Timer3 overflows as conversion source, to
// generate an interrupt on conversion complete, and to use left-justified
// output mode.  Enables ADC end of conversion interrupt. Enables ADC0, but
// leaves ADC0 end-of-conversion interrupts disabled.
//
void ADC0_Init (void)
{
   ADC0CN = 0x05;                      // ADC0 disabled; normal tracking
                                       // mode; ADC0 conversions are initiated 
                                       // on overflow of Timer3; ADC0 data is
                                       // left-justified
   REF0CN = 0x07;                      // enable temp sensor, on-chip VREF,
                                       // and VREF output buffer
   AMX0SL = 0x00;                      // Select AIN0 as ADC mux output
   ADC0CF = (SYSCLK/2500000) << 3;     // ADC conversion clock = 2.5MHz
   ADC0CF &= ~0x07;                    // PGA gain = 1
   EIE2 &= ~0x02;                      // disable ADC0 interrupts

   AD0EN = 1;                          // enable ADC0
}

//-----------------------------------------------------------------------------
// Timer3_Init
//-----------------------------------------------------------------------------
//
// Configure Timer3 to auto-reload at interval specified by <counts> (no 
// interrupt generated) using SYSCLK as its time base.
//
void Timer3_Init (int counts)
{
   TMR3CN = 0x02;                      // Stop Timer3; Clear TF3;
                                       // use SYSCLK as timebase
   TMR3RL  = -counts;                  // Init reload values
   TMR3    = 0xffff;                   // set to reload immediately
   EIE2   &= ~0x01;                    // disable Timer3 interrupts
   TMR3CN |= 0x04;                     // start Timer3
}

//-----------------------------------------------------------------------------
// Interrupt Service Routines
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// ADC0_ISR
//-----------------------------------------------------------------------------
//
// ADC0 end-of-conversion ISR 
// Here we take the ADC0 sample and store it in the global array <samples[]>
// and update the local sample counter <num_samples>.  When <num_samples> ==
// <NUM_SAMPLES>, we disable ADC0 end-of-conversion interrupts and post
// ADC0_DONE = 1.
//
void ADC0_ISR (void) interrupt 15 using 3
{
   static unsigned num_samples = 0;    // ADC0 sample counter

   AD0INT = 0;                         // clear ADC0 conversion complete
                                       // indicator

   samples[num_samples] = ADC0;        // read and store ADC0 value

   num_samples++;                      // update sample counter

   if (num_samples == NUM_SAMPLES) {
      num_samples = 0;                 // reset sample counter
      EIE2 &= ~0x02;                   // disable ADC0 interrupts
      ADC0_DONE = 1;                   // set DONE indicator
   }
}
