//-----------------------------------------------------------------------------
// FLASH_Scratch1.c
//-----------------------------------------------------------------------------
// Copyright 2002 Cygnal Integrated Products, Inc.
//
// AUTH: BW
// DATE: 24 JUN 02
//
// This program illustrates how to erase, write, and read FLASH memory from
// application code written in 'C'.  This routine exercises the upper 128-
// byte FLASH sector.
//
// Note: debugging operations are not possible while SFLE = 1.
//
// Note: because this code contains routines which write to FLASH memory,
// the on-chip VDD monitor should be enabled by tying the MONEN pin high
// to VDD.
//
// Target: C8051F02x
// Tool chain: KEIL C51 6.03 / KEIL EVAL C51
//

//-----------------------------------------------------------------------------
// Includes
//-----------------------------------------------------------------------------

#include <c8051f020.h>                 // SFR declarations
#include <stdio.h>

//-----------------------------------------------------------------------------
// 16-bit SFR Definitions for 'F02x
//-----------------------------------------------------------------------------

sfr16 DP       = 0x82;                 // data pointer
sfr16 TMR3RL   = 0x92;                 // Timer3 reload value
sfr16 TMR3     = 0x94;                 // Timer3 counter
sfr16 ADC0     = 0xbe;                 // ADC0 data
sfr16 ADC0GT   = 0xc4;                 // ADC0 greater than window
sfr16 ADC0LT   = 0xc6;                 // ADC0 less than window
sfr16 RCAP2    = 0xca;                 // Timer2 capture/reload
sfr16 T2       = 0xcc;                 // Timer2
sfr16 RCAP4    = 0xe4;                 // Timer4 capture/reload
sfr16 T4       = 0xf4;                 // Timer4
sfr16 DAC0     = 0xd2;                 // DAC0 data
sfr16 DAC1     = 0xd5;                 // DAC1 data

//-----------------------------------------------------------------------------
// Global CONSTANTS
//-----------------------------------------------------------------------------

#define SYSCLK       22118400          // SYSCLK frequency in Hz

#define SCRATCH_ADDR 0x0000            // address of Scratchpad

sbit LED = P0^2;                       // LED='1' means ON
sbit SW2 = P0^3;                       // SW2='0' means switch pressed

//-----------------------------------------------------------------------------
// Function PROTOTYPES
//-----------------------------------------------------------------------------

void SYSCLK_Init (void);

//-----------------------------------------------------------------------------
// Global VARIABLES
//-----------------------------------------------------------------------------

char code my_array[] = "Monkeys";

//-----------------------------------------------------------------------------
// MAIN Routine
//-----------------------------------------------------------------------------

void main (void) {
   unsigned char xdata * data pwrite;  // FLASH write pointer
   unsigned char code * data pread;    // read pointer
   unsigned char test_array[16];
   unsigned char i;
   unsigned char temp;

   // Disable Watchdog timer
   WDTCN = 0xde;
   WDTCN = 0xad;

   SYSCLK_Init ();                     // initialize oscillator

   // erase Scratchpad
   FLSCL |= 0x01;                      // Enable FLASH writes/erases

   PSCTL |= 0x03;                      // set PSWE = PSEE = 1
   PSCTL |= 0x04;                      // set SFLE = 1 (enable
                                       // access to scratchpad)

   // initialize FLASH write pointer to SCRATCH ADDRESS
   pwrite = (unsigned char xdata *) SCRATCH_ADDR;

   *pwrite = 0x00;                     // erase SCRATCH PAGE

   PSCTL &= ~0x07;                     // set PSWE = PSEE = SLFE = 0

   // copy array into SCRATCH PAGE
   pread = my_array;                   // you can set a breakpoint at
                                       // this line to verify that the
                                       // Scratch Pad Memory has been
                                       // erased.

   PSCTL |= 0x01;                      // set PSWE = 1 so that MOVX
                                       // writes will target FLASH
                                       // memory
   for (i = 0; i < sizeof(my_array); i++) {
      PSCTL &= ~0x04;                  // clear SLFE to enable FLASH
                                       // reads from non-Scratch Pad memory
      temp = pread[i];                 // read the source character
      PSCTL |= 0x04;                   // set SFLE to enable FLASH writes
                                       // to Scratch Pad memory
      pwrite[i] = temp;                // write the byte
   }

   PSCTL &= ~0x07;                     // set PSWE = PSEE = SFLE = 0   
   FLSCL &= ~0x01;                     // clear FLWE to disable FLASH
                                       // write/erases

   // copy first 16 bytes from Scratch Pad memory to a local RAM array
   PSCTL |= 0x04;                      // set SFLE = 1 to access Scratch
                                       // Pad memory
   pread = (unsigned char code *) SCRATCH_ADDR;

   for (i = 0; i < 16; i++) {
      test_array[i] = pread[i];
   }

   PSCTL &= ~0x04;                     // clear SFLE to disable access
                                       // to Scratch Pad memory

   while (1);                          // you can set a breakpoint at
                                       // this line to verify that the
                                       // string has been written to the
                                       // Scratch Pad memory
}

//-----------------------------------------------------------------------------
// Initialization Subroutines
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// SYSCLK_Init
//-----------------------------------------------------------------------------
//
// This routine initializes the system clock to use an 22.1184MHz crystal
// as its clock source.
//
void SYSCLK_Init (void)
{
   int i;                              // delay counter

   OSCXCN = 0x67;                      // start external oscillator with
                                       // 22.1184MHz crystal

   for (i=0; i < 256; i++) ;           // wait for oscillator to start

   while (!(OSCXCN & 0x80)) ;          // Wait for crystal osc. to settle

   OSCICN = 0x88;                      // select external oscillator as SYSCLK
                                       // source and enable missing clock
                                       // detector
}
