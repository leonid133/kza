//-----------------------------------------------------------------------------
// compiler_defs.h
//-----------------------------------------------------------------------------
// Copyright 2007, Silicon Laboratories, Inc.
// http://www.silabs.com
//
// Program Description:
//
// Macro definitions to accomodate 8051 compiler differences in specifying
// special function registers and other 8051-specific features.
// **Important Note**: This header file should be included before including
// a device-specific header file such as C8051F300_defs.h.
//
// Target:         C8051xxxx
// Tool chain:     Generic
// Command Line:   None
//
// Release 1.4 - 07 AUG 2007 (PKC)
//    -Removed FID and fixed formatting.
// Release 1.3 - 30 SEP 2007 (TP)
//    -Added INTERRUPT_PROTO_USING to properly support ISR context switching
//     under SDCC.
// Release 1.2 - (BW)
//    -Added support for U8,U16,U32,S8,S16,S32,UU16,UU32 data types
// Release 1.1 - (BW)
//    -Added support for INTERRUPT, INTERRUPT_USING, INTERRUPT_PROTO,
//     SEGMENT_VARIABLE, VARIABLE_SEGMENT_POINTER,
//     SEGMENT_VARIABLE_SEGMENT_POINTER, and LOCATED_VARIABLE
// Release 1.0 - 29 SEP 2006 (PKC)
//    -Initial revision

//-----------------------------------------------------------------------------
// Header File Preprocessor Directive
//-----------------------------------------------------------------------------

#ifndef COMPILER_DEFS_H
#define COMPILER_DEFS_H

//-----------------------------------------------------------------------------
// Macro definitions
//-----------------------------------------------------------------------------

// The following macro definitions have been adapted from SDCC file compiler.h
// This file is free software; you can redistribute it and/or modify it
// under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation; either version 2.1 of the License, or
// (at your option) any later version.

// This header file is designed to accommodate 8051 compiler differences in
// specifying special function registers. The following compilers are supported:
// SDCC, Keil, Raisonance, IAR, Hi-Tech, Tasking, Crossware, Wickenh�user.

// SBIT and SFR define special bit and special function registers at the given
// address. SFR16 and SFR32 define sfr combinations at adjacent addresses in
// little-endian format. SFR16E and SFR32E define sfr combinations without
// prerequisite byte order or adjacency. None of these multi-byte sfr
// combinations will guarantee the order in which they are accessed when read
// or written.

// SDCC - Small Device C Compiler
// http://sdcc.sf.net

#if defined SDCC

# define SBIT(name, addr, bit)  __sbit  __at(addr+bit)             name
# define SFR(name, addr)        __sfr   __at(addr)                 name
# define SFR16(name, addr)      __sfr16 __at(((addr+1)<<8) | addr) name
# define SFR16E(name, fulladdr) __sfr16 __at(fulladdr)             name
# define SFR32(name, addr)      __sfr32 __at(((addr+3)<<24) | ((addr+2)<<16) | ((addr+1)<<8) | addr) name
# define SFR32E(name, fulladdr) __sfr32 __at(fulladdr)             name

# define INTERRUPT(name, vector) void name (void) interrupt (vector)
# define INTERRUPT_USING(name, vector, regnum) void name (void) interrupt (vector) using (regnum)
# define INTERRUPT_PROTO(name, vector) void name (void) interrupt (vector)
# define INTERRUPT_PROTO_USING(name, vector, regnum) void name (void) interrupt (vector) using (regnum)

// Note:  the preprocessor does not like the "__" inserted before the segment identifiers, so they have been removed,
// but things still work properly.
# define SEGMENT_VARIABLE(name, vartype, locsegment) locsegment vartype name
# define VARIABLE_SEGMENT_POINTER(name, vartype, targsegment) targsegment vartype * name
# define SEGMENT_VARIABLE_SEGMENT_POINTER(name, vartype, targsegment, locsegment) targsegment vartype * locsegment name
# define LOCATED_VARIABLE(name, vartype, locsegment, addr, init) locsegment at (addr) vartype name = init

# define LSB 0
# define MSB 1

# define b0 0
# define b1 1
# define b2 2
# define b3 3

typedef unsigned char U8;
typedef unsigned int U16;
typedef unsigned long U32;

typedef char S8;
typedef int S16;
typedef long S32;

typedef union UU16
{
   U16 U16;
   S16 S16;
   U8 U8[2];
   S8 S8[2];
} UU16;

typedef union UU32
{
   U32 U32;
   S32 S32;
   UU16 UU16[2];
   U16 U16[2];
   S16 S16[2];
   U8 U8[4];
   S8 S8[4];
} UU32;

//-----------------------------------------------------------------------------

// Keil C51
// http://www.keil.com

#elif defined __C51__

# define SBIT(name, addr, bit)  sbit  name = addr^bit
# define SFR(name, addr)        sfr   name = addr
# define SFR16(name, addr)      sfr16 name = addr
# define SFR16E(name, fulladdr) /* not supported */
# define SFR32(name, fulladdr)  /* not supported */
# define SFR32E(name, fulladdr) /* not supported */

# define INTERRUPT(name, vector) void name (void) interrupt vector
# define INTERRUPT_USING(name, vector, regnum) void name (void) interrupt vector using regnum
# define INTERRUPT_PROTO(name, vector) void name (void)
# define INTERRUPT_PROTO_USING(name, vector, regnum) void name (void)

# define SEGMENT_VARIABLE(name, vartype, locsegment) vartype locsegment name
# define VARIABLE_SEGMENT_POINTER(name, vartype, targsegment) vartype targsegment * name
# define SEGMENT_VARIABLE_SEGMENT_POINTER(name, vartype, targsegment, locsegment) vartype targsegment * locsegment name
# define LOCATED_VARIABLE(name, vartype, locsegment, addr, init) vartype locsegment name _at_ addr

# define LSB 1
# define MSB 0

# define b0 3
# define b1 2
# define b2 1
# define b3 0

typedef unsigned char U8;
typedef unsigned int U16;
typedef unsigned long U32;

typedef char S8;
typedef int S16;
typedef long S32;

typedef union UU16
{
   U16 U16;
   S16 S16;
   U8 U8[2];
   S8 S8[2];
} UU16;

typedef union UU32
{
   U32 U32;
   S32 S32;
   UU16 UU16[2];
   U16 U16[2];
   S16 S16[2];
   U8 U8[4];
   S8 S8[4];
} UU32;

//-----------------------------------------------------------------------------

// Raisonance
// http://www.raisonance.com

#elif defined __RC51__
# define SBIT(name, addr, bit)  at (addr+bit) sbit         name
# define SFR(name, addr)        sfr at addr                name
# define SFR16(name, addr)      sfr16 at addr              name
# define SFR16E(name, fulladdr) /* not supported */
# define SFR32(name, fulladdr)  /* not supported */
# define SFR32E(name, fulladdr) /* not supported */

//-----------------------------------------------------------------------------

// IAR 8051
// http://www.iar.com

#elif defined __ICC8051__

# include "stdbool.h"

// the 'bool' business, including the "stdbool.h" include are BS
# define bit bool

# define SBIT(name, addr, bit)  __no_init __bit volatile bool name @ (addr+bit)
# define SFR(name, addr)        __sfr __no_init volatile unsigned char name @ addr
# define SFR16(name, addr)      __sfr __no_init volatile unsigned int  name @ addr
# define SFR16E(name, fulladdr) /* not supported */
# define SFR32(name, fulladdr)  __sfr __no_init volatile unsigned long name @ addr
# define SFR32E(name, fulladdr) /* not supported */

// interrupts also require #pragma's for vector address and register bank, in addition to
// the below macros (untested)
# define INTERRUPT(name, vector) __interrupt void name (void)
# define INTERRUPT_USING(name, vector, regnum) __interrupt void name (void)
# define INTERRUPT_PROTO(name, vector)

// memory attributes not allowed on autovariables or parameters, therefore
// the following segment-specified macros are not supported by the compiler

# define SEGMENT_VARIABLE(name, vartype, locsegment) vartype __locsegment name ;
# define VARIABLE_SEGMENT_POINTER(name, vartype, targsegment) vartype __targsegment * name ;
# define SEGMENT_VARIABLE_SEGMENT_POINTER(name, vartype, targsegment, locsegment) vartype __targsegment * __locsegment name ;
# define LOCATED_VARIABLE(name, vartype, locsegment, addr) __locsegment vartype name @ addr ;

//-----------------------------------------------------------------------------

// Tasking / Altium
// http://www.altium.com/tasking

#elif defined _CC51
# define SBIT(name, addr, bit)  _sfrbit  name _at(addr+bit)
# define SFR(name, addr)        _sfrbyte name _at(addr)
# define SFR16(name, addr)      /* not supported */
# define SFR16E(name, fulladdr) /* not supported */
# define SFR32(name, fulladdr)  /* not supported */
# define SFR32E(name, fulladdr) /* not supported */

//-----------------------------------------------------------------------------

// Hi-Tech 8051
// http://www.htsoft.com

#elif defined HI_TECH_C
# define SBIT(name, addr, bit)  volatile bit           name @ (addr+bit)
# define SFR(name, addr)        volatile unsigned char name @ addr
# define SFR16(name, addr)      /* not supported */
# define SFR16E(name, fulladdr) /* not supported */
# define SFR32(name, fulladdr)  /* not supported */
# define SFR32E(name, fulladdr) /* not supported */

//-----------------------------------------------------------------------------

// Crossware
// http://www.crossware.com

#elif defined _XC51_VER
# define SBIT(name, addr, bit)  _sfrbit  name = (addr+bit)
# define SFR(name, addr)        _sfr     name = addr
# define SFR16(name, addr)      _sfrword name = addr
# define SFR16E(name, fulladdr) /* not supported */
# define SFR32(name, fulladdr)  /* not supported */
# define SFR32E(name, fulladdr) /* not supported */

//-----------------------------------------------------------------------------

// Wickenh�user
// http://www.wickenhaeuser.de

#elif defined __UC__
# define SBIT(name, addr, bit)  unsigned char bit  name @ (addr+bit)
# define SFR(name, addr)        near unsigned char name @ addr
# define SFR16(name, addr)      /* not supported */
# define SFR16E(name, fulladdr) /* not supported */
# define SFR32(name, fulladdr)  /* not supported */
# define SFR32E(name, fulladdr) /* not supported */

//-----------------------------------------------------------------------------

// Default
// Unknown compiler

#elif
# define SBIT(name, addr, bit)  volatile bool
# define SFR(name, addr)        volatile unsigned char
# define SFR16(name, addr)      volatile short
# define SFR16E(name, fulladdr) volatile short
# define SFR32(name, fulladdr)  volatile int
# define SFR32E(name, fulladdr) volatile int

#endif

//-----------------------------------------------------------------------------
// Header File PreProcessor Directive
//-----------------------------------------------------------------------------

#endif                                 // #define COMPILER_DEFS_H

//-----------------------------------------------------------------------------
// End Of File
//-----------------------------------------------------------------------------