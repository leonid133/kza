//-----------------------------------------------------------------------------
// C8051F36x_FFT_Demo.c
//-----------------------------------------------------------------------------
// Copyright 2006 Silicon Laboratories, Inc.
// http://www.silabs.com
//
// Program Description:
// --------------------
//
// This program generates tones on the DAC, collects that data using ADC0 at
// <SAMPLE_RATE> Hz and performs an FFT on the data.  The Real and Imaginary
// parts of the results are then sent to the UART peripheral at <BAUDRATE> bps,
// where they can be displayed or captured using a terminal (ToolStick
// Terminal) program.
//
// This program uses the MAC to calculate both the Windowing and the FFT.
// Please note that if the MAC is used in any interrupts while the FFT is being
// calculated, steps must be taken to save the FFT data before the MAC is used.
//
// This program uses the internal oscillator multiplied by 4 for an effective
// SYSCLK of 98 Mhz. This program also initializes and uses UART0 at <BAUDRATE>
// bits per second.
//
// The FFT_Code_Tables_MAC.h file must be in the same folder as this file
// when compiling.
//
// Pinout:
//
// P0.1 - IDA0 output
//
// P0.4 - UART0 TX pin
// P0.5 - UART0 RX pin
//
// P1.1 - ADC0 input
//
//
// How To Test:
// ------------
//
// 1) Change the program parameters as necessary:
//       <SYSCLK> is the selected SYSCLK rate in Hz
//       <BAUDRATE> is the UART baud rate
//       <SAMPLE_RATE> is the ADC sample rate
//       <NUM_BITS> is the number of bits of data
//       <DATA_BEGIN> is the address in XRAM where the Real and Imag arrays
//          start
//       <RUN_ONCE> determines whether the FFT will be performed continuously
//
//       <NUM_FFT> in FFT_Code_Tables_MAC.h is the number of points in the FFT
//       <WINDOW_TYPE> in FFT_Code_Tables_MAC.h is the window type as described
//
//       <SAMPLE_RATE_DAC> is the output rate of the IDAC
//       tones can be modified as shown
// 2) Compile the code with FFT_Code_Tables_MAC.h in the folder.
// 3) Download the code to an 'F36x device.  This code was specifically written
//    for the 'F362 ToolStick Daughter Card. (Alternatively, download
//    the precompiled hex file C8051F36x_FFT_Demo.hex).
// 4) Connect P0.1 and P1.1 on the ToolStick Daughter Card.
// 5) Connect to the ToolStick board using ToolStick Terminal.  The output of
//    the UART may need to be saved to a file because of its length.
// 6) Using the Real/Imaginary output, calculate the magnitudes and frequencies
//    of the FFT using FFT_graph.xls in Excel.
//
//
// Target:         C8051F36x ('F362 ToolStick Daughter Card)
// Tool chain:     Keil C51 7.50 / SDCC 7.1
// Command Line:   None
//
// Release 1.1
//    -Modified to support both SDCC and Keil (TP)
//    -16 JUL 2007
//
// Release 1.0
//    -Initial Revision (BD / TP)
//    -10 MAR 2007
//

//-----------------------------------------------------------------------------
// Includes
//-----------------------------------------------------------------------------

#include "compiler_defs.h"             // Compiler-specific declarations
                                       // (Keil/SDCC)
#include "C8051F360_defs.h"            // SFR declarations
#include <stdio.h>
#include "FFT_Code_Tables_MAC.h"       // Code Tables for FFT routines

//-----------------------------------------------------------------------------
// Global Constants and Variable Type Definitions
//-----------------------------------------------------------------------------

// System Parameters
#define INTOSC       24500000          // Internal 24.5 MHz Oscillator
#define SYSCLK       98000000          // Output of PLL derived from
                                       // (INTOSC*4/1)
#define BAUDRATE     115200            // Baud Rate for UART0

#define SAMPLE_RATE  10000             // Sample frequency in Hz

#define NUM_BITS     16                // Number of Bits in Data

#define DATA_BEGIN   0x0000            // Beginning of XRAM Data

#define RUN_ONCE     1                 // Setting to a non-zero value will
                                       // cause the program to stop after one
                                       // data set.

// For frequency generation
#define SAMPLE_RATE_DAC   100000L      // Update rate of DAC in Hz

#define PHASE_PRECISION   65536L       // Range of phase accumulator

#define LOW_697           697L * PHASE_PRECISION / SAMPLE_RATE_DAC
#define LOW_770           770L * PHASE_PRECISION / SAMPLE_RATE_DAC
#define LOW_852           852L * PHASE_PRECISION / SAMPLE_RATE_DAC
#define LOW_941           941L * PHASE_PRECISION / SAMPLE_RATE_DAC

#define HIGH_1209         1209L * PHASE_PRECISION / SAMPLE_RATE_DAC
#define HIGH_1336         1336L * PHASE_PRECISION / SAMPLE_RATE_DAC
#define HIGH_1477         1477L * PHASE_PRECISION / SAMPLE_RATE_DAC
#define HIGH_1633         1633L * PHASE_PRECISION / SAMPLE_RATE_DAC

char code SINE_TABLE[256] = {
   0x00, 0x03, 0x06, 0x09, 0x0c, 0x0f, 0x12, 0x15,
   0x18, 0x1c, 0x1f, 0x22, 0x25, 0x28, 0x2b, 0x2e,
   0x30, 0x33, 0x36, 0x39, 0x3c, 0x3f, 0x41, 0x44,
   0x47, 0x49, 0x4c, 0x4e, 0x51, 0x53, 0x55, 0x58,
   0x5a, 0x5c, 0x5e, 0x60, 0x62, 0x64, 0x66, 0x68,
   0x6a, 0x6c, 0x6d, 0x6f, 0x70, 0x72, 0x73, 0x75,
   0x76, 0x77, 0x78, 0x79, 0x7a, 0x7b, 0x7c, 0x7c,
   0x7d, 0x7e, 0x7e, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f,
   0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7f, 0x7e, 0x7e,
   0x7d, 0x7c, 0x7c, 0x7b, 0x7a, 0x79, 0x78, 0x77,
   0x76, 0x75, 0x73, 0x72, 0x70, 0x6f, 0x6d, 0x6c,
   0x6a, 0x68, 0x66, 0x64, 0x62, 0x60, 0x5e, 0x5c,
   0x5a, 0x58, 0x55, 0x53, 0x51, 0x4e, 0x4c, 0x49,
   0x47, 0x44, 0x41, 0x3f, 0x3c, 0x39, 0x36, 0x33,
   0x30, 0x2e, 0x2b, 0x28, 0x25, 0x22, 0x1f, 0x1c,
   0x18, 0x15, 0x12, 0x0f, 0x0c, 0x09, 0x06, 0x03,
   0x00, 0xfd, 0xfa, 0xf7, 0xf4, 0xf1, 0xee, 0xeb,
   0xe8, 0xe4, 0xe1, 0xde, 0xdb, 0xd8, 0xd5, 0xd2,
   0xd0, 0xcd, 0xca, 0xc7, 0xc4, 0xc1, 0xbf, 0xbc,
   0xb9, 0xb7, 0xb4, 0xb2, 0xaf, 0xad, 0xab, 0xa8,
   0xa6, 0xa4, 0xa2, 0xa0, 0x9e, 0x9c, 0x9a, 0x98,
   0x96, 0x94, 0x93, 0x91, 0x90, 0x8e, 0x8d, 0x8b,
   0x8a, 0x89, 0x88, 0x87, 0x86, 0x85, 0x84, 0x84,
   0x83, 0x82, 0x82, 0x81, 0x81, 0x81, 0x81, 0x81,
   0x80, 0x81, 0x81, 0x81, 0x81, 0x81, 0x82, 0x82,
   0x83, 0x84, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89,
   0x8a, 0x8b, 0x8d, 0x8e, 0x90, 0x91, 0x93, 0x94,
   0x96, 0x98, 0x9a, 0x9c, 0x9e, 0xa0, 0xa2, 0xa4,
   0xa6, 0xa8, 0xab, 0xad, 0xaf, 0xb2, 0xb4, 0xb7,
   0xb9, 0xbc, 0xbf, 0xc1, 0xc4, 0xc7, 0xca, 0xcd,
   0xd0, 0xd2, 0xd5, 0xd8, 0xdb, 0xde, 0xe1, 0xe4,
   0xe8, 0xeb, 0xee, 0xf1, 0xf4, 0xf7, 0xfa, 0xfd
};

//-----------------------------------------------------------------------------
// Macros
//-----------------------------------------------------------------------------

#if defined __C51__
#include <intrins.h>
#define NOP() \
   _nop_();
#elif defined SDCC
#define NOP() \
   _asm \
   nop \
   _endasm;
#endif // defined SDCC

// FFT_AplusB calculates:
//
// TempL.l = <A>.i + <B>.i;
// if ((TempL.l < 0)&&(0x01 & TempL.U8[3]))
// {
//    <result>.i = (TempL.l >> 1) + 1;
// }
// else
// {
//    <result>.i = TempL.l >> 1;
// }
//
// by calculating: -TempL.l = -A.i - TempReB.i;
// and using the MAC Rounding registers
//
// In C using the MAC:
//
// MAC0A = 0x8000;                     // Load the MAC0A register with "-1"
// MAC0BH = A.U8[MSB];                 // Multiply <A> * -1
// MAC0BL = A.U8[LSB];
//
// MAC0BH = B.U8[MSB];                 // Multiply <B> * -1
// MAC0BL = B.U8[LSB];
//
// NOP();                              // Wait for the multiplications and
// NOP();                              // accumulation to finish
//
// MAC0CF |= 0x01;                     // Switch the MAC to multiplication only
//
// MAC0BH = MAC0ACC3;                  // Multiply the result by "-1"
// MAC0BL = MAC0ACC2;
//
// NOP();                              // Wait for the multiplication to
// NOP();                              // finish
//
// MAC0CF |= 0x20;                     // Right shift the contents of the ACC
//
// NOP();
// NOP();
//
// <result> = MAC0RND;                 // Store the value of the Round register
//
// MAC0CF &= ~0x01;                    // Switch back to mult + acc mode
// MAC0CF |= 0x08;                     // Clear the ACC
//
// NOTE:
//   <A>, <B> must be of the UU16 type
//   <result> must be an int or long
#define FFT_AplusB(A, B, result) \
   MAC0A = 0x8000; \
   MAC0BH = A.U8[MSB]; \
   MAC0BL = A.U8[LSB]; \
   MAC0BH = B.U8[MSB]; \
   MAC0BL = B.U8[LSB]; \
   NOP(); \
   NOP(); \
   MAC0CF |= 0x01; \
   MAC0BH = MAC0ACC3; \
   MAC0BL = MAC0ACC2; \
   NOP(); \
   NOP(); \
   MAC0CF |= 0x20; \
   NOP(); \
   NOP(); \
   result = MAC0RND; \
   MAC0CF &= ~0x01; \
   MAC0CF |= 0x08;

// FFT_AminusB calculates:
//
// TempL.l = <A>.i - <B>.i;
// if ((TempL.l < 0)&&(0x01 & TempL.U8[3]))
// {
//    <result>.i = (TempL.l >> 1) + 1;
// }
// else
// {
//    <result>.i = TempL.l >> 1;
// }
//
// by calculating: -TempL.l = -TempReA.i - (-TempReB.i);
// and using the MAC Rounding registers
//
// In C using the MAC:
//
// MAC0A = 0x8000;                     // Load the MAC0A register with "-1"
// MAC0BH = B.U8[MSB];                 // Multiply <B> * -1
// MAC0BL = B.U8[LSB];
//
// NOP();                              // Wait for the multiplication to
// NOP();                              // finish
//
// temp.U8[MSB] = MAC0ACC3;            // Store -<B> in <temp>
// temp.U8[LSB] = MAC0ACC2;
//
// MAC0CF |= 0x08;                     // Clear the ACC
//
// MAC0BH = A.U8[MSB];                 // Multiply <A> * -1
// MAC0BL = A.U8[LSB];
//
// MAC0BH = temp.U8[MSB];              // Multiply <temp> (-<B>) * -1
// MAC0BL = temp.U8[LSB];
//
// NOP();                              // Wait for the multiplications and
// NOP();                              // accumulation to finish
//
// MAC0CF |= 0x01;                     // Switch the MAC to multiplication only
//
// MAC0BH = MAC0ACC3;                  // Multiply the result by "-1"
// MAC0BL = MAC0ACC2;
//
// NOP();                              // Wait for the multiplication to
// NOP();                              // finish
//
// MAC0CF |= 0x20;                     // Right shift the contents of the ACC
//
// NOP();
// NOP();
//
// result = MAC0RND;                   // Store the value of the Round register
//
// MAC0CF &= ~0x01;                    // Switch back to mult + acc mode
// MAC0CF |= 0x08;                     // Clear the ACC
//
// NOTE:
//   <A>, <B> must be of the UU16 type
//   <result> must be an int or long
//   <temp> must be of the UU16 type and declared in the calling function
#define FFT_AminusB(A, B, result) \
   MAC0A = 0x8000; \
   MAC0BH = B.U8[MSB]; \
   MAC0BL = B.U8[LSB]; \
   NOP(); \
   NOP(); \
   temp.U8[MSB] = MAC0ACC3; \
   temp.U8[LSB] = MAC0ACC2; \
   MAC0CF |= 0x08; \
   MAC0BH = A.U8[MSB]; \
   MAC0BL = A.U8[LSB]; \
   MAC0BH = temp.U8[MSB]; \
   MAC0BL = temp.U8[LSB]; \
   NOP(); \
   NOP(); \
   MAC0CF |= 0x01; \
   MAC0BH = MAC0ACC3; \
   MAC0BL = MAC0ACC2; \
   NOP(); \
   NOP(); \
   MAC0CF |= 0x20; \
   NOP(); \
   NOP(); \
   result = MAC0RND; \
   MAC0CF &= ~0x01; \
   MAC0CF |= 0x08;

//-----------------------------------------------------------------------------
// Global Variables
//-----------------------------------------------------------------------------

// XRAM storage of FFT: requires NUM_FFT*4 Bytes after DATA_BEGIN address
// 16 bits of data (so 2 bytes per data point) and Real and Imaginary arrays
// = 4*NUM_FFT
//UU16 xdata Real[NUM_FFT] _at_ DATA_BEGIN;
//UU16 xdata Imag[NUM_FFT] _at_ (DATA_BEGIN + (NUM_FFT * 2));
LOCATED_VARIABLE(Real[NUM_FFT], UU16, xdata, DATA_BEGIN, {{0}});
LOCATED_VARIABLE(Imag[NUM_FFT], UU16, xdata, (DATA_BEGIN + (NUM_FFT * 2)), {{0}});

// NUM_FFT is defined in the "FFT_Code_Tables_MAC.h" header file
#if (NUM_FFT < 256)
unsigned char index, ADC_Index;
#endif

// NOTE: NUM_FFT sizes larger than 256 can only be used in conjuction with
// an external XRAM through the EMIF.
#if (NUM_FFT >= 256)
unsigned int index, ADC_Index;
#endif

unsigned int BinNum;

unsigned int Input_Offset;

bit Conversion_Set_Complete;           // This indicates when the data has been
                                       // stored and is ready to be processed
                                       // using the FFT routines

// For frequency tone...
unsigned int phase_add1;               // Holds low-tone phase adder
unsigned int phase_add2;               // Holds low-tone phase adder

//-----------------------------------------------------------------------------
// Function PROTOTYPES
//-----------------------------------------------------------------------------

void SYSCLK_Init (void);
void Port_Init (void);
void UART0_Init (void);
void ADC0_Init (void);
void IDA0_Init(void);
void MAC0_Init (void);
void Timer2_Init (void);
void Timer3_Init(int counts);

void WindowCalc(UU16 Win_Array[], bit Remove_DC);
void Bit_Reverse(UU16 BR_Array[]);
void Int_FFT(UU16 ReArray[], UU16 ImArray[]);

INTERRUPT_PROTO_USING(Timer3_ISR, INTERRUPT_TIMER3, 3);
INTERRUPT_PROTO_USING(ADC0_ISR, INTERRUPT_ADC0_EOC, 2);

// Define the UART printing functions
#if defined __C51__
char putchar (char c);                 // Define putchar for Keil
#elif defined SDCC
void putchar (char c);
#endif // defined SDCC

// Similar to STARTUP.A51 for Keil, this function stub for SDCC allows us to
// disable the WDT before memory is initialized.
#if defined SDCC
void _sdcc_external_startup (void);

void _sdcc_external_startup (void)
{
   PCA0MD &= ~0x40;                    // Disable WDT in startup
}
#endif // defined SDCC

//-----------------------------------------------------------------------------
// MAIN Routine
//-----------------------------------------------------------------------------
void main()
{
   PCA0MD &= ~0x40;                    // Clear watchdog timer

   SYSCLK_Init();                      // Initialize external clock and PLL
   Port_Init ();                       // Set up Port I/O
   UART0_Init ();                      // Initialize UART0
   MAC0_Init ();                       // Initialize the MAC
   Timer2_Init ();                     // Initialize Timer2 to overflow at
                                       // <SAMPLE_RATE>
   Timer3_Init(SYSCLK/SAMPLE_RATE_DAC);// Initialize Timer3 to overflow at
                                       // <SAMPLE_RATE_DAC>
   ADC0_Init ();                       // Initialize ADC0
   IDA0_Init ();

   phase_add1 = LOW_770;
   phase_add2 = HIGH_1336;

   EA = 1;                             // Globally enable interrupts

   SFRPAGE = LEGACY_PAGE;

   while (1)
   {
      ADC_Index = 0;
      Conversion_Set_Complete = 0;

      EIE1 |= 0x08;                    // Enable ADC interrupts
      EIE1 |= 0x80;                    // Timer3 interrupt enable
                                       // ADC and IDAC interrupts are disabled
                                       // in the ADC ISR after N samples are
                                       // collected

      while(!Conversion_Set_Complete);

      WindowCalc(Real, 1);             // Window Real Data, and remove
                                       // the DC information in the FFT

      Bit_Reverse(Real);               // Sort Real (Input) Data in bit-reverse
                                       // order

      Int_FFT(Real, Imag);             // Perform FFT on data

      // Print the output of the FFT
      printf("Bin\tReal\tImag\n");
      for (BinNum = 0; BinNum < NUM_FFT/2; BinNum++)
      {
         // Print Data in the format: Bin <tab> Real <tab> Imaginary
         printf("%d\t%d\t%d\n", BinNum, Real[BinNum].S16, Imag[BinNum].S16);
      }

      // If RUN_ONCE is set, loop infinitely
      if (RUN_ONCE)
      {
         while(1);
      }
   }
}

//-----------------------------------------------------------------------------
// Initialization Subroutines
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// SYSCLK_Init
//-----------------------------------------------------------------------------
//
// Return Value:  None
// Parameters:    None
//
// This routine initializes the system clock to use the internal 24.5MHz*4
// oscillator as its clock source.
//
//-----------------------------------------------------------------------------
void SYSCLK_Init (void)
{
   char i;
   unsigned char SFRPAGE_save = SFRPAGE; // Save the current SFRPAGE

   SFRPAGE = CONFIG_PAGE;              // Switch to the necessary SFRPAGE

   OSCICN = 0x83;

   // Step 2. Set the PLLSRC bit (PLL0CN.2) to select the desired
   // clock source for the PLL.
   PLL0CN &= ~0x04;                    // Internal oscillator

   // Step 3. Program the Flash read timing bits, FLRT (FLSCL.5-4) to the
   // appropriate value for the new clock rate (see Section 15. Flash Memory
   // on page 199).
   SFRPAGE = LEGACY_PAGE;
   FLSCL |= 0x30;                      // >= 100 MHz
   SFRPAGE = CONFIG_PAGE;

   // Step 4. Enable power to the PLL by setting PLLPWR (PLL0CN.0) to �1�.
   PLL0CN |= 0x01;

   // Step 5. Program the PLL0DIV register to produce the divided reference
   // frequency to the PLL.
   PLL0DIV = 0x01;

   // Step 6. Program the PLLLP3-0 bits (PLL0FLT.3-0) to the appropriate
   // range for the divided reference frequency.
   PLL0FLT |= 0x01;

   // Step 7. Program the PLLICO1-0 bits (PLL0FLT.5-4) to the appropriate
   // range for the PLL output frequency.
   PLL0FLT &= ~0x30;

   // Step 8. Program the PLL0MUL register to the desired clock multiplication
   // factor.
   PLL0MUL = 0x04;

   // Step 9. Wait at least 5 �s, to provide a fast frequency lock.
   for (i = 100; i > 0; i--);

   // Step 10. Enable the PLL by setting PLLEN (PLL0CN.1) to �1�.
   PLL0CN |= 0x02;

   // Step 11. Poll PLLLCK (PLL0CN.4) until it changes from �0� to �1�.
   while ((PLL0CN & 0x10) != 0x10);

   // Step 12. Switch the System Clock source to the PLL using the CLKSEL
   // register.
   CLKSEL = 0x04;

   SFRPAGE = SFRPAGE_save;             // Restore the SFRPAGE
}

//-----------------------------------------------------------------------------
// Port_Init
//-----------------------------------------------------------------------------
//
// Return Value:  None
// Parameters:    None
//
// Configure the Crossbar and GPIO ports:
//
// P0.1 - IDA0 output
//
// P0.4 - UART0 TX pin
// P0.5 - UART0 RX pin
//
// P1.1 - ADC0 input
//
//-----------------------------------------------------------------------------
void Port_Init (void)
{
   unsigned char SFRPAGE_save = SFRPAGE; // Save the current SFRPAGE

   SFRPAGE = CONFIG_PAGE;              // Switch to the necessary SFRPAGE

   P0MDOUT |= 0x10;                    // Set TX pin to push-pull

   P0MDIN &= ~0x02;                    // Set P0.1 as an analog pin (IDAC)

   P0SKIP = 0x01;                      // Skip P0.1 for the IDAC output

   P1MDIN &= ~0x02;                    // Set P1.1 as an analog pin (ADC0)

   P1SKIP = 0x01;                      // Skip P1.1 for the ADC0 output

   XBR0 = 0x01;                        // Enable UART0
   XBR1 = 0x40;                        // Enable crossbar and weak pull-ups

   SFRPAGE = SFRPAGE_save;             // Restore the SFRPAGE
}

//-----------------------------------------------------------------------------
// UART0_Init
//-----------------------------------------------------------------------------
//
// Return Value:  None
// Parameters:    None
//
// Configure the UART0 using Timer1, for <BAUDRATE> and 8-N-1.
//
//-----------------------------------------------------------------------------
void UART0_Init (void)
{
   unsigned char SFRPAGE_save = SFRPAGE; // Save the current SFRPAGE

   SFRPAGE = CONFIG_PAGE;              // Switch to the necessary SFRPAGE

   SCON0 = 0x10;                       // SCON0: 8-bit variable bit rate
                                       //        level of STOP bit is ignored
                                       //        RX enabled
                                       //        ninth bits are zeros
                                       //        clear RI0 and TI0 bits
   if (SYSCLK/BAUDRATE/2/256 < 1)
   {
      TH1 = -(SYSCLK/BAUDRATE/2);
      CKCON |=  0x08;                  // T1M = 1; SCA1:0 = xx
   }
   else if (SYSCLK/BAUDRATE/2/256 < 4)
   {
      TH1 = -(SYSCLK/BAUDRATE/2/4);
      CKCON &= ~0x0B;                  // T1M = 0; SCA1:0 = 01
      CKCON |=  0x01;
   }
   else if (SYSCLK/BAUDRATE/2/256 < 12)
   {
      TH1 = -(SYSCLK/BAUDRATE/2/12);
      CKCON &= ~0x0B;                  // T1M = 0; SCA1:0 = 00
   }
   else if (SYSCLK/BAUDRATE/2/256 < 48)
   {
      TH1 = -(SYSCLK/BAUDRATE/2/48);
      CKCON &= ~0x0B;                  // T1M = 0; SCA1:0 = 10
      CKCON |=  0x02;
   }
   else
   {
      while (1);                       // Error.  Unsupported baud rate
   }

   TL1 = TH1;                          // Init Timer1
   TMOD &= ~0xF0;                      // TMOD: Timer 1 in 8-bit autoreload
   TMOD |=  0x20;
   TR1 = 1;                            // START Timer1
   TI0 = 1;                            // Indicate TX0 ready

   SFRPAGE = SFRPAGE_save;             // Restore the SFRPAGE
}

//-----------------------------------------------------------------------------
// ADC0_Init
//-----------------------------------------------------------------------------
//
// Return Value:  None
// Parameters:    None
//
// Configure ADC0 to use Timer2 overflows as conversion source, to
// generate an interrupt on conversion complete, and to use left-justified
// output mode.  Enables ADC0.
//
//-----------------------------------------------------------------------------
void ADC0_Init (void)
{
   unsigned char SFRPAGE_save = SFRPAGE; // Save the current SFRPAGE

   SFRPAGE = CONFIG_PAGE;              // Switch to the necessary SFRPAGE

   ADC0CN = 0x02;                      // ADC disabled;
                                       // Normal tracking mode;
                                       // ADC conversions are initiated
                                       // on overflow of Timer2

   REF0CN = 0x03;                      // Enable on-chip VREF and output buffer

   AMX0P = 0x01;                       // ADC0 positive mux = P1.1
   AMX0N = 0x1F;                       // ADC0 negative mux = GND
                                       // (single-ended)

   ADC0CF = ((SYSCLK/2500000)-1) << 3; // ADC conversion clock <= 2.5MHz
   ADC0CF |= 0x04;                     // Left-justify ADC0 data

   AD0EN = 1;                          // Enable ADC0

   SFRPAGE = SFRPAGE_save;             // Restore the SFRPAGE
}

//-----------------------------------------------------------------------------
// IDA0_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Enable IDAC0 and VREF.  The IDAC uses "8-bit" mode by setting IDA0L to
// always be 0.
//
//-----------------------------------------------------------------------------
void IDA0_Init (void)
{
   unsigned char SFRPAGE_save = SFRPAGE; // Save the current SFRPAGE

   SFRPAGE = CONFIG_PAGE;              // Switch to the necessary SFRPAGE

   REF0CN = 0x03;                      // Enable on-chip VREF and buffer

   IDA0CN = 0xB2;                      // Enable IDAC0 for 2.0 mA full-scale
                                       // output; updated on Timer3 overflows

   IDA0L = 0x00;                       // Initialize IDA0L to '0' for "8-bit"
                                       // IDAC mode

   SFRPAGE = SFRPAGE_save;             // Restore the SFRPAGE
}

//-----------------------------------------------------------------------------
// MAC0_Init
//-----------------------------------------------------------------------------
//
// Return Value:  None
// Parameters:    None
//
// Initialize the MAC for use in the Windowing and FFT calculations.
//
//-----------------------------------------------------------------------------
void MAC0_Init(void)
{
   unsigned char SFRPAGE_save = SFRPAGE; // Save the current SFRPAGE

   SFRPAGE = LEGACY_PAGE;              // Switch to the necessary SFRPAGE

   MAC0CF = 0x00;                      // Integer mode;
                                       // Multiply and Accumulate

   MAC0CF |= 0x08;                     // Clear the accumulator

   SFRPAGE = SFRPAGE_save;             // Restore the SFRPAGE
}

//-----------------------------------------------------------------------------
// Timer2_Init
//-----------------------------------------------------------------------------
//
// Return Value:  None
// Parameters:    None
//
// Configure Timer2 to 16-bit auto-reload mode and overflow at <SAMPLE_RATE>
// (no interrupt generated) using SYSCLK as its time base.
//
//-----------------------------------------------------------------------------
void Timer2_Init (void)
{
   unsigned char SFRPAGE_save = SFRPAGE; // Save the current SFRPAGE

   SFRPAGE = CONFIG_PAGE;              // Switch to the necessary SFRPAGE

   TMR2CN = 0x00;                      // Stop Timer2; Clear TF2
                                       // 16-bit mode
   CKCON |= 0x10;                      // Use SYSCLK as timebase

   TMR2RL = -(SYSCLK/SAMPLE_RATE);     // Init reload values
   TMR2 = TMR2RL;

   ET2 = 0;                            // Disable Timer2 interrupts
   TR2 = 1;                            // Start Timer2

   SFRPAGE = SFRPAGE_save;             // Restore the SFRPAGE
}

//-----------------------------------------------------------------------------
// Timer3_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   :
//   1)  int counts - calculated Timer overflow rate
//                    range is positive range of integer: 0 to 32767
//
// Configure Timer3 to auto-reload at interval specified by <counts>
// using SYSCLK as its time base.  Interrupts are enabled.
//
//-----------------------------------------------------------------------------
void Timer3_Init(int counts)
{
   unsigned char SFRPAGE_save = SFRPAGE; // Save the current SFRPAGE

   SFRPAGE = CONFIG_PAGE;              // Switch to the necessary SFRPAGE

   TMR3CN  = 0x00;                     // Resets Timer 3, sets to 16 bit mode
   CKCON  |= 0x40;                     // Use system clock

   TMR3RL  = -counts;                  // Initial reload value
   TMR3    = 0xffff;                   // Sets timer to reload automatically

   EIP1   |= 0x80;                     // Enable Timer 3 interrupts as high
                                       // priority

   TMR3CN |= 0x04;                     // Enable Timer3

   SFRPAGE = SFRPAGE_save;             // Restore the SFRPAGE
}

//-----------------------------------------------------------------------------
// Interrupt Service Routines
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// ADC0_ISR
//-----------------------------------------------------------------------------
//
// The ADC sample is stored in memory, and an index variable is incremented.
// If enough samples have been taken to process the FFT, then a flag is set,
// and ADC interrupts are disabled until the next set is requested.
//
//-----------------------------------------------------------------------------
//void ADC0_ISR (void) interrupt 10
INTERRUPT_USING(ADC0_ISR, INTERRUPT_ADC0_EOC, 2)
{
   static unsigned int ADC_Max_Input = 0x0000;
   static unsigned int ADC_Min_Input = 0xFFFF;

   AD0INT = 0;                         // Clear ADC conversion complete
                                       // flag

   Real[ADC_Index].U16 = ADC0;           // Store ADC value

   // Determine the minimum and maximum inputs values so that the Windowing
   // routine can properly remove the DC offset.
   if (Real[ADC_Index].U16 > ADC_Max_Input)
   {
      ADC_Max_Input = Real[ADC_Index].U16;
   }
   else if (Real[ADC_Index].U16 < ADC_Min_Input)
   {
      ADC_Min_Input = Real[ADC_Index].U16;
   }

   ADC_Index++;                        // Increment the index into memory

   if (ADC_Index >= NUM_FFT)           // If enough samples have been collected
   {
      Input_Offset = ((ADC_Max_Input - ADC_Min_Input)/2) + ADC_Min_Input;

      Conversion_Set_Complete = 1;     // Tell the Main Routine and...
      EIE1 &= ~0x08;                   // Disable ADC interrupts
      EIE1 &= ~0x80;                   // Disable IDAC interrupts
   }
}

//-----------------------------------------------------------------------------
// Timer3_ISR
//-----------------------------------------------------------------------------
//
// This ISR is called on Timer3 overflows.  Timer3 is set to auto-reload mode
// and is used to schedule the DAC output sample rate in this example.
// Note that the value that is written to the IDAC during this ISR call is
// actually transferred to the IDAC at the next Timer3 overflow.
//
// Note: DTMF "twist" is not generated in this routine.  This feature can be
// added by scaling the high tone or low tone before outputting the value on
// the DAC.
//
//-----------------------------------------------------------------------------
//void Timer3_ISR (void) interrupt 14
INTERRUPT_USING(Timer3_ISR, INTERRUPT_TIMER3, 3)
{
   static UU16 phase_acc1 = {0};       // Holds low-tone phase accumulator
   static UU16 phase_acc2 = {0};       // Holds high-tone phase accumulator

   unsigned int temp1;                 // Temp values for table results
   unsigned int temp2;

   TMR3CN &= ~0x80;                    // Clear Timer3 overflow flag

   phase_acc1.U16 += phase_add1;       // Update phase acc1 (low tone)
   temp1 = SINE_TABLE[phase_acc1.U8[MSB]];

   phase_acc2.U16 += phase_add2;       // Update phase acc2 (high tone)

   // Read the table value
   temp2 = SINE_TABLE[phase_acc2.U8[MSB]];

   // Now update the DAC value.  Note: the XOR with 0x80 translates
   // the bipolar table look-up into a unipolar quantity.
   IDA0H = 0x80 ^ ((temp1 >> 1) + (temp2 >> 1));
}

//-----------------------------------------------------------------------------
// Support Subroutines
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// WindowCalc
//-----------------------------------------------------------------------------
//
// Return Value:  None
// Parameters:
//    1) UU16 Win_Array Real[] - array of the input data from the ADC
//    2) unsigned char Remove_DC - if Remove_DC is 1, the input data will be
//             centered around 0 to remove the DC component.
//
// Uses the values in WindowFunc[] to window the stored data
// (in FFT_Code_Tables_MAC.h).
//
// The WindowFunc[] Array contains window coefficients between samples
// 0 and (NUM_FFT/2)-1, and samples from NUM_FFT/2 to NUM_FFT-1 are the mirror
// image of the other side.
//
// Window values are interpreted as a fraction of 1 (WindowFunc[x]/65536).
// The value at NUM_FFT/2 is assumed to be 1.0 (65536).
//
// If Remove_DC = 1, the input data is move to center around 0 to cancel the DC
// offset.  To do this, the ADC ISR records the maximum and minimum ADC data,
// calculates the middle point of the input waveform.  This value is then
// subtracted from the single-ended ADC inputs.
//
//-----------------------------------------------------------------------------
void WindowCalc(UU16 Win_Array[], bit Remove_DC)
{
   unsigned char SFRPAGE_save = SFRPAGE; // Save the current SFRPAGE

#if (WINDOW_TYPE != 0)                 // Use this section if a window has been
                                       // specified

   for (index = 0; index < NUM_FFT/2; index++)
   {
      // Array positions 1 to (NUM_FFT/2 - 1)
      if (Remove_DC)
      {
         Win_Array[index].U16 -= Input_Offset;
      }
      else
      {
         Win_Array[index].U16 = (unsigned)Win_Array[index].U16 >> 1;
      }

      MAC0A = WindowFunc[index];
      MAC0BH = Win_Array[index].U8[MSB];
      MAC0BL = Win_Array[index].U8[LSB];

      NOP();
      NOP();                           // ACC results available here
      NOP();

      if (!Remove_DC)
      {
         MAC0CF |= 0x20;
      }

      Win_Array[index].U16 = MAC0RND;

      MAC0CF |= 0x08;

      // Array positions (NUM_FFT/2 + 1) to (NUM_FFT - 1)
      if (Remove_DC)
      {
         Win_Array[NUM_FFT-index-1].U16 -= Input_Offset;
      }
      else
      {
         Win_Array[NUM_FFT-index-1].U16 = (unsigned)Win_Array[NUM_FFT-index-1].U16
                                      >> 1;
      }

      MAC0BH = Win_Array[NUM_FFT-index-1].U8[MSB];
      MAC0BL = Win_Array[NUM_FFT-index-1].U8[LSB];

      NOP();
      NOP();                           // ACC results available here
      NOP();

      if (!Remove_DC)
      {
         MAC0CF |= 0x20;
      }

      Win_Array[NUM_FFT-index-1].U16 = MAC0RND;

      MAC0CF |= 0x08;
   }

#endif

#if (WINDOW_TYPE == 0)                 // Compile this if no window has been
                                       // specified
   if (Remove_DC)
   {
      for (index = 0; index < NUM_FFT; index++)
      {
         Win_Array[index].U16 -= Input_Offset;
      }
   }
#endif

   SFRPAGE = SFRPAGE_save;
}

//-----------------------------------------------------------------------------
// Bit_Reverse
//-----------------------------------------------------------------------------
//
// Return Value:  None
// Parameters:
//    1) UU16 BR_Array[] - array to be bit-reversed in order.
//
// Sorts data in Bit Reversed Address order
//
// The BRTable[] array is used to find which values must be swapped.  Only
// half of this array is stored, to save code space.  The second half is
// assumed to be a mirror image of the first half.
//
//-----------------------------------------------------------------------------
void Bit_Reverse(UU16 BR_Array[])
{

// NOTE: NUM_FFT sizes larger than 256 can only be used in conjuction with
// an external XRAM through the EMIF.
#if (NUM_FFT >= 512)
   unsigned int swapA, swapB, sw_cnt;  // Swap Indices
#endif

#if (NUM_FFT <= 256)
   unsigned char swapA, swapB, sw_cnt; // Swap Indices
#endif

   int TempStore;

   // Loop through locations to swap
   for (sw_cnt = 1; sw_cnt < NUM_FFT/2; sw_cnt++)
   {
      swapA = sw_cnt;                  // Store current location
      swapB = BRTable[sw_cnt] * 2;     // Retrieve bit-reversed index
      if (swapB > swapA)               // If the bit-reversed index is
      {                                // larger than the current index,
         TempStore = BR_Array[swapA].U16; // the two data locations are
         BR_Array[swapA].U16 = BR_Array[swapB].U16; // swapped. Using this
         BR_Array[swapB].U16 = TempStore;  // comparison ensures that locations
      }                                // are only swapped once, and never with
                                       // themselves

      swapA += NUM_FFT/2;              // Now perform the same operations
      swapB++;                         // on the second half of the data
      if (swapB > swapA)
      {
         TempStore = BR_Array[swapA].U16;
         BR_Array[swapA].U16 = BR_Array[swapB].U16;
         BR_Array[swapB].U16 = TempStore;
      }
   }
}

//-----------------------------------------------------------------------------
// Int_FFT
//-----------------------------------------------------------------------------
//
// Return Value:  None
// Parameters:
//    1) UU16 ReArray[] - array of Real data values
//    2) UU16 ImArray[] - array of Imaginary data values
//
// Performs a Radix-2 Decimation-In-Time FFT on the input array ReArray[]
//
// During each stage of the FFT, the values are calculated using a set of
// "Butterfly" equations, as listed below:
//
// ReA = ReA + (Cos(x)*ReB + Sin(x)*ImB)
// ReB = ReA - (Cos(x)*ReB + Sin(x)*ImB)
// ImA = ImA + (Cos(x)*ImB - Sin(x)*ReB)
// ImB = ImA - (Cos(x)*ImB - Sin(x)*ReB)
//
// The routine implements this calculation using the MAC and the following
// values:
//
// ReA = ReArray[indexA], ReB = ReArray[indexB]
// ImA = ImArray[indexA], ImB = ImArray[indexB]
// x = the angle: 2*pi*(sin_index/NUM_FFT), in radians.  The necessary values
//    are stored in code space in the SinTable[] array.
//
//
// Key Points for using this FFT routine:
//
// 1) It expects REAL data (in ReArray[]), in 2's complement, 16-bit binary
//    format and assumes an initial value of 0 for all imaginary locations
//    (in ImArray[]).
//
// 2) It expects the REAL input data to be sorted in bit-reversed index order.
//
// 3) SIN and COS values are retrieved and calculated from a table consisting
//    of 1/4 of a period of a SIN function.
//
// 4) It is optimized to use integer math only (no floating-point operations),
//    and for storage space.  The input, all intermediate stages, and the
//    output of the FFT are stored as 16-bit INTEGER values. This limits the
//    precision of the routine.  When using input data of less than 16-bits,
//    the best results are produced by left-justifying the data prior to
//    windowing and performing the FFT.
//
// 5) The algorithm is a Radix-2 type, meaning that the number of samples must
//    be 2^N, where N is an integer.  The minimum number of samples to process
//    is 4.  The constant NUM_FFT contains the number of samples to process.
//
//-----------------------------------------------------------------------------
void Int_FFT(UU16 ReArray[], UU16 ImArray[])
{
// NOTE: NUM_FFT sizes larger than 256 can only be used in conjuction with
// an external XRAM through the EMIF.
#if (NUM_FFT >= 512)
   unsigned int sin_index, g_cnt, s_cnt; // Keeps track of the proper index
   unsigned int indexA, indexB;          // locations for each calculation
#endif

#if (NUM_FFT <= 256)
   unsigned char sin_index, g_cnt, s_cnt; // Keeps track of the proper index
   unsigned char indexA, indexB;          // locations for each calculation
#endif

   UU16 temp;                          // This must be declared here for use
                                       // with the FFT_AminusB macro

   unsigned int group = NUM_FFT/4, stage = 2;
   int CosVal, SinVal;
   UU32 ReTwid, ImTwid;
   UU16 TempReA, TempReB, TempImA, TempImB;
   UU16 TempReA2, TempReB2, TempImA2, TempImB2;

// ----------------------------------------------------------------------------
// FIRST STAGE - optimized for REAL input data only.  This will set all
// Imaginary locations to zero.
//
// The first stage is all of the 2-bit butterflies (so the groups are in
// pairs).
//
// Shortcuts have been taken to remove unnecessary multiplications during this
// stage. The angle "x" is 0 radians for all calculations at this point, so
// the SIN value is equal to 0.0 and the COS value is equal to 1.0.
// Additionally, all Imaginary locations are assumed to be '0' in this stage of
// the algorithm, and are set to '0'.
// ----------------------------------------------------------------------------

   // Initialize the MAC
   MAC0CF |= 0x10;                     // Right-shift mode
   MAC0CF |= 0x02;                     // Put the MAC in fractional mode
   MAC0CF |= 0x08;                     // Clear the accumulator

   indexA = 0;
   for (g_cnt = 0; g_cnt < NUM_FFT/2; g_cnt++)
   {
      indexB = indexA + 1;             // With bit-reversed input, A and B
                                       // are next to each other in the array

      TempReA.U16 = ReArray[indexA].U16; // Store the values in temporary
      TempReB.U16 = ReArray[indexB].U16; // variables to reduce clock cycles

      // Calculate new value for ReArray[indexA]
      // ReA2 = ReA.i + ReB.i;
      FFT_AplusB(TempReA, TempReB, ReArray[indexA].U16);

      // Calculate new value for ReArray[indexB]
      // ReA2 = ReA.i - ReB.i;
      FFT_AminusB(TempReA, TempReB, ReArray[indexB].U16)

      ImArray[indexA].U16 = 0;         // Set Imaginary locations to '0'
      ImArray[indexB].U16 = 0;

      indexA = indexB + 1;             // Move to the next butterfly pair
   }

// END OF FIRST STAGE

// ----------------------------------------------------------------------------
// 2nd - Nth stage - Calculate the appropriate butterflies.
//
// The 2nd stage is the 4-bit butterflies, 3rd stage is 8-bit butterflies, and
// so forth.  The <group> variable distinguishes between each n-bit butterfly,
// and the <stage> variable is used to determine which A and B in the array
// are combined to create the data for the next stage.
//
// Shortcuts have been taken to remove unnecessary multiplications during these
// stages. Whenever the angle "x" is 0 radians or pi/2 radians, the
// multiplications have been removed.
// ----------------------------------------------------------------------------

   while (stage <= NUM_FFT/2)
   {
      indexA = 0;
      sin_index = 0;

      for (g_cnt = 0; g_cnt < group; g_cnt++)
      {
         for (s_cnt = 0; s_cnt < stage; s_cnt++)
         {
            indexB = indexA + stage;

            TempReA.U16 = ReArray[indexA].U16;
            TempReB.U16 = ReArray[indexB].U16;
            TempImA.U16 = ImArray[indexA].U16;
            TempImB.U16 = ImArray[indexB].U16;

            // The following first checks for the special cases when the angle
            // "x" is equal to either 0 or pi/2 radians.  In these cases,
            // unnecessary multiplications have been removed to improve the
            // processing speed.
            //
            // Real_Twiddle = ReB*CosVal + ImB*SinVal
            // Imaginary_Twiddle = ImB*CosVal - ReB*SinVal
            //
            // ReA = ReA + Real_Twiddle
            // ReB = ReA - Real_Twiddle
            // ImA = ImA + Imaginary_Twiddle
            // ImB = ImA - Imaginary_Twiddle
            //
            // If the CosVal is 1 and SinVal is 0 (like when "x" = 0):
            //
            // ReA = ReA + (ReB*1 + ImB*0) = ReA + ReB
            // ReB = ReA - (ReB*1 + ImB*0) = ReA - ReB
            // ImA = ImA + (ImB*1 - ReB*0) = ImA + ImB
            // ImB = ImA - (ImB*1 - ReB*0) = ImA - ImB
            //
            // If the CosVal is 0 and SinVal is 1 (like when "x" = pi/2):
            //
            // ReA = ReA + (ReB*0 + ImB*1) = ReA + ImB
            // ReB = ReA - (ReB*0 + ImB*1) = ReA - ImB
            // ImA = ImA + (ImB*0 - ReB*1) = ImA - ReB
            // ImB = ImA - (ImB*0 - ReB*1) = ImA + ReB
            //
            if (sin_index == 0)  // corresponds to "x" = 0 radians
            {

               // Calculate new value for ReArray[indexA]
               // ReA = ReA + (ReB*1 + ImB*0) = ReA + ReB
               FFT_AplusB(TempReA, TempReB, TempReA2.U16);

               // Calculate new value for ReArray[indexB]
               // ReB = ReA - (ReB*1 + ImB*0) = ReA - ReB
               FFT_AminusB(TempReA, TempReB, TempReB2.U16);

               // Calculate new value for ImArray[indexA]
               // ImA = ImA + (ImB*1 - ReB*0) = ImA + ImB
               FFT_AplusB(TempImA, TempImB, TempImA2.U16);

               // Calculate new value for ImArray[indexB]
               // ImB = ImA - (ImB*1 - ReB*0) = ImA - ImB
               FFT_AminusB(TempImA, TempImB, TempImB2.U16);
            }
            else if (sin_index == NUM_FFT/4) // corresponds to "x" = pi/2
            {                                // radians

               // Calculate new value for ReArray[indexA]
               // ReA = ReA + (ReB*0 + ImB*1) = ReA + ImB
               FFT_AplusB(TempReA, TempImB, TempReA2.U16);

               // Calculate new value for ReArray[indexB]
               // ReB = ReA - (ReB*0 + ImB*1) = ReA - ImB
               FFT_AminusB(TempReA, TempImB, TempReB2.U16);

               // Calculate new value for ImArray[indexA]
               // ImA = ImA + (ImB*0 - ReB*1) = ImA - ReB
               FFT_AminusB(TempImA, TempReB, TempImA2.U16);

               // Calculate new value for ImArray[indexB]
               // ImB = ImA - (ImB*0 - ReB*1) = ImA + ReB
               FFT_AplusB(TempImA, TempReB, TempImB2.U16);
            }
            else
            {
               // If no multiplication shortcuts can be taken, the SIN and COS
               // values for the Butterfly calculation are fetched from the
               // SinTable[] array.
               //
               // Real_Twiddle = ReB*CosVal + ImB*SinVal
               // Imaginary_Twiddle = ImB*CosVal - ReB*SinVal
               //
               // ReA = ReA + Real_Twiddle
               // ReB = ReA - Real_Twiddle
               // ImA = ImA + Imaginary_Twiddle
               // ImB = ImA - Imaginary_Twiddle

               if (sin_index > NUM_FFT/4)
               {
                  SinVal = SinTable[(NUM_FFT/2) - sin_index];
                  CosVal = -SinTable[sin_index - (NUM_FFT/4)];
               }
               else
               {
                  SinVal = SinTable[sin_index];
                  CosVal = SinTable[(NUM_FFT/4) - sin_index];
               }

               // The SIN and COS values are used here to calculate part of the
               // Butterfly equation

               MAC0CF &= ~0x02;        // Put the MAC in integer mode

               // ReTwid.l = ((long)TempReB.U16 * CosVal) +
               //            ((long)TempImB.U16 * SinVal);
               MAC0A = CosVal;         // CosVal * ReB
               MAC0BH = TempReB.U8[MSB];
               MAC0BL = TempReB.U8[LSB];

               MAC0A = SinVal;         // SinVal * ImB
               MAC0BH = TempImB.U8[MSB];
               MAC0BL = TempImB.U8[LSB];

               NOP();
               NOP();

               ReTwid.U8[b3] = MAC0ACC3;
               ReTwid.U8[b2] = MAC0ACC2;
               ReTwid.U8[b1] = MAC0ACC1;
               ReTwid.U8[b0] = MAC0ACC0;

               MAC0CF |= 0x08;         // Clear the ACC

               // ImTwid.l = ((long)TempImB.U16 * CosVal) -
               //            ((long)TempReB.U16 * SinVal);
               MAC0A = SinVal;         // Multiply SinVal by -1
               MAC0BH = 0xFF;
               MAC0BL = 0xFF;

               NOP();
               NOP();

               MAC0AH = MAC0ACC1;
               MAC0AL = MAC0ACC0;

               MAC0CF |= 0x08;         // Clear the ACC

               MAC0BH = TempReB.U8[MSB]; // -SinVal * ReB
               MAC0BL = TempReB.U8[LSB];

               MAC0A = CosVal;         // CosVal * ImB
               MAC0BH = TempImB.U8[MSB];
               MAC0BL = TempImB.U8[LSB];

               NOP();
               NOP();

               ImTwid.U8[b3] = MAC0ACC3;
               ImTwid.U8[b2] = MAC0ACC2;
               ImTwid.U8[b1] = MAC0ACC1;
               ImTwid.U8[b0] = MAC0ACC0;

               MAC0CF |= 0x08;         // Clear the ACC

               MAC0CF |= 0x02;         // Put the MAC in fractional mode


               // Using the values calculated above, the new variables
               // are computed

               // Calculate new value for ReArray[indexA]
               // ReA = ReA + Real_Twiddle
               // by calculating:
               // ReA = -(-ReA) + Real_Twiddle
               MAC0A = TempReA.U16;      // ReA * -1
               MAC0BH = 0x80;
               MAC0BL = 0x00;

               NOP();
               NOP();

               MAC0CF |= 0x20;         // Right shift to guarantee no overflow

               NOP();
               NOP();

               MAC0AH = MAC0ACC3;      // Load -ReA in the MAC0A registers
               MAC0AL = MAC0ACC2;

               MAC0ACC3 = ReTwid.U8[b3]; // Load the ACC with ReTwid
               MAC0ACC2 = ReTwid.U8[b2];
               MAC0ACC1 = ReTwid.U8[b1];
               MAC0ACC0 = ReTwid.U8[b0];

               MAC0BH = 0x80;          // -ReA * -1
               MAC0BL = 0x00;

               NOP();
               NOP();

               TempReA2.U16 = MAC0RND;

               MAC0CF |= 0x08;         // Clear the ACC

               // Calculate new value for ReArray[indexB]
               // ReB = ReA - Real_Twiddle
               // by calculating:
               // -ReB = -ReA + Real_Twiddle
               MAC0ACC3 = ReTwid.U8[b3]; // Load the ACC with ReTwid
               MAC0ACC2 = ReTwid.U8[b2];
               MAC0ACC1 = ReTwid.U8[b1];
               MAC0ACC0 = ReTwid.U8[b0];

               MAC0A = 0x8000;         // ReA * -1
               MAC0BH = TempReA.U8[MSB];
               MAC0BL = TempReA.U8[LSB];

               NOP();
               NOP();
               NOP();

               MAC0CF |= 0x01;         // Multiply only mode

               MAC0A = MAC0RND;        // -ReB * -1
               MAC0BH = 0x80;
               MAC0BL = 0x00;

               NOP();
               NOP();

               TempReB2.U8[MSB] = MAC0ACC3;
               TempReB2.U8[LSB] = MAC0ACC2;

               MAC0CF &= ~0x01;        // Multiply and accumulate

               MAC0CF |= 0x08;         // Clear the ACC

               // Calculate new value for ImArray[indexA]
               // ImA = ImA + Imaginary_Twiddle
               // by calculating:
               // ImA = -(-ImA) + Imaginary_Twiddle
               MAC0A = TempImA.U16;      // ImA * -1
               MAC0BH = 0x80;
               MAC0BL = 0x00;

               NOP();
               NOP();

               MAC0CF |= 0x20;         // Right shift to guarantee no overflow

               NOP();
               NOP();

               MAC0AH = MAC0ACC3;      // Load -ImA in the MAC0A registers
               MAC0AL = MAC0ACC2;

               MAC0ACC3 = ImTwid.U8[b3]; // Load the ACC with ImTwid
               MAC0ACC2 = ImTwid.U8[b2];
               MAC0ACC1 = ImTwid.U8[b1];
               MAC0ACC0 = ImTwid.U8[b0];

               MAC0BH = 0x80;          // -ImA * -1
               MAC0BL = 0x00;

               NOP();
               NOP();

               TempImA2.U16 = MAC0RND;

               MAC0CF |= 0x08;         // Clear the ACC

               // Calculate new value for ImArray[indexB]
               // ImB = ImA - Imaginary_Twiddle
               // by calculating
               // -ImB = -ImA + Imaginary_Twiddle
               MAC0ACC3 = ImTwid.U8[b3]; // Load the ACC with ImTwid
               MAC0ACC2 = ImTwid.U8[b2];
               MAC0ACC1 = ImTwid.U8[b1];
               MAC0ACC0 = ImTwid.U8[b0];

               MAC0A = 0x8000;         // ImA * -1
               MAC0BH = TempImA.U8[MSB];
               MAC0BL = TempImA.U8[LSB];

               NOP();
               NOP();
               NOP();

               MAC0CF |= 0x01;         // Multiply only mode

               MAC0A = MAC0RND;        // -ImB * -1
               MAC0BH = 0x80;
               MAC0BL = 0x00;

               NOP();
               NOP();

               TempImB2.U8[MSB] = MAC0ACC3;
               TempImB2.U8[LSB] = MAC0ACC2;

               MAC0CF &= ~0x01;        // Multiply and accumulate

               MAC0CF |= 0x08;         // Clear the ACC

            }

            ReArray[indexA].U16 = TempReA2.U16;
            ReArray[indexB].U16 = TempReB2.U16;
            ImArray[indexA].U16 = TempImA2.U16;
            ImArray[indexB].U16 = TempImB2.U16;

            indexA++;
            sin_index += group;
         }                             // END of stage FOR loop (s_cnt)

         indexA = indexB + 1;
         sin_index = 0;
      }                                // END of group FOR loop (g_cnt)

      group /= 2;
      stage *= 2;
   }
}

//-----------------------------------------------------------------------------
// putchar
//-----------------------------------------------------------------------------
//
// Return Value:
//   1) char c - returns the char c that was passed as a parameter
// Parameters:
//   1) char c - the character to be printed
//
// Print the character <c> using the UART at <BAUDRATE>.
//
//-----------------------------------------------------------------------------
#if defined __C51__
char putchar (char c)
#elif defined SDCC
void putchar (char c)
#endif
{
   if (c == '\n')                      // Print a carriage return
   {
      while (!TI0);
      TI0 = 0;
      SBUF0 = 0x0d;
   }
   while (!TI0);
   TI0 = 0;
   SBUF0 = c;
#if defined __C51__
   return c;                           // Print the character
#endif
}

//-----------------------------------------------------------------------------
// End Of File
//-----------------------------------------------------------------------------
